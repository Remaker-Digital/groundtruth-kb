# Codex Session Bootstrap - {{PROJECT_NAME}}

This document defines the mandatory startup sequence for every Codex session.
Execute phases A through C in order before beginning any assigned work.

---

## Phase A: Bridge Sweep

1. **Read canonical bridge state.** Use TAFE/dispatcher bridge state. Treat
   retired bridge-index artifacts as non-authoritative historical material.
2. **Identify actionable entries.** Process document entries whose latest
   status is `NEW` or `REVISED`. Entries are newest-first; historical status
   lines are evidence, not current work.
3. **Review each entry.** Read the referenced bridge document and relevant
   artifacts.
4. **Write the response.** Create the next numbered bridge document through the
   governed bridge writer/helper path; that path must not recreate retired
   bridge-index artifacts.
5. **Report.** Log the result: "File bridge scan: N entries processed."

If canonical bridge state is missing, report that the bridge is not initialized
and continue with Phase B. Do not use a retired bridge-index view or an
archived SQLite/MCP bridge runtime as the active queue for new projects.

---

## Phase B: Read Project Documents

Load and internalize the following documents in order:

1. `CLAUDE.md` -- Project rules, governance, and procedures.
2. `MEMORY.md` -- Current project state, versions, recent sessions.
   - MEMORY.md is the operational notepad per ADR-0001: Three-Tier Memory Architecture; canonical knowledge lives in MemBase.
3. `AGENTS.md` -- Loyal Opposition operating contract, if present.
4. `.claude/rules/canonical-terminology.md` -- ADR-0001 canonical vocabulary (MemBase, DA, Prime Builder, Loyal Opposition, etc.).
5. `BRIDGE-INVENTORY.md` -- Bridge scripts, prompts, schedules, and recovery.
6. `independent-progress-assessments/LOYAL-OPPOSITION-LOG.md` -- Open items,
   pending decisions, and completed work from prior sessions, if present.

Note any discrepancies between documents. If MEMORY.md and CLAUDE.md conflict,
CLAUDE.md takes precedence (rules over state). Remember: MEMORY.md can coordinate work, but it cannot make anything true.

---

## Phase C: Check for Pending Review Requests

1. Confirm whether any latest `NEW` or `REVISED` entries remain in canonical
   bridge state.
2. Check the insight dropbox for reports that reference unresolved items.
3. Prioritize pending bridge review requests over exploratory analysis.

Report your readiness state:

```text
Codex session [session_id] initialized.
- File bridge: [clear/actionable/degraded/not initialized]
- Documents loaded: [count]
- Pending reviews: [count]
- Ready to proceed: [yes/no + reason if no]
```

---

*Copyright 2026 Remaker Digital, a DBA of VanDusen & Palmeter, LLC. All rights reserved.*
