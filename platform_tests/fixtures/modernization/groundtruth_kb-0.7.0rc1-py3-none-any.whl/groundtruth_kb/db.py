"""
GroundTruth KB — Versioned SQLite store for project artifacts.

Manages specifications, tests, test plans, work items, backlog snapshots,
operational procedures, documents, and environment config. Core data uses
append-only versioning (UNIQUE(id, version)) — every mutation creates a new
versioned record.

RETENTION POLICY: Core artifact rows are never deleted. Operational tables
(assertion_runs, quality_scores) permit maintenance deletes for pruning stale
history. Use export_json() for logical backups.

Copyright (c) 2026 Remaker Digital, a DBA of VanDusen & Palmeter, LLC. All rights reserved.
Licensed under AGPL-3.0-or-later.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import logging
import os
import re
import sqlite3
import threading
import uuid
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

from groundtruth_kb.governance.credential_patterns import db_pattern_list

_log = logging.getLogger(__name__)

if TYPE_CHECKING:
    from groundtruth_kb.gates import GateRegistry

# Default DB path — overridden by GTConfig.db_path or constructor arg
DB_PATH = Path("./groundtruth.db")


# ChromaDB optional dependency (ignore_missing_imports configured in pyproject.toml).
# Availability is resolved cheaply at import time via find_spec, which locates the
# module spec WITHOUT executing the package (~17ms vs. chromadb's ~6s import chain).
# The chromadb module itself is imported lazily on first semantic-search use via
# _load_chromadb(), so `import groundtruth_kb` stays fast for hooks and the CLI.
def _compute_has_chromadb() -> bool:
    """Return True when the chromadb module spec can be located.

    Availability is gated solely on whether ``chromadb`` is importable, resolved
    cheaply via ``find_spec`` (no package execution). WI-4561 removed the stale
    static Python-version ceiling (a ``sys.version_info`` upper-bound comparison
    against 3.14): it force-disabled an installed, functional chromadb on Python
    3.14 even though chromadb 1.5.9 embeds and queries correctly on that
    interpreter. Genuine
    import breakage on any current or future interpreter remains handled at
    lazy-import time by ``_load_chromadb()``, which flips ``HAS_CHROMADB`` to
    False on ``ImportError`` and falls back to SQLite LIKE search — so removing
    the version ceiling preserves graceful degradation.
    """
    try:
        return importlib.util.find_spec("chromadb") is not None
    except (ImportError, ValueError):
        return False


HAS_CHROMADB = _compute_has_chromadb()

chromadb = None  # type: ignore[assignment]  # populated lazily by _load_chromadb()


def _load_chromadb() -> Any | None:
    """Import and cache the chromadb module on first use.

    Returns the chromadb module, or None when chromadb is unavailable or when the
    lazy import fails. On lazy ImportError, HAS_CHROMADB is flipped to False so the
    optional-dependency contract — treat chromadb as unavailable, fall back to
    SQLite LIKE search — is preserved exactly as in the prior eager-import design.
    """
    global chromadb, HAS_CHROMADB
    if chromadb is None and HAS_CHROMADB:
        try:
            import chromadb as _chromadb
        except ImportError:
            HAS_CHROMADB = False
            return None
        chromadb = _chromadb
    return chromadb


# Semantic search constants
SEMANTIC_MAX_DISTANCE = 1.5  # L2 distance threshold for relevance filtering
CHUNK_MAX_TOKENS = 230  # Safe margin below all-MiniLM-L6-v2's 256 wordpiece limit
CHUNK_OVERLAP_TOKENS = 30  # Overlap between consecutive chunks
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
_CHROMA_COLLECTION_NAME = "deliberations"

# FAB-17 (HYG-048): the ChromaDB read path must DEGRADE under contention, not
# crash or hang. Multi-session concurrency is this project's normal mode, so the
# chroma probe + query run under a bounded timeout in a daemon worker thread the
# caller can abandon; on timeout or error the caller falls back to the
# SQLite-LIKE path (search_method="text_match"). Overridable via env for
# operators on slow disks.
_CHROMA_QUERY_TIMEOUT_SECONDS = float(os.environ.get("GTKB_CHROMA_QUERY_TIMEOUT_SECONDS") or "10")
_CHROMA_QUERY_RETRIES = int(os.environ.get("GTKB_CHROMA_QUERY_RETRIES") or "1")
_CHROMA_STALE_SEGMENT_ERROR_PATTERNS = (
    "failed to apply logs",
    "hnsw segment",
    "error querying knn",
)

# WI-4453: the index/record path (collection.add) triggers the SAME first-embed
# DefaultEmbeddingFunction model load as the query path, so `gt deliberations
# record` and any `gt bridge propose` that indexes a deliberation could hang
# indefinitely on an offline/stalled embedding step. Bound the add under the
# same daemon-worker timeout used for the query path (FAB-17). On timeout the
# canonical SQLite DA row — already committed by insert_deliberation before
# indexing — is preserved and only the rebuildable semantic index is deferred
# (recoverable via rebuild_deliberation_index). Overridable via env.
_CHROMA_INDEX_TIMEOUT_SECONDS = float(os.environ.get("GTKB_CHROMA_INDEX_TIMEOUT_SECONDS") or "15")

# FAB-17 (Area 3): the single canonical on-disk Chroma store directory name,
# declared in config/governance/chroma-read-path.toml so every read path
# resolves to ONE index and no stray default-path store (e.g. ./chroma) is
# treated as authoritative. Falls back to the historical default when the config
# is absent (adopter installs / fresh clones).
_CANONICAL_CHROMA_DIRNAME_DEFAULT = ".groundtruth-chroma"
_CHROMA_READ_PATH_CONFIG_RELPATH = ("config", "governance", "chroma-read-path.toml")


def _call_with_timeout(fn: Callable[[], Any], timeout_seconds: float) -> Any:
    """Run ``fn()`` in a daemon thread, raising ``TimeoutError`` past ``timeout_seconds``.

    The worker is a daemon so a genuinely hung ChromaDB C call cannot block
    interpreter exit or the calling session; on timeout we abandon it and let
    the caller degrade to the SQLite-LIKE fallback. Exceptions raised by ``fn``
    are re-raised on the calling thread.
    """
    box: dict[str, Any] = {}

    def _worker() -> None:
        try:
            box["value"] = fn()
        except Exception as exc:  # intentional-catch: surfaced to the caller below
            box["error"] = exc

    thread = threading.Thread(target=_worker, name="gtkb-chroma-query", daemon=True)
    thread.start()
    thread.join(timeout_seconds)
    if thread.is_alive():
        raise TimeoutError(f"ChromaDB query exceeded {timeout_seconds:.1f}s")
    if "error" in box:
        raise box["error"]
    return box.get("value")


def _is_chroma_stale_segment_error(exc: BaseException) -> bool:
    """Return True for known stale/incompatible Chroma HNSW segment failures."""
    message = str(exc).lower()
    return any(pattern in message for pattern in _CHROMA_STALE_SEGMENT_ERROR_PATTERNS)


WORK_ITEM_BACKLOG_COLUMNS = {
    "approval_state": "TEXT",
    "project_name": "TEXT",
    "subproject_name": "TEXT",
    "implementation_order": "INTEGER",
    "status_detail": "TEXT",
    "source_owner_directive": "TEXT",
    "source_deliberation_query": "TEXT",
    "related_deliberation_ids": "TEXT",
    "related_spec_ids_at_creation": "TEXT",
    "related_bridge_threads": "TEXT",
    "depends_on_work_items": "TEXT",
    "blocks_work_items": "TEXT",
    "acceptance_summary": "TEXT",
    "regression_visibility": "TEXT",
    "completion_evidence": "TEXT",
    "supersedes": "TEXT",
    "superseded_by": "TEXT",
}

WORK_ITEM_BACKLOG_FIELDS = tuple(WORK_ITEM_BACKLOG_COLUMNS)

WORK_ITEM_TERMINAL_RESOLUTION_STATUSES = (
    "verified",
    "resolved",
    "retired",
    "wont_fix",
    "not_a_defect",
)

PROJECT_TERMINAL_STATUSES = (
    "completed",
    "retired",
    "cancelled",
)


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS specifications (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    priority TEXT,
    scope TEXT,
    section TEXT,
    handle TEXT,
    tags TEXT,
    status TEXT NOT NULL,
    assertions TEXT,
    implementation_verified_at TEXT,
    retired_at TEXT,
    parent TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS specification_deliberation_sources (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    spec_id TEXT NOT NULL,
    spec_version INTEGER NOT NULL,
    deliberation_id TEXT NOT NULL,
    source_role TEXT,
    added_at TEXT NOT NULL,
    added_by TEXT NOT NULL,
    UNIQUE(spec_id, spec_version, deliberation_id)
);

CREATE TABLE IF NOT EXISTS test_procedures (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    title TEXT NOT NULL,
    type TEXT,
    content TEXT,
    assertion_count INTEGER,
    last_execution_status TEXT,
    last_executed_at TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS operational_procedures (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    title TEXT NOT NULL,
    type TEXT,
    variables TEXT,
    steps TEXT,
    known_failure_modes TEXT,
    last_verified_at TEXT,
    last_corrected_at TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS assertion_runs (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    spec_id TEXT NOT NULL,
    spec_version INTEGER NOT NULL,
    run_at TEXT NOT NULL,
    overall_passed INTEGER NOT NULL,
    results TEXT NOT NULL,
    triggered_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS session_prompts (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    event_type TEXT NOT NULL DEFAULT 'created',
    created_at TEXT NOT NULL,
    prompt_text TEXT NOT NULL,
    context TEXT
);

CREATE TABLE IF NOT EXISTS dispatch_events (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    rule_id TEXT NOT NULL,
    target_kind TEXT NOT NULL,
    target_value TEXT NOT NULL,
    trigger_at TEXT NOT NULL,
    gate_result TEXT NOT NULL,
    payload_template_id TEXT,
    spawn_outcome TEXT NOT NULL,
    spawn_pid INTEGER,
    spawn_exit_status INTEGER,
    activity_gate TEXT NOT NULL,
    dry_run INTEGER NOT NULL DEFAULT 1,
    payload TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS environment_config (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    environment TEXT NOT NULL,
    category TEXT NOT NULL,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    sensitive INTEGER NOT NULL DEFAULT 0,
    notes TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS documents (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    content TEXT,
    tags TEXT,
    status TEXT NOT NULL,
    source_path TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS test_coverage (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    spec_id TEXT NOT NULL,
    test_file TEXT NOT NULL,
    test_class TEXT,
    test_function TEXT NOT NULL,
    confidence TEXT NOT NULL DEFAULT 'high',
    match_reason TEXT,
    created_at TEXT NOT NULL,
    created_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS tests (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    title TEXT NOT NULL,
    spec_id TEXT NOT NULL,
    test_type TEXT NOT NULL,
    test_file TEXT,
    test_class TEXT,
    test_function TEXT,
    description TEXT,
    expected_outcome TEXT NOT NULL,
    last_result TEXT,
    last_executed_at TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS test_plans (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS test_plan_phases (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    plan_id TEXT NOT NULL,
    phase_order INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    gate_criteria TEXT NOT NULL,
    test_ids TEXT,
    last_result TEXT,
    last_executed_at TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS work_items (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    origin TEXT NOT NULL,
    component TEXT NOT NULL,
    source_spec_id TEXT,
    source_test_id TEXT,
    failure_description TEXT,
    resolution_status TEXT NOT NULL,
    priority TEXT,
    stage TEXT NOT NULL DEFAULT 'created',
    approval_state TEXT,
    project_name TEXT,
    subproject_name TEXT,
    implementation_order INTEGER,
    status_detail TEXT,
    source_owner_directive TEXT,
    source_deliberation_query TEXT,
    related_deliberation_ids TEXT,
    related_spec_ids_at_creation TEXT,
    related_bridge_threads TEXT,
    depends_on_work_items TEXT,
    blocks_work_items TEXT,
    acceptance_summary TEXT,
    regression_visibility TEXT,
    completion_evidence TEXT,
    supersedes TEXT,
    superseded_by TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS projects (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    rank INTEGER,
    parent_project_id TEXT,
    purpose TEXT,
    target_outcome TEXT,
    scope_note TEXT,
    start_date TEXT,
    target_date TEXT,
    completed_at TEXT,
    notes TEXT,
    source_project_name TEXT,
    source_subproject_name TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS project_work_item_memberships (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    project_id TEXT NOT NULL,
    work_item_id TEXT NOT NULL,
    membership_role TEXT NOT NULL DEFAULT 'member',
    membership_order INTEGER,
    status TEXT NOT NULL DEFAULT 'active',
    source TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS project_dependencies (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    from_project_id TEXT NOT NULL,
    to_project_id TEXT NOT NULL,
    dependency_type TEXT NOT NULL DEFAULT 'depends_on',
    rationale TEXT,
    blocking_status TEXT NOT NULL DEFAULT 'open',
    related_work_item_id TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS project_artifact_links (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    project_id TEXT NOT NULL,
    artifact_type TEXT NOT NULL,
    artifact_ref TEXT NOT NULL,
    relationship TEXT NOT NULL DEFAULT 'related',
    status TEXT NOT NULL DEFAULT 'active',
    notes TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS project_authorizations (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    project_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    authorization_name TEXT NOT NULL,
    owner_decision_deliberation_id TEXT NOT NULL,
    scope_summary TEXT NOT NULL,
    allowed_mutation_classes TEXT,
    forbidden_operations TEXT,
    included_work_item_ids TEXT,
    excluded_work_item_ids TEXT,
    included_spec_ids TEXT,
    excluded_spec_ids TEXT,
    expires_at TEXT,
    supersedes TEXT,
    superseded_by TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS flow_definitions (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    flow_type TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    stage_sequence TEXT NOT NULL,
    required_roles_by_stage TEXT NOT NULL,
    auq_gate_positions TEXT,
    never_self_review_stages TEXT,
    deterministic_carve_outs TEXT,
    workspace_isolation TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS flow_instances (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    flow_definition_id TEXT NOT NULL,
    flow_definition_version INTEGER,
    flow_type TEXT,
    subject_type TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'created',
    current_stage_instance_id TEXT,
    started_at TEXT,
    completed_at TEXT,
    metadata TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS stage_instances (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    flow_instance_id TEXT NOT NULL,
    stage_id TEXT NOT NULL,
    stage_index INTEGER NOT NULL,
    required_role TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    claim_status TEXT NOT NULL DEFAULT 'unclaimed',
    claimed_by_harness_id TEXT,
    claimed_by_session_id TEXT,
    started_at TEXT,
    completed_at TEXT,
    metadata TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS flow_events (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    flow_instance_id TEXT NOT NULL,
    stage_instance_id TEXT,
    event_type TEXT NOT NULL,
    event_at TEXT NOT NULL,
    event_payload TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id)
);

CREATE TABLE IF NOT EXISTS flow_artifacts (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    flow_instance_id TEXT NOT NULL,
    stage_instance_id TEXT,
    artifact_type TEXT NOT NULL,
    artifact_ref TEXT NOT NULL,
    relationship TEXT NOT NULL DEFAULT 'related',
    status TEXT NOT NULL DEFAULT 'active',
    metadata TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id)
);

CREATE TABLE IF NOT EXISTS stage_leases (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    stage_instance_id TEXT NOT NULL,
    holder_harness_id TEXT NOT NULL,
    holder_session_id TEXT NOT NULL,
    lease_status TEXT NOT NULL DEFAULT 'active',
    acquired_at TEXT NOT NULL,
    heartbeat_at TEXT,
    ttl_seconds INTEGER NOT NULL,
    expires_at TEXT,
    released_at TEXT,
    metadata TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS stage_attempt_telemetry (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    flow_instance_id TEXT NOT NULL,
    stage_instance_id TEXT NOT NULL,
    attempt_number INTEGER,
    agent_harness_id TEXT,
    agent_session_id TEXT,
    agent_context_id TEXT,
    model_identifier TEXT,
    provider TEXT,
    dispatch_decision TEXT,
    lease_id TEXT,
    lease_lifecycle TEXT,
    started_at TEXT,
    completed_at TEXT,
    duration_ms INTEGER,
    token_count INTEGER,
    cost REAL,
    outcome TEXT,
    verdict TEXT,
    test_summary TEXT,
    failure_class TEXT,
    cleanup_result TEXT,
    recovery_actions TEXT,
    artifact_links TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    metadata TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS agent_capability_snapshots (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    harness_id TEXT NOT NULL,
    harness_name TEXT,
    role TEXT NOT NULL,
    subject_scope TEXT,
    health_status TEXT NOT NULL DEFAULT 'unknown',
    reviewer_precedence INTEGER,
    workspace_availability TEXT,
    model_identifier TEXT,
    capabilities TEXT,
    captured_at TEXT NOT NULL,
    source TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    metadata TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS backlog_snapshots (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    snapshot_at TEXT NOT NULL,
    work_item_ids TEXT NOT NULL,
    summary_by_origin TEXT,
    summary_by_component TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS testable_elements (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    subsystem TEXT NOT NULL,
    page_or_module TEXT NOT NULL,
    name TEXT NOT NULL,
    element_type TEXT NOT NULL,
    expected_behavior TEXT NOT NULL,
    spec_id TEXT,
    applicable_dimensions TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS quality_scores (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    computed_at TEXT NOT NULL,
    spec_coverage REAL NOT NULL,
    defect_escape_rate REAL NOT NULL,
    assertion_strength REAL NOT NULL,
    change_failure_rate REAL NOT NULL,
    test_freshness REAL NOT NULL,
    coverage_delta REAL NOT NULL,
    composite_score REAL NOT NULL,
    details TEXT,
    UNIQUE(session_id)
);

-- F3: Per-spec quality scores (spec pipeline)
CREATE TABLE IF NOT EXISTS spec_quality_scores (
    spec_id TEXT NOT NULL,
    spec_version INTEGER NOT NULL,
    session_id TEXT NOT NULL,
    scored_at TEXT NOT NULL,
    overall REAL NOT NULL,
    d1_clarity REAL NOT NULL,
    d2_testability REAL NOT NULL,
    d3_completeness REAL NOT NULL,
    d4_isolation REAL NOT NULL,
    d5_freshness REAL NOT NULL,
    tier TEXT NOT NULL,
    flags TEXT,
    UNIQUE(spec_id, spec_version, session_id)
);

-- F7: Session health snapshots
CREATE TABLE IF NOT EXISTS session_snapshots (
    session_id TEXT NOT NULL PRIMARY KEY,
    captured_at TEXT NOT NULL,
    data TEXT NOT NULL
);

-- Pipeline lifecycle events (SPEC-2099) — append-only event log
CREATE TABLE IF NOT EXISTS pipeline_events (
    id              TEXT    NOT NULL PRIMARY KEY,
    event_type      TEXT    NOT NULL,
    session_id      TEXT,
    artifact_id     TEXT,
    artifact_type   TEXT,
    artifact_version INTEGER,
    timestamp       TEXT    NOT NULL,
    duration_ms     INTEGER,
    metadata        TEXT,
    changed_by      TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS deliberations (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    spec_id TEXT,
    work_item_id TEXT,
    source_type TEXT NOT NULL,
    source_ref TEXT,
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    content TEXT NOT NULL,
    content_hash TEXT,
    participants TEXT,
    outcome TEXT,
    session_id TEXT,
    sensitivity TEXT DEFAULT 'normal',
    redaction_state TEXT DEFAULT 'clean',
    redaction_notes TEXT,
    origin_project TEXT,
    origin_repo TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE TABLE IF NOT EXISTS deliberation_specs (
    deliberation_id TEXT NOT NULL,
    spec_id TEXT NOT NULL,
    role TEXT DEFAULT 'related',
    UNIQUE(deliberation_id, spec_id)
);

CREATE TABLE IF NOT EXISTS deliberation_work_items (
    deliberation_id TEXT NOT NULL,
    work_item_id TEXT NOT NULL,
    role TEXT DEFAULT 'related',
    UNIQUE(deliberation_id, work_item_id)
);

-- Canonical Terminology System backing registry
-- (per gtkb-canonical-terminology-system-context-model-001-005, GO at -006).
-- Phase 1: structured backing registry; markdown/TOML remain startup-readable
-- canonical authority. Append-only/versioned per artifact discipline.
CREATE TABLE IF NOT EXISTS canonical_terms (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    canonical_term TEXT NOT NULL,
    definition TEXT NOT NULL,
    authority_level TEXT NOT NULL CHECK (authority_level IN ('platform_core', 'adopter_extension', 'project_local')),
    scope TEXT NOT NULL,
    accepted_synonyms TEXT,
    discouraged_synonyms TEXT,
    linked_artifacts TEXT,
    linked_services TEXT,
    usage_examples TEXT,
    forbidden_uses TEXT,
    lifecycle_status TEXT NOT NULL CHECK (lifecycle_status IN ('candidate', 'active', 'deprecated', 'retired')),
    source_authority TEXT NOT NULL,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

-- Harness registry: append-only authoritative store of AI coding harness
-- records (REQ-HARNESS-REGISTRY-001 FR1). Topology is derived, never stored.
CREATE TABLE IF NOT EXISTS harnesses (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    harness_name TEXT NOT NULL,
    harness_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'registered',
    role TEXT NOT NULL,
    reviewer_precedence INTEGER,
    invocation_surfaces TEXT,
    capabilities_ref TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

-- Indexes for query performance (append-only tables grow monotonically)
CREATE INDEX IF NOT EXISTS idx_specs_id_version ON specifications(id, version);
CREATE INDEX IF NOT EXISTS idx_specs_status ON specifications(status);
CREATE INDEX IF NOT EXISTS idx_specs_changed_at ON specifications(changed_at);
CREATE INDEX IF NOT EXISTS idx_test_procs_id_version ON test_procedures(id, version);
CREATE INDEX IF NOT EXISTS idx_op_procs_id_version ON operational_procedures(id, version);
CREATE INDEX IF NOT EXISTS idx_assertion_runs_spec ON assertion_runs(spec_id, rowid);
CREATE INDEX IF NOT EXISTS idx_session_prompts_session ON session_prompts(session_id, rowid);
CREATE INDEX IF NOT EXISTS idx_dispatch_events_rule ON dispatch_events(rule_id, rowid);
CREATE INDEX IF NOT EXISTS idx_env_config_id_version ON environment_config(id, version);
CREATE INDEX IF NOT EXISTS idx_env_config_env_cat ON environment_config(environment, category);
CREATE INDEX IF NOT EXISTS idx_docs_id_version ON documents(id, version);
CREATE INDEX IF NOT EXISTS idx_docs_category ON documents(category);
CREATE INDEX IF NOT EXISTS idx_test_cov_spec ON test_coverage(spec_id);
CREATE INDEX IF NOT EXISTS idx_test_cov_file ON test_coverage(test_file);
CREATE INDEX IF NOT EXISTS idx_tests_id_version ON tests(id, version);
CREATE INDEX IF NOT EXISTS idx_tests_spec_id ON tests(spec_id);
CREATE INDEX IF NOT EXISTS idx_test_plans_id_version ON test_plans(id, version);
CREATE INDEX IF NOT EXISTS idx_tpp_id_version ON test_plan_phases(id, version);
CREATE INDEX IF NOT EXISTS idx_tpp_plan_id ON test_plan_phases(plan_id);
CREATE INDEX IF NOT EXISTS idx_work_items_id_version ON work_items(id, version);
CREATE INDEX IF NOT EXISTS idx_work_items_status ON work_items(resolution_status);
CREATE INDEX IF NOT EXISTS idx_work_items_origin ON work_items(origin);
CREATE INDEX IF NOT EXISTS idx_projects_id_version ON projects(id, version);
CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
CREATE INDEX IF NOT EXISTS idx_projects_rank ON projects(rank);
CREATE INDEX IF NOT EXISTS idx_projects_parent ON projects(parent_project_id);
CREATE INDEX IF NOT EXISTS idx_project_memberships_id_version ON project_work_item_memberships(id, version);
CREATE INDEX IF NOT EXISTS idx_project_memberships_project ON project_work_item_memberships(project_id);
CREATE INDEX IF NOT EXISTS idx_project_memberships_work_item ON project_work_item_memberships(work_item_id);
CREATE INDEX IF NOT EXISTS idx_project_dependencies_id_version ON project_dependencies(id, version);
CREATE INDEX IF NOT EXISTS idx_project_dependencies_from ON project_dependencies(from_project_id);
CREATE INDEX IF NOT EXISTS idx_project_dependencies_to ON project_dependencies(to_project_id);
CREATE INDEX IF NOT EXISTS idx_project_artifact_links_id_version ON project_artifact_links(id, version);
CREATE INDEX IF NOT EXISTS idx_project_artifact_links_project ON project_artifact_links(project_id);
CREATE INDEX IF NOT EXISTS idx_project_artifact_links_artifact ON project_artifact_links(artifact_type, artifact_ref);
CREATE INDEX IF NOT EXISTS idx_project_authorizations_id_version ON project_authorizations(id, version);
CREATE INDEX IF NOT EXISTS idx_project_authorizations_project ON project_authorizations(project_id);
CREATE INDEX IF NOT EXISTS idx_project_authorizations_status ON project_authorizations(status);
CREATE INDEX IF NOT EXISTS idx_project_authorizations_owner_decision
    ON project_authorizations(owner_decision_deliberation_id);
CREATE INDEX IF NOT EXISTS idx_flow_definitions_id_version ON flow_definitions(id, version);
CREATE INDEX IF NOT EXISTS idx_flow_definitions_flow_type ON flow_definitions(flow_type);
CREATE INDEX IF NOT EXISTS idx_flow_instances_id_version ON flow_instances(id, version);
CREATE INDEX IF NOT EXISTS idx_flow_instances_definition ON flow_instances(flow_definition_id);
CREATE INDEX IF NOT EXISTS idx_flow_instances_status ON flow_instances(status);
CREATE INDEX IF NOT EXISTS idx_stage_instances_id_version ON stage_instances(id, version);
CREATE INDEX IF NOT EXISTS idx_stage_instances_flow ON stage_instances(flow_instance_id);
CREATE INDEX IF NOT EXISTS idx_stage_instances_status ON stage_instances(status);
CREATE INDEX IF NOT EXISTS idx_flow_events_flow ON flow_events(flow_instance_id, rowid);
CREATE INDEX IF NOT EXISTS idx_flow_events_stage ON flow_events(stage_instance_id, rowid);
CREATE INDEX IF NOT EXISTS idx_flow_events_type ON flow_events(event_type);
CREATE INDEX IF NOT EXISTS idx_flow_artifacts_flow ON flow_artifacts(flow_instance_id, rowid);
CREATE INDEX IF NOT EXISTS idx_flow_artifacts_artifact ON flow_artifacts(artifact_type, artifact_ref);
CREATE INDEX IF NOT EXISTS idx_stage_leases_id_version ON stage_leases(id, version);
CREATE INDEX IF NOT EXISTS idx_stage_leases_stage ON stage_leases(stage_instance_id);
CREATE INDEX IF NOT EXISTS idx_stage_leases_status ON stage_leases(lease_status);
CREATE INDEX IF NOT EXISTS idx_stage_leases_holder ON stage_leases(holder_harness_id, holder_session_id);
CREATE INDEX IF NOT EXISTS idx_stage_leases_heartbeat ON stage_leases(heartbeat_at);
CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_id_version ON stage_attempt_telemetry(id, version);
CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_flow ON stage_attempt_telemetry(flow_instance_id);
CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_stage ON stage_attempt_telemetry(stage_instance_id);
CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_outcome ON stage_attempt_telemetry(outcome);
CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_failure_class ON stage_attempt_telemetry(failure_class);
CREATE INDEX IF NOT EXISTS idx_agent_capability_snapshots_id_version ON agent_capability_snapshots(id, version);
CREATE INDEX IF NOT EXISTS idx_agent_capability_snapshots_harness ON agent_capability_snapshots(harness_id);
CREATE INDEX IF NOT EXISTS idx_agent_capability_snapshots_health ON agent_capability_snapshots(health_status);
CREATE INDEX IF NOT EXISTS idx_agent_capability_snapshots_captured ON agent_capability_snapshots(captured_at);
CREATE INDEX IF NOT EXISTS idx_backlog_id_version ON backlog_snapshots(id, version);
CREATE INDEX IF NOT EXISTS idx_te_id_version ON testable_elements(id, version);
CREATE INDEX IF NOT EXISTS idx_te_subsystem ON testable_elements(subsystem);
CREATE INDEX IF NOT EXISTS idx_te_status ON testable_elements(status);
CREATE INDEX IF NOT EXISTS idx_quality_scores_session ON quality_scores(session_id);
CREATE INDEX IF NOT EXISTS idx_pe_event_type_ts ON pipeline_events(event_type, timestamp);
CREATE INDEX IF NOT EXISTS idx_pe_artifact ON pipeline_events(artifact_type, artifact_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_pe_session_ts ON pipeline_events(session_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_deliberations_id_version ON deliberations(id, version);
CREATE INDEX IF NOT EXISTS idx_deliberations_spec_id ON deliberations(spec_id);
CREATE INDEX IF NOT EXISTS idx_deliberations_work_item_id ON deliberations(work_item_id);
CREATE INDEX IF NOT EXISTS idx_deliberations_source_type ON deliberations(source_type);
CREATE INDEX IF NOT EXISTS idx_deliberations_session_id ON deliberations(session_id);
CREATE INDEX IF NOT EXISTS idx_deliberations_source_ref ON deliberations(source_ref);
CREATE INDEX IF NOT EXISTS idx_dspecs_delib ON deliberation_specs(deliberation_id);
CREATE INDEX IF NOT EXISTS idx_dspecs_spec ON deliberation_specs(spec_id);
CREATE INDEX IF NOT EXISTS idx_dwis_delib ON deliberation_work_items(deliberation_id);
CREATE INDEX IF NOT EXISTS idx_dwis_wi ON deliberation_work_items(work_item_id);
CREATE INDEX IF NOT EXISTS idx_canonical_terms_id_version ON canonical_terms(id, version);
CREATE INDEX IF NOT EXISTS idx_canonical_terms_authority ON canonical_terms(authority_level);
CREATE INDEX IF NOT EXISTS idx_canonical_terms_scope ON canonical_terms(scope);

-- Views: current state = latest version per ID
CREATE VIEW IF NOT EXISTS current_specifications AS
SELECT s.* FROM specifications s
INNER JOIN (SELECT id, MAX(version) AS max_v FROM specifications GROUP BY id) m
ON s.id = m.id AND s.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_test_procedures AS
SELECT t.* FROM test_procedures t
INNER JOIN (SELECT id, MAX(version) AS max_v FROM test_procedures GROUP BY id) m
ON t.id = m.id AND t.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_operational_procedures AS
SELECT o.* FROM operational_procedures o
INNER JOIN (SELECT id, MAX(version) AS max_v FROM operational_procedures GROUP BY id) m
ON o.id = m.id AND o.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_environment_config AS
SELECT e.* FROM environment_config e
INNER JOIN (SELECT id, MAX(version) AS max_v FROM environment_config GROUP BY id) m
ON e.id = m.id AND e.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_documents AS
SELECT d.* FROM documents d
INNER JOIN (SELECT id, MAX(version) AS max_v FROM documents GROUP BY id) m
ON d.id = m.id AND d.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_tests AS
SELECT t.* FROM tests t
INNER JOIN (SELECT id, MAX(version) AS max_v FROM tests GROUP BY id) m
ON t.id = m.id AND t.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_test_plans AS
SELECT t.* FROM test_plans t
INNER JOIN (SELECT id, MAX(version) AS max_v FROM test_plans GROUP BY id) m
ON t.id = m.id AND t.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_test_plan_phases AS
SELECT t.* FROM test_plan_phases t
INNER JOIN (SELECT id, MAX(version) AS max_v FROM test_plan_phases GROUP BY id) m
ON t.id = m.id AND t.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_work_items AS
SELECT w.* FROM work_items w
INNER JOIN (SELECT id, MAX(version) AS max_v FROM work_items GROUP BY id) m
ON w.id = m.id AND w.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_projects AS
SELECT p.* FROM projects p
INNER JOIN (SELECT id, MAX(version) AS max_v FROM projects GROUP BY id) m
ON p.id = m.id AND p.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_project_work_item_memberships AS
SELECT m.* FROM project_work_item_memberships m
INNER JOIN (
    SELECT id, MAX(version) AS max_v FROM project_work_item_memberships GROUP BY id
) latest
ON m.id = latest.id AND m.version = latest.max_v;

CREATE VIEW IF NOT EXISTS current_project_dependencies AS
SELECT d.* FROM project_dependencies d
INNER JOIN (SELECT id, MAX(version) AS max_v FROM project_dependencies GROUP BY id) m
ON d.id = m.id AND d.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_project_artifact_links AS
SELECT l.* FROM project_artifact_links l
INNER JOIN (SELECT id, MAX(version) AS max_v FROM project_artifact_links GROUP BY id) m
ON l.id = m.id AND l.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_project_authorizations AS
SELECT a.* FROM project_authorizations a
INNER JOIN (SELECT id, MAX(version) AS max_v FROM project_authorizations GROUP BY id) m
ON a.id = m.id AND a.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_flow_definitions AS
SELECT f.* FROM flow_definitions f
INNER JOIN (SELECT id, MAX(version) AS max_v FROM flow_definitions GROUP BY id) m
ON f.id = m.id AND f.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_flow_instances AS
SELECT f.* FROM flow_instances f
INNER JOIN (SELECT id, MAX(version) AS max_v FROM flow_instances GROUP BY id) m
ON f.id = m.id AND f.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_stage_instances AS
SELECT s.* FROM stage_instances s
INNER JOIN (SELECT id, MAX(version) AS max_v FROM stage_instances GROUP BY id) m
ON s.id = m.id AND s.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_stage_leases AS
SELECT l.* FROM stage_leases l
INNER JOIN (SELECT id, MAX(version) AS max_v FROM stage_leases GROUP BY id) m
ON l.id = m.id AND l.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_stage_attempt_telemetry AS
SELECT t.* FROM stage_attempt_telemetry t
INNER JOIN (SELECT id, MAX(version) AS max_v FROM stage_attempt_telemetry GROUP BY id) m
ON t.id = m.id AND t.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_agent_capability_snapshots AS
SELECT a.* FROM agent_capability_snapshots a
INNER JOIN (SELECT id, MAX(version) AS max_v FROM agent_capability_snapshots GROUP BY id) m
ON a.id = m.id AND a.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_backlog_snapshots AS
SELECT b.* FROM backlog_snapshots b
INNER JOIN (SELECT id, MAX(version) AS max_v FROM backlog_snapshots GROUP BY id) m
ON b.id = m.id AND b.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_testable_elements AS
SELECT t.* FROM testable_elements t
INNER JOIN (SELECT id, MAX(version) AS max_v FROM testable_elements GROUP BY id) m
ON t.id = m.id AND t.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_deliberations AS
SELECT d.* FROM deliberations d
INNER JOIN (SELECT id, MAX(version) AS max_v FROM deliberations GROUP BY id) m
ON d.id = m.id AND d.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_canonical_terms AS
SELECT c.* FROM canonical_terms c
INNER JOIN (SELECT id, MAX(version) AS max_v FROM canonical_terms GROUP BY id) m
ON c.id = m.id AND c.version = m.max_v;

CREATE VIEW IF NOT EXISTS current_harnesses AS
SELECT h.* FROM harnesses h
INNER JOIN (SELECT id, MAX(version) AS max_v FROM harnesses GROUP BY id) m
ON h.id = m.id AND h.version = m.max_v;

-- Phase 1 DB Instrumentation: KPI Suite Views
CREATE VIEW IF NOT EXISTS kpi_spec_test_mapping AS
WITH live_test_evidence AS (
    SELECT DISTINCT spec_id FROM test_coverage
    UNION
    SELECT DISTINCT spec_id FROM current_tests
    WHERE test_file IS NOT NULL
      AND TRIM(test_file) != ''
      AND COALESCE(last_result, '') NOT IN ('stale', 'historical_agent_red')
)
SELECT
    COUNT(DISTINCT s.id) AS total_specifications,
    SUM(CASE WHEN t.spec_id IS NOT NULL THEN 1 ELSE 0 END) AS mapped_specifications,
    SUM(CASE WHEN t.spec_id IS NULL THEN 1 ELSE 0 END) AS unmapped_specifications,
    (SUM(CASE WHEN t.spec_id IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(DISTINCT s.id)) AS spec_test_mapping_percentage
FROM current_specifications s
LEFT JOIN live_test_evidence t ON s.id = t.spec_id
WHERE s.status != 'retired';

CREATE VIEW IF NOT EXISTS kpi_deliberation_provenance AS
SELECT
    (SUM(CASE WHEN related_deliberation_ids IS NOT NULL OR source_owner_directive IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) AS deliberation_linkage_percentage,
    COUNT(*) AS total_work_items,
    SUM(CASE WHEN related_deliberation_ids IS NULL AND source_owner_directive IS NULL THEN 1 ELSE 0 END) AS unmapped_work_items
FROM current_work_items;

CREATE VIEW IF NOT EXISTS kpi_backlog_churn AS
SELECT
    (SUM(CASE WHEN resolution_status IN ('open', 'new', 'unresolved', 'in_progress') THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) AS active_churn_ratio,
    COUNT(*) AS total_work_items,
    SUM(CASE WHEN resolution_status IN ('open', 'new', 'unresolved', 'in_progress') THEN 1 ELSE 0 END) AS active_unresolved_items,
    SUM(CASE WHEN resolution_status IN ('completed', 'done', 'resolved', 'verified', 'fixed') THEN 1 ELSE 0 END) AS completed_items
FROM current_work_items;

-- Platform SoT Artifact Registry (GOV-PLATFORM-SOT-REGISTRY-001 + DCL-SOT-REGISTRY-PROJECTION-PARITY-001 + DCL-SOT-REGISTRY-RECORD-SCHEMA-001) -- MemBase projection of config/registry/sot-artifacts.toml; append-only versioned per UNIQUE(id, version).
CREATE TABLE IF NOT EXISTS sot_artifacts (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL,
    version INTEGER NOT NULL,
    domain TEXT NOT NULL,
    lifecycle TEXT NOT NULL,
    storage_path TEXT NOT NULL,
    authority_spec_id TEXT NOT NULL,
    mutation_api TEXT NOT NULL,
    versioning_policy TEXT NOT NULL,
    backup_policy TEXT NOT NULL,
    health_check_function TEXT,
    owner_role TEXT NOT NULL,
    depends_on TEXT,
    forbidden_substitutes TEXT,
    notes TEXT,
    changed_by TEXT NOT NULL,
    changed_at TEXT NOT NULL,
    change_reason TEXT NOT NULL,
    UNIQUE(id, version)
);

CREATE INDEX IF NOT EXISTS idx_sot_artifacts_id ON sot_artifacts(id);
CREATE INDEX IF NOT EXISTS idx_sot_artifacts_domain ON sot_artifacts(domain);
CREATE INDEX IF NOT EXISTS idx_sot_artifacts_lifecycle ON sot_artifacts(lifecycle);

CREATE VIEW IF NOT EXISTS current_sot_artifacts AS
SELECT s.* FROM sot_artifacts s
INNER JOIN (
    SELECT id, MAX(version) AS max_version FROM sot_artifacts GROUP BY id
) latest ON s.id = latest.id AND s.version = latest.max_version;

-- Work intent claims registry for bridge thread coordination
CREATE TABLE IF NOT EXISTS work_intent_claims (
    rowid INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_slug TEXT NOT NULL,
    session_id TEXT NOT NULL,
    acquired_at TEXT NOT NULL,
    ttl_expires_at TEXT NOT NULL,
    UNIQUE(thread_slug)
);

CREATE INDEX IF NOT EXISTS idx_work_intent_claims_slug ON work_intent_claims(thread_slug);
"""


def _now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def _parse_iso_utc(value: str) -> datetime:
    text = value[:-1] + "+00:00" if value.endswith("Z") else value
    parsed = datetime.fromisoformat(text)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _iso_plus_seconds(value: str, seconds: int) -> str:
    return (_parse_iso_utc(value) + timedelta(seconds=seconds)).isoformat(timespec="seconds")


def spec_sort_key(spec_id: str) -> tuple[Any, ...]:
    """Convert decimal ID to tuple for correct numeric ordering.

    "245" → (1, 245,), "245.2" → (1, 245, 2), "245.10" → (1, 245, 10)
    "PB-001" → (0, "PB-001")   (prefix-based IDs sort before numeric IDs)

    This ensures 245.2 sorts before 245.10 (unlike lexicographic TEXT sort),
    and non-numeric IDs (like PB-*) sort into their own group at the top.
    """
    try:
        return (1,) + tuple(int(x) for x in spec_id.split("."))
    except (ValueError, AttributeError):
        # Non-numeric IDs (PB-001, etc.) — sort lexicographically in group 0
        return (0, spec_id)


def get_parent_id(spec_id: str) -> str | None:
    """Return parent ID by stripping the last decimal segment.

    "245.1.3" → "245.1", "245.1" → "245", "245" → None
    """
    parts = spec_id.rsplit(".", 1)
    return parts[0] if len(parts) > 1 else None


def get_depth(spec_id: str) -> int:
    """Return nesting depth: "245" → 0, "245.1" → 1, "245.1.3" → 2."""
    return spec_id.count(".")


# --- F1: Schema Enrichment sentinels and validators ---


class _UnsetSentinel:
    def __repr__(self) -> str:
        return "<UNSET>"


class _CarryForwardSentinel:
    def __repr__(self) -> str:
        return "<CARRY_FORWARD>"


_UNSET = _UnsetSentinel()  # Sentinel: caller did not provide this argument
_CARRY_FORWARD = _CarryForwardSentinel()  # Sentinel: carry forward from previous version (update only)


def _is_unset(val: Any) -> bool:
    cls = getattr(val, "__class__", None)
    return val is _UNSET or (cls is not None and cls.__name__ == "_UnsetSentinel")


def _is_carry_forward(val: Any) -> bool:
    cls = getattr(val, "__class__", None)
    return val is _CARRY_FORWARD or (cls is not None and cls.__name__ == "_CarryForwardSentinel")


_VALID_AUTHORITIES = frozenset({"stated", "inferred", "provisional", "inherited", "unknown"})
_VALID_TESTABILITIES = frozenset({"automatable", "observable", "structural", "untestable"})
_VALID_COMPLEXITY_CEILINGS = frozenset({"simple", "moderate", "complex"})
_VALID_DECISION_AUTHORITIES = frozenset({"owner", "ai", "either"})


def _normalize_provisional(authority: Any, provisional_until: Any) -> tuple[Any, Any]:
    """Enforce provisional lifecycle invariants INV-1 through INV-4.

    Returns (authority, provisional_until) after normalization.
    """
    if provisional_until is not None:
        if _is_unset(authority) or authority is None:
            authority = "provisional"
        elif authority != "provisional":
            raise ValueError(f"provisional_until requires authority='provisional', got {authority!r}")
    else:
        if authority is not None and not _is_unset(authority) and authority == "provisional":
            raise ValueError("authority='provisional' requires provisional_until to be set")
    return authority, provisional_until


def _validate_authority(authority: str) -> None:
    """Validate authority is one of the approved enum values."""
    if authority not in _VALID_AUTHORITIES:
        raise ValueError(f"Invalid authority: {authority!r}. Must be one of {sorted(_VALID_AUTHORITIES)}")


def _validate_testability(testability: str) -> None:
    """Validate testability is one of the approved enum values."""
    if testability not in _VALID_TESTABILITIES:
        raise ValueError(f"Invalid testability: {testability!r}. Must be one of {sorted(_VALID_TESTABILITIES)}")


def _validate_constraints(constraints: Any) -> None:
    """Validate constraints is None or a dict with approved known-key rules."""
    if constraints is None:
        return
    if not isinstance(constraints, dict):
        raise ValueError(f"constraints must be a dict, got {type(constraints).__name__}")
    cc = constraints.get("complexity_ceiling")
    if cc is not None and cc not in _VALID_COMPLEXITY_CEILINGS:
        raise ValueError(
            f"constraints.complexity_ceiling must be one of {sorted(_VALID_COMPLEXITY_CEILINGS)}, got {cc!r}"
        )
    da = constraints.get("decision_authority")
    if da is not None and da not in _VALID_DECISION_AUTHORITIES:
        raise ValueError(
            f"constraints.decision_authority must be one of {sorted(_VALID_DECISION_AUTHORITIES)}, got {da!r}"
        )
    ea = constraints.get("excluded_approaches")
    if ea is not None:
        if not isinstance(ea, list):
            raise ValueError(f"constraints.excluded_approaches must be a list, got {type(ea).__name__}")
        for i, item in enumerate(ea):
            if not isinstance(item, str):
                raise ValueError(f"constraints.excluded_approaches[{i}] must be a string, got {type(item).__name__}")


def _validate_affected_by(affected_by: Any) -> None:
    """Validate affected_by is None or a list of strings."""
    if affected_by is None:
        return
    if not isinstance(affected_by, list):
        raise ValueError(f"affected_by must be a list, got {type(affected_by).__name__}")
    for i, item in enumerate(affected_by):
        if not isinstance(item, str):
            raise ValueError(f"affected_by[{i}] must be a string, got {type(item).__name__}")


def _validate_provisional_until(provisional_until: Any) -> None:
    """Validate provisional_until is None or a non-empty spec ID string."""
    if provisional_until is not None:
        if not isinstance(provisional_until, str) or not provisional_until.strip():
            raise ValueError("provisional_until must be a non-empty string")


def _stable_slug(value: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9]+", "-", value.upper()).strip("-")
    return slug or "UNNAMED"


def _project_id_from_names(project_name: str, subproject_name: str | None = None) -> str:
    slug = _stable_slug(project_name)
    # Idempotent prefix: a caller may pass either a bare project name
    # ("GTKB-RELIABILITY-FIXES") or an already-qualified project id
    # ("PROJECT-GTKB-RELIABILITY-FIXES"). Only prepend "PROJECT-" when the
    # slug does not already carry it, so an already-qualified id is not
    # doubled into "PROJECT-PROJECT-*".
    base = slug if slug.startswith("PROJECT-") else f"PROJECT-{slug}"
    if subproject_name and subproject_name.strip():
        return f"{base}-{_stable_slug(subproject_name)}"
    return base


def _stable_project_link_id(prefix: str, *parts: str) -> str:
    return f"{prefix}-{'-'.join(_stable_slug(part) for part in parts if part)}"


class KnowledgeDB:
    """Append-only knowledge database."""

    def __init__(
        self,
        db_path: str | Path | None = None,
        gate_registry: GateRegistry | None = None,
        check_same_thread: bool = True,
        chroma_path: str | Path | None = None,
    ):
        self.db_path = Path(db_path) if db_path else DB_PATH
        self._chroma_path = Path(chroma_path) if chroma_path else None
        self._conn: sqlite3.Connection | None = None
        self._gate_registry = gate_registry
        self._check_same_thread = check_same_thread
        self._last_deliberation_search_status: dict[str, Any] = {
            "semantic_expected": bool(HAS_CHROMADB),
            "semantic_attempted": False,
            "semantic_succeeded": False,
            "semantic_degraded": False,
            "degradation_reason": None,
        }
        self._ensure_schema()

    def _deliberation_search_status(self) -> dict[str, Any]:
        """Return metadata for the most recent ``search_deliberations`` call."""
        return dict(self._last_deliberation_search_status)

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(
                str(self.db_path),
                check_same_thread=self._check_same_thread,
            )
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
        return self._conn

    def _ensure_schema(self) -> None:
        conn = self._get_conn()
        conn.executescript(SCHEMA_SQL)
        conn.commit()
        self._migrate_schema()

    def _migrate_schema(self) -> None:
        """Apply incremental migrations that cannot be expressed as CREATE IF NOT EXISTS."""
        conn = self._get_conn()
        # Migration 1: Add 'type' column to specifications (S113)
        cols = {row[1] for row in conn.execute("PRAGMA table_info(specifications)").fetchall()}
        if "type" not in cols:
            conn.execute("ALTER TABLE specifications ADD COLUMN type TEXT DEFAULT 'requirement'")
            # Backfill based on ID patterns
            conn.execute("UPDATE specifications SET type = 'governance' WHERE id LIKE 'GOV-%'")
            conn.execute("UPDATE specifications SET type = 'protected_behavior' WHERE id LIKE 'PB-%'")
            conn.commit()
            _log.debug("Applied migration: add type column to specifications")

        # Migration 2: Backfill architecture_decision and design_constraint types (GOV-20 Phase 1)
        conn.execute(
            "UPDATE specifications SET type = 'architecture_decision' WHERE id LIKE 'ADR-%' AND type = 'requirement'"
        )
        conn.execute(
            "UPDATE specifications SET type = 'design_constraint' WHERE id LIKE 'DCL-%' AND type = 'requirement'"
        )
        conn.commit()

        # Migration 3: F1 Schema Enrichment — add 5 new columns to specifications
        cols = {row[1] for row in conn.execute("PRAGMA table_info(specifications)").fetchall()}
        f1_columns = {
            "authority": "TEXT",
            "provisional_until": "TEXT",
            "constraints": "TEXT",
            "affected_by": "TEXT",
            "testability": "TEXT",
        }
        added_f1 = []
        for col_name, col_type in f1_columns.items():
            if col_name not in cols:
                conn.execute(f"ALTER TABLE specifications ADD COLUMN {col_name} {col_type}")
                added_f1.append(col_name)
        conn.commit()
        if added_f1:
            _log.debug("Applied migration: F1 schema enrichment columns %s", added_f1)

        # Migration 4: Add source_paths column for spec-before-code governance hook
        cols = {row[1] for row in conn.execute("PRAGMA table_info(specifications)").fetchall()}
        if "source_paths" not in cols:
            conn.execute("ALTER TABLE specifications ADD COLUMN source_paths TEXT DEFAULT NULL")
            conn.commit()
            _log.debug("Applied migration: add source_paths column")

        # Migration 5: lifecycle schema additions.
        cols = {row[1] for row in conn.execute("PRAGMA table_info(specifications)").fetchall()}
        lifecycle_columns = {
            "implementation_verified_at": "TEXT",
            "retired_at": "TEXT",
            "parent": "TEXT",
        }
        added_lifecycle_cols = []
        for col_name, col_type in lifecycle_columns.items():
            if col_name not in cols:
                conn.execute(f"ALTER TABLE specifications ADD COLUMN {col_name} {col_type}")
                added_lifecycle_cols.append(col_name)
        conn.commit()
        if added_lifecycle_cols:
            _log.debug("Applied migration: lifecycle schema columns %s", added_lifecycle_cols)

        # Migration 6: unify backlog metadata onto work_items.
        cols = {row[1] for row in conn.execute("PRAGMA table_info(work_items)").fetchall()}
        added_work_item_cols = []
        for col_name, col_type in WORK_ITEM_BACKLOG_COLUMNS.items():
            if col_name not in cols:
                conn.execute(f"ALTER TABLE work_items ADD COLUMN {col_name} {col_type}")
                added_work_item_cols.append(col_name)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_work_items_project ON work_items(project_name)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_work_items_order ON work_items(implementation_order)")
        conn.commit()
        if added_work_item_cols:
            _log.debug("Applied migration: unified backlog work item columns %s", added_work_item_cols)

        # Migration 7: first-class project layer over canonical work_items.
        self._backfill_project_artifacts_from_work_items()

        # Migration 8: TAFE flow definition schema compatibility.
        flow_cols = {row[1] for row in conn.execute("PRAGMA table_info(flow_definitions)").fetchall()}
        flow_definition_columns = {
            "title": "TEXT",
            "name": "TEXT",
            "status": "TEXT",
            "lifecycle_status": "TEXT",
            "stage_sequence": "TEXT",
            "stages": "TEXT",
            "required_roles_by_stage": "TEXT",
            "required_roles": "TEXT",
            "auq_gate_positions": "TEXT",
            "never_self_review_stages": "TEXT",
            "never_self_review_points": "TEXT",
            "deterministic_carve_outs": "TEXT",
            "deterministic_carveouts": "TEXT",
            "workspace_isolation": "TEXT",
            "source_spec_ids": "TEXT",
        }
        added_flow_cols = []
        for col_name, col_type in flow_definition_columns.items():
            if col_name not in flow_cols:
                conn.execute(f"ALTER TABLE flow_definitions ADD COLUMN {col_name} {col_type}")
                added_flow_cols.append(col_name)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_flow_definitions_status ON flow_definitions(status)")
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_flow_definitions_lifecycle_status ON flow_definitions(lifecycle_status)"
        )
        conn.commit()
        if added_flow_cols:
            _log.debug("Applied migration: TAFE flow definition columns %s", added_flow_cols)

        # Migration 9: TAFE runtime table substrate.
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS flow_instances (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                id TEXT NOT NULL,
                version INTEGER NOT NULL,
                flow_definition_id TEXT NOT NULL,
                flow_definition_version INTEGER,
                flow_type TEXT,
                subject_type TEXT NOT NULL,
                subject_id TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'created',
                current_stage_instance_id TEXT,
                started_at TEXT,
                completed_at TEXT,
                metadata TEXT,
                changed_by TEXT NOT NULL,
                changed_at TEXT NOT NULL,
                change_reason TEXT NOT NULL,
                UNIQUE(id, version)
            );
            CREATE TABLE IF NOT EXISTS stage_instances (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                id TEXT NOT NULL,
                version INTEGER NOT NULL,
                flow_instance_id TEXT NOT NULL,
                stage_id TEXT NOT NULL,
                stage_index INTEGER NOT NULL,
                required_role TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                claim_status TEXT NOT NULL DEFAULT 'unclaimed',
                claimed_by_harness_id TEXT,
                claimed_by_session_id TEXT,
                started_at TEXT,
                completed_at TEXT,
                metadata TEXT,
                changed_by TEXT NOT NULL,
                changed_at TEXT NOT NULL,
                change_reason TEXT NOT NULL,
                UNIQUE(id, version)
            );
            CREATE TABLE IF NOT EXISTS flow_events (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                id TEXT NOT NULL,
                flow_instance_id TEXT NOT NULL,
                stage_instance_id TEXT,
                event_type TEXT NOT NULL,
                event_at TEXT NOT NULL,
                event_payload TEXT,
                changed_by TEXT NOT NULL,
                changed_at TEXT NOT NULL,
                change_reason TEXT NOT NULL,
                UNIQUE(id)
            );
            CREATE TABLE IF NOT EXISTS flow_artifacts (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                id TEXT NOT NULL,
                flow_instance_id TEXT NOT NULL,
                stage_instance_id TEXT,
                artifact_type TEXT NOT NULL,
                artifact_ref TEXT NOT NULL,
                relationship TEXT NOT NULL DEFAULT 'related',
                status TEXT NOT NULL DEFAULT 'active',
                metadata TEXT,
                changed_by TEXT NOT NULL,
                changed_at TEXT NOT NULL,
                change_reason TEXT NOT NULL,
                UNIQUE(id)
            );
            """
        )
        runtime_table_columns = {
            "flow_instances": {
                "id": "TEXT",
                "version": "INTEGER",
                "flow_definition_id": "TEXT",
                "flow_definition_version": "INTEGER",
                "flow_type": "TEXT",
                "subject_type": "TEXT",
                "subject_id": "TEXT",
                "status": "TEXT",
                "current_stage_instance_id": "TEXT",
                "started_at": "TEXT",
                "completed_at": "TEXT",
                "metadata": "TEXT",
                "changed_by": "TEXT",
                "changed_at": "TEXT",
                "change_reason": "TEXT",
            },
            "stage_instances": {
                "id": "TEXT",
                "version": "INTEGER",
                "flow_instance_id": "TEXT",
                "stage_id": "TEXT",
                "stage_index": "INTEGER",
                "required_role": "TEXT",
                "status": "TEXT",
                "claim_status": "TEXT",
                "claimed_by_harness_id": "TEXT",
                "claimed_by_session_id": "TEXT",
                "started_at": "TEXT",
                "completed_at": "TEXT",
                "metadata": "TEXT",
                "changed_by": "TEXT",
                "changed_at": "TEXT",
                "change_reason": "TEXT",
            },
            "flow_events": {
                "id": "TEXT",
                "flow_instance_id": "TEXT",
                "stage_instance_id": "TEXT",
                "event_type": "TEXT",
                "event_at": "TEXT",
                "event_payload": "TEXT",
                "changed_by": "TEXT",
                "changed_at": "TEXT",
                "change_reason": "TEXT",
            },
            "flow_artifacts": {
                "id": "TEXT",
                "flow_instance_id": "TEXT",
                "stage_instance_id": "TEXT",
                "artifact_type": "TEXT",
                "artifact_ref": "TEXT",
                "relationship": "TEXT",
                "status": "TEXT",
                "metadata": "TEXT",
                "changed_by": "TEXT",
                "changed_at": "TEXT",
                "change_reason": "TEXT",
            },
        }
        added_runtime_cols: dict[str, list[str]] = {}
        for table, columns in runtime_table_columns.items():
            table_cols = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
            for col_name, col_type in columns.items():
                if col_name not in table_cols:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}")
                    added_runtime_cols.setdefault(table, []).append(col_name)
        conn.executescript(
            """
            CREATE INDEX IF NOT EXISTS idx_flow_instances_id_version ON flow_instances(id, version);
            CREATE INDEX IF NOT EXISTS idx_flow_instances_definition ON flow_instances(flow_definition_id);
            CREATE INDEX IF NOT EXISTS idx_flow_instances_status ON flow_instances(status);
            CREATE INDEX IF NOT EXISTS idx_stage_instances_id_version ON stage_instances(id, version);
            CREATE INDEX IF NOT EXISTS idx_stage_instances_flow ON stage_instances(flow_instance_id);
            CREATE INDEX IF NOT EXISTS idx_stage_instances_status ON stage_instances(status);
            CREATE INDEX IF NOT EXISTS idx_flow_events_flow ON flow_events(flow_instance_id, rowid);
            CREATE INDEX IF NOT EXISTS idx_flow_events_stage ON flow_events(stage_instance_id, rowid);
            CREATE INDEX IF NOT EXISTS idx_flow_events_type ON flow_events(event_type);
            CREATE INDEX IF NOT EXISTS idx_flow_artifacts_flow ON flow_artifacts(flow_instance_id, rowid);
            CREATE INDEX IF NOT EXISTS idx_flow_artifacts_artifact ON flow_artifacts(artifact_type, artifact_ref);
            CREATE VIEW IF NOT EXISTS current_flow_instances AS
            SELECT f.* FROM flow_instances f
            INNER JOIN (SELECT id, MAX(version) AS max_v FROM flow_instances GROUP BY id) m
            ON f.id = m.id AND f.version = m.max_v;
            CREATE VIEW IF NOT EXISTS current_stage_instances AS
            SELECT s.* FROM stage_instances s
            INNER JOIN (SELECT id, MAX(version) AS max_v FROM stage_instances GROUP BY id) m
            ON s.id = m.id AND s.version = m.max_v;
            """
        )
        conn.commit()
        if added_runtime_cols:
            _log.debug("Applied migration: TAFE runtime table columns %s", added_runtime_cols)

        # Migration 10: TAFE stage lease table substrate.
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS stage_leases (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                id TEXT NOT NULL,
                version INTEGER NOT NULL,
                stage_instance_id TEXT NOT NULL,
                holder_harness_id TEXT NOT NULL,
                holder_session_id TEXT NOT NULL,
                lease_status TEXT NOT NULL DEFAULT 'active',
                acquired_at TEXT NOT NULL,
                heartbeat_at TEXT,
                ttl_seconds INTEGER NOT NULL,
                expires_at TEXT,
                released_at TEXT,
                metadata TEXT,
                changed_by TEXT NOT NULL,
                changed_at TEXT NOT NULL,
                change_reason TEXT NOT NULL,
                UNIQUE(id, version)
            );
            """
        )
        stage_lease_columns = {
            "id": "TEXT",
            "version": "INTEGER",
            "stage_instance_id": "TEXT",
            "holder_harness_id": "TEXT",
            "holder_session_id": "TEXT",
            "lease_status": "TEXT",
            "acquired_at": "TEXT",
            "heartbeat_at": "TEXT",
            "ttl_seconds": "INTEGER",
            "expires_at": "TEXT",
            "released_at": "TEXT",
            "metadata": "TEXT",
            "changed_by": "TEXT",
            "changed_at": "TEXT",
            "change_reason": "TEXT",
        }
        existing_lease_cols = {row[1] for row in conn.execute("PRAGMA table_info(stage_leases)").fetchall()}
        added_lease_cols = []
        for col_name, col_type in stage_lease_columns.items():
            if col_name not in existing_lease_cols:
                conn.execute(f"ALTER TABLE stage_leases ADD COLUMN {col_name} {col_type}")
                added_lease_cols.append(col_name)
        conn.executescript(
            """
            CREATE INDEX IF NOT EXISTS idx_stage_leases_id_version ON stage_leases(id, version);
            CREATE INDEX IF NOT EXISTS idx_stage_leases_stage ON stage_leases(stage_instance_id);
            CREATE INDEX IF NOT EXISTS idx_stage_leases_status ON stage_leases(lease_status);
            CREATE INDEX IF NOT EXISTS idx_stage_leases_holder ON stage_leases(holder_harness_id, holder_session_id);
            CREATE INDEX IF NOT EXISTS idx_stage_leases_heartbeat ON stage_leases(heartbeat_at);
            CREATE VIEW IF NOT EXISTS current_stage_leases AS
            SELECT l.* FROM stage_leases l
            INNER JOIN (SELECT id, MAX(version) AS max_v FROM stage_leases GROUP BY id) m
            ON l.id = m.id AND l.version = m.max_v;
            """
        )
        conn.commit()
        if added_lease_cols:
            _log.debug("Applied migration: TAFE stage lease columns %s", added_lease_cols)

        # Migration 11: TAFE agent capability snapshot table substrate.
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS agent_capability_snapshots (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                id TEXT NOT NULL,
                version INTEGER NOT NULL,
                harness_id TEXT NOT NULL,
                harness_name TEXT,
                role TEXT NOT NULL,
                subject_scope TEXT,
                health_status TEXT NOT NULL DEFAULT 'unknown',
                reviewer_precedence INTEGER,
                workspace_availability TEXT,
                model_identifier TEXT,
                capabilities TEXT,
                captured_at TEXT NOT NULL,
                source TEXT,
                status TEXT NOT NULL DEFAULT 'active',
                metadata TEXT,
                changed_by TEXT NOT NULL,
                changed_at TEXT NOT NULL,
                change_reason TEXT NOT NULL,
                UNIQUE(id, version)
            );
            """
        )
        capability_snapshot_columns = {
            "id": "TEXT",
            "version": "INTEGER",
            "harness_id": "TEXT",
            "harness_name": "TEXT",
            "role": "TEXT",
            "subject_scope": "TEXT",
            "health_status": "TEXT",
            "reviewer_precedence": "INTEGER",
            "workspace_availability": "TEXT",
            "model_identifier": "TEXT",
            "capabilities": "TEXT",
            "captured_at": "TEXT",
            "source": "TEXT",
            "status": "TEXT",
            "metadata": "TEXT",
            "changed_by": "TEXT",
            "changed_at": "TEXT",
            "change_reason": "TEXT",
        }
        existing_capability_cols = {
            row[1] for row in conn.execute("PRAGMA table_info(agent_capability_snapshots)").fetchall()
        }
        added_capability_cols = []
        for col_name, col_type in capability_snapshot_columns.items():
            if col_name not in existing_capability_cols:
                conn.execute(f"ALTER TABLE agent_capability_snapshots ADD COLUMN {col_name} {col_type}")
                added_capability_cols.append(col_name)
        conn.executescript(
            """
            CREATE INDEX IF NOT EXISTS idx_agent_capability_snapshots_id_version ON agent_capability_snapshots(id, version);
            CREATE INDEX IF NOT EXISTS idx_agent_capability_snapshots_harness ON agent_capability_snapshots(harness_id);
            CREATE INDEX IF NOT EXISTS idx_agent_capability_snapshots_health ON agent_capability_snapshots(health_status);
            CREATE INDEX IF NOT EXISTS idx_agent_capability_snapshots_captured ON agent_capability_snapshots(captured_at);
            CREATE VIEW IF NOT EXISTS current_agent_capability_snapshots AS
            SELECT a.* FROM agent_capability_snapshots a
            INNER JOIN (SELECT id, MAX(version) AS max_v FROM agent_capability_snapshots GROUP BY id) m
            ON a.id = m.id AND a.version = m.max_v;
            """
        )
        conn.commit()
        if added_capability_cols:
            _log.debug("Applied migration: TAFE agent capability snapshot columns %s", added_capability_cols)

        # Migration 12: TAFE per-stage-attempt telemetry table substrate (WI-4504, SPEC-TAFE-R6).
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS stage_attempt_telemetry (
                rowid INTEGER PRIMARY KEY AUTOINCREMENT,
                id TEXT NOT NULL,
                version INTEGER NOT NULL,
                flow_instance_id TEXT NOT NULL,
                stage_instance_id TEXT NOT NULL,
                attempt_number INTEGER,
                agent_harness_id TEXT,
                agent_session_id TEXT,
                agent_context_id TEXT,
                model_identifier TEXT,
                provider TEXT,
                dispatch_decision TEXT,
                lease_id TEXT,
                lease_lifecycle TEXT,
                started_at TEXT,
                completed_at TEXT,
                duration_ms INTEGER,
                token_count INTEGER,
                cost REAL,
                outcome TEXT,
                verdict TEXT,
                test_summary TEXT,
                failure_class TEXT,
                cleanup_result TEXT,
                recovery_actions TEXT,
                artifact_links TEXT,
                status TEXT NOT NULL DEFAULT 'active',
                metadata TEXT,
                changed_by TEXT NOT NULL,
                changed_at TEXT NOT NULL,
                change_reason TEXT NOT NULL,
                UNIQUE(id, version)
            );
            """
        )
        stage_attempt_telemetry_columns = {
            "id": "TEXT",
            "version": "INTEGER",
            "flow_instance_id": "TEXT",
            "stage_instance_id": "TEXT",
            "attempt_number": "INTEGER",
            "agent_harness_id": "TEXT",
            "agent_session_id": "TEXT",
            "agent_context_id": "TEXT",
            "model_identifier": "TEXT",
            "provider": "TEXT",
            "dispatch_decision": "TEXT",
            "lease_id": "TEXT",
            "lease_lifecycle": "TEXT",
            "started_at": "TEXT",
            "completed_at": "TEXT",
            "duration_ms": "INTEGER",
            "token_count": "INTEGER",
            "cost": "REAL",
            "outcome": "TEXT",
            "verdict": "TEXT",
            "test_summary": "TEXT",
            "failure_class": "TEXT",
            "cleanup_result": "TEXT",
            "recovery_actions": "TEXT",
            "artifact_links": "TEXT",
            "status": "TEXT",
            "metadata": "TEXT",
            "changed_by": "TEXT",
            "changed_at": "TEXT",
            "change_reason": "TEXT",
        }
        existing_telemetry_cols = {
            row[1] for row in conn.execute("PRAGMA table_info(stage_attempt_telemetry)").fetchall()
        }
        added_telemetry_cols = []
        for col_name, col_type in stage_attempt_telemetry_columns.items():
            if col_name not in existing_telemetry_cols:
                conn.execute(f"ALTER TABLE stage_attempt_telemetry ADD COLUMN {col_name} {col_type}")
                added_telemetry_cols.append(col_name)
        conn.executescript(
            """
            CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_id_version ON stage_attempt_telemetry(id, version);
            CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_flow ON stage_attempt_telemetry(flow_instance_id);
            CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_stage ON stage_attempt_telemetry(stage_instance_id);
            CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_outcome ON stage_attempt_telemetry(outcome);
            CREATE INDEX IF NOT EXISTS idx_stage_attempt_telemetry_failure_class ON stage_attempt_telemetry(failure_class);
            CREATE VIEW IF NOT EXISTS current_stage_attempt_telemetry AS
            SELECT t.* FROM stage_attempt_telemetry t
            INNER JOIN (SELECT id, MAX(version) AS max_v FROM stage_attempt_telemetry GROUP BY id) m
            ON t.id = m.id AND t.version = m.max_v;
            """
        )
        conn.commit()
        if added_telemetry_cols:
            _log.debug("Applied migration: TAFE stage attempt telemetry columns %s", added_telemetry_cols)

    def _backfill_project_artifacts_from_work_items(self) -> None:
        """Backfill project rows from compatibility work-item project strings.

        This keeps ``work_items`` / ``current_work_items`` as the canonical
        backlog authority and creates only organizing project records plus
        memberships. The migration is idempotent and never deletes rows.
        """
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT id, project_name, subproject_name, implementation_order
               FROM current_work_items
               WHERE project_name IS NOT NULL AND TRIM(project_name) <> ''
               ORDER BY project_name, subproject_name, implementation_order IS NULL, implementation_order, id"""
        ).fetchall()
        changed = False
        now = _now()
        for row in rows:
            project_name = str(row["project_name"]).strip()
            subproject_name = str(row["subproject_name"]).strip() if row["subproject_name"] else None
            work_item_id = str(row["id"])
            order = row["implementation_order"]
            project_id = _project_id_from_names(project_name)
            if not self._project_exists(project_id):
                conn.execute(
                    """INSERT INTO projects
                       (id, version, name, status, rank, parent_project_id, purpose, target_outcome,
                        scope_note, start_date, target_date, completed_at, notes, source_project_name,
                        source_subproject_name, changed_by, changed_at, change_reason)
                       VALUES (?, 1, ?, 'active', ?, NULL, NULL, NULL, ?, NULL, NULL, NULL, NULL, ?, NULL,
                               'project-backfill', ?, ?)""",
                    (
                        project_id,
                        project_name,
                        order,
                        "Backfilled from current_work_items.project_name compatibility field.",
                        project_name,
                        now,
                        "Create first-class project record from work_items.project_name compatibility data.",
                    ),
                )
                changed = True
            changed = (
                self._insert_project_membership_if_missing(
                    project_id=project_id,
                    work_item_id=work_item_id,
                    membership_role="member",
                    membership_order=order,
                    source="work_items.project_name",
                    changed_by="project-backfill",
                    change_reason="Backfill project membership from work_items.project_name compatibility data.",
                    changed_at=now,
                )
                or changed
            )

            if subproject_name:
                subproject_id = _project_id_from_names(project_name, subproject_name)
                if not self._project_exists(subproject_id):
                    conn.execute(
                        """INSERT INTO projects
                           (id, version, name, status, rank, parent_project_id, purpose, target_outcome,
                            scope_note, start_date, target_date, completed_at, notes, source_project_name,
                            source_subproject_name, changed_by, changed_at, change_reason)
                           VALUES (?, 1, ?, 'active', ?, ?, NULL, NULL, ?, NULL, NULL, NULL, NULL, ?, ?,
                                   'project-backfill', ?, ?)""",
                        (
                            subproject_id,
                            subproject_name,
                            order,
                            project_id,
                            "Backfilled from current_work_items.subproject_name compatibility field.",
                            project_name,
                            subproject_name,
                            now,
                            "Create first-class subproject record from work_items.subproject_name compatibility data.",
                        ),
                    )
                    changed = True
                changed = (
                    self._insert_project_membership_if_missing(
                        project_id=subproject_id,
                        work_item_id=work_item_id,
                        membership_role="subproject_member",
                        membership_order=order,
                        source="work_items.subproject_name",
                        changed_by="project-backfill",
                        change_reason="Backfill project membership from work_items.subproject_name compatibility data.",
                        changed_at=now,
                    )
                    or changed
                )
        if changed:
            conn.commit()

    def _project_exists(self, project_id: str) -> bool:
        row = self._get_conn().execute("SELECT 1 FROM current_projects WHERE id = ?", (project_id,)).fetchone()
        return row is not None

    def _project_membership_exists(self, membership_id: str) -> bool:
        row = (
            self._get_conn()
            .execute("SELECT 1 FROM current_project_work_item_memberships WHERE id = ?", (membership_id,))
            .fetchone()
        )
        return row is not None

    def _insert_project_membership_if_missing(
        self,
        *,
        project_id: str,
        work_item_id: str,
        membership_role: str,
        membership_order: int | None,
        source: str,
        changed_by: str,
        change_reason: str,
        changed_at: str | None = None,
    ) -> bool:
        membership_id = _stable_project_link_id("PWM", project_id, work_item_id)
        if self._project_membership_exists(membership_id):
            return False
        self._get_conn().execute(
            """INSERT INTO project_work_item_memberships
               (id, version, project_id, work_item_id, membership_role, membership_order, status,
                source, changed_by, changed_at, change_reason)
               VALUES (?, 1, ?, ?, ?, ?, 'active', ?, ?, ?, ?)""",
            (
                membership_id,
                project_id,
                work_item_id,
                membership_role,
                membership_order,
                source,
                changed_by,
                changed_at or _now(),
                change_reason,
            ),
        )
        return True

    @staticmethod
    def _auto_detect_spec_type(spec_id: str, declared_type: str) -> str:
        """Auto-detect spec type from ID prefix when declared as default 'requirement'."""
        if declared_type != "requirement":
            return declared_type
        prefix_map = {
            "GOV-": "governance",
            "PB-": "protected_behavior",
            "ADR-": "architecture_decision",
            "DCL-": "design_constraint",
        }
        for prefix, spec_type in prefix_map.items():
            if spec_id.startswith(prefix):
                return spec_type
        return declared_type

    def close(self) -> None:
        """Close the underlying SQLite connection.

        Closes the active SQLite connection and releases it. The connection
        is lazily re-opened on the next database operation, so calling
        ``close()`` does not permanently invalidate the instance. Safe to
        call multiple times — a no-op if no connection is currently open.

        Note: ``close()`` does not touch the ChromaDB client. ChromaDB
        resources are managed separately and are not released by this call.
        """
        if self._conn:
            self._conn.close()
            self._conn = None

    # ------------------------------------------------------------------
    # Specifications
    # ------------------------------------------------------------------

    def _next_spec_version(self, spec_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM specifications WHERE id = ?", (spec_id,)).fetchone()
        return (row[0] or 0) + 1

    def insert_spec(
        self,
        id: str,
        title: str,
        status: str,
        changed_by: str,
        change_reason: str,
        *,
        description: str | None = None,
        priority: str | None = None,
        scope: str | None = None,
        section: str | None = None,
        handle: str | None = None,
        tags: list[str] | None = None,
        assertions: list[dict[str, Any]] | None = None,
        type: str = "requirement",
        validate_assertions: bool = True,
        authority: Any = _UNSET,
        provisional_until: str | None = None,
        constraints: dict[str, Any] | None = None,
        affected_by: list[str] | None = None,
        testability: str | None = None,
        source_paths: list[str] | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of a specification.

        Args:
            type: Specification type — 'requirement', 'governance', 'protected_behavior',
                  'architecture_decision', or 'design_constraint'.
                  Auto-detected from ID prefix (GOV-*, PB-*, ADR-*, DCL-*) when left
                  as default 'requirement'.
            validate_assertions: If True (default), validate assertion definitions
                  before writing. Set False only for tested migration tooling.
            authority: Spec authority — 'stated', 'inferred', 'provisional', 'inherited',
                  or 'unknown'. Defaults to 'stated' on new insert when omitted.
            provisional_until: Spec ID this provisional spec is waiting on. Requires
                  authority='provisional' (auto-set if authority omitted).
            constraints: JSON-serializable dict of constraints metadata.
            affected_by: List of spec/ADR/DCL IDs that affect this spec.
            testability: Testability classification — 'automatable', 'observable',
                  'structural', or 'untestable'.
            source_paths: Optional list of relative file paths or glob patterns this spec
                  covers. JSON-encoded into the source_paths TEXT column. Used by the
                  spec-before-code governance hook.
        """
        type = self._auto_detect_spec_type(id, type)

        # Validate assertions at write time
        if validate_assertions and assertions:
            from groundtruth_kb.assertion_schema import validate_assertion_list

            errors = validate_assertion_list(assertions)
            if errors:
                raise ValueError(f"Invalid assertions for {id}: {'; '.join(errors)}")

        # F1: Normalize provisional lifecycle FIRST (while _UNSET preserved)
        authority, provisional_until = _normalize_provisional(authority, provisional_until)
        # F1: Apply new-insert default AFTER normalization
        if _is_unset(authority):
            authority = "stated"
        # F1: Validate enriched fields
        if authority is not None:
            _validate_authority(authority)
        if testability is not None:
            _validate_testability(testability)
        _validate_constraints(constraints)
        _validate_affected_by(affected_by)
        _validate_provisional_until(provisional_until)
        # F1: Serialize JSON fields
        constraints_json = json.dumps(constraints) if constraints is not None else None
        affected_by_json = json.dumps(affected_by) if affected_by is not None else None
        source_paths_json = json.dumps(source_paths) if source_paths is not None else None

        # Run governance gates on initial insert (for status enforcement)
        if self._gate_registry is not None:
            spec_data: dict[str, Any] = {
                "type": type,
                "assertions": json.dumps(assertions) if assertions else None,
                "title": title,
                "status": status,
            }
            if status == "verified":
                spec_data["linked_tests"] = self.get_tests_for_spec(id)
            self._gate_registry.run_pre_promote(id, "new", status, spec_data)
        version = self._next_spec_version(id)
        assertions_json = json.dumps(assertions) if assertions else None
        tags_json = json.dumps(tags) if tags else None
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO specifications
               (id, version, title, description, priority, scope, section,
                handle, tags, status, assertions, type,
                authority, provisional_until, constraints, affected_by, testability,
                source_paths,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                title,
                description,
                priority,
                scope,
                section,
                handle,
                tags_json,
                status,
                assertions_json,
                type,
                authority,
                provisional_until,
                constraints_json,
                affected_by_json,
                testability,
                source_paths_json,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        try:
            self._record_event(
                conn,
                "spec_transition",
                changed_by,
                artifact_id=id,
                artifact_type="spec",
                artifact_version=version,
                metadata={"from_status": "new", "to_status": status, "change_reason": change_reason},
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return self.get_spec(id)

    def update_spec(
        self,
        id: str,
        changed_by: str,
        change_reason: str,
        *,
        validate_assertions: bool = True,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """Create a new version of a spec, carrying forward unchanged fields.

        F1 enriched fields (authority, provisional_until, constraints, affected_by,
        testability) follow the carry-forward rule: if omitted, the previous version's
        value is preserved. JSON fields (constraints, affected_by) carry forward as raw
        storage strings without re-validation or re-serialization.

        Args:
            validate_assertions: If True (default), validate assertion definitions
                  before writing. Set False only for tested migration tooling.
        """
        current = self.get_spec(id)
        if not current:
            raise ValueError(f"Spec {id} not found")

        # Validate assertions at write time if provided
        if validate_assertions and "assertions" in fields and fields["assertions"] is not None:
            from groundtruth_kb.assertion_schema import validate_assertion_list

            errors = validate_assertion_list(fields["assertions"])
            if errors:
                raise ValueError(f"Invalid assertions for {id}: {'; '.join(errors)}")

        version = self._next_spec_version(id)
        # Merge: new fields override current values
        title = fields.get("title", current["title"])
        description = fields.get("description", current["description"])
        priority = fields.get("priority", current["priority"])
        scope = fields.get("scope", current["scope"])
        section = fields.get("section", current["section"])
        handle = fields.get("handle", current["handle"])
        status = fields.get("status", current["status"])
        spec_type = self._auto_detect_spec_type(id, fields.get("type", current.get("type", "requirement")))

        # Tags and assertions: use module-level _UNSET to allow explicit [] or None
        raw_tags = fields.get("tags", _UNSET)
        if not _is_unset(raw_tags):
            tags_json = json.dumps(raw_tags) if raw_tags is not None else None
        else:
            tags_json = current["tags"]

        raw_assertions = fields.get("assertions", _UNSET)
        if not _is_unset(raw_assertions):
            assertions_json = json.dumps(raw_assertions) if raw_assertions is not None else None
        else:
            assertions_json = current["assertions"]

        # --- F1: 8-step carry-forward for enriched fields ---
        # Step 1: Already done — current = self.get_spec(id) above

        # Step 2: Extract with sentinels
        authority = fields.get("authority", _UNSET)
        provisional_until = fields.get("provisional_until", _CARRY_FORWARD)
        testability = fields.get("testability", _UNSET)

        # Step 3: Resolve carry-forward BEFORE normalization
        if _is_unset(authority):
            authority = current.get("authority")
        if _is_carry_forward(provisional_until):
            provisional_until = current.get("provisional_until")
        if _is_unset(testability):
            testability = current.get("testability")

        # Step 4: INV-4 — changing authority AWAY from provisional clears provisional_until
        prev_authority = current.get("authority")
        if prev_authority == "provisional" and authority != "provisional" and authority is not None:
            provisional_until = None

        # Step 5: Normalize provisional lifecycle
        authority, provisional_until = _normalize_provisional(authority, provisional_until)

        # Step 6: Default — if still _UNSET after carry-forward, keep None (legacy rows)
        if _is_unset(authority):
            authority = None

        # Step 7: Validate all F1 fields
        if authority is not None:
            _validate_authority(authority)
        if testability is not None:
            _validate_testability(testability)
        _validate_provisional_until(provisional_until)

        # F1 JSON fields: provided → validate + serialize; omitted → raw carry-forward
        if "constraints" in fields:
            constraints_val = fields["constraints"]
            _validate_constraints(constraints_val)
            constraints_raw = json.dumps(constraints_val) if constraints_val is not None else None
        else:
            constraints_raw = current.get("constraints")  # raw JSON string from _row_to_dict

        if "affected_by" in fields:
            affected_by_val = fields["affected_by"]
            _validate_affected_by(affected_by_val)
            affected_by_raw = json.dumps(affected_by_val) if affected_by_val is not None else None
        else:
            affected_by_raw = current.get("affected_by")  # raw JSON string from _row_to_dict

        # source_paths: carry-forward (same pattern as constraints/affected_by)
        if "source_paths" in fields:
            source_paths_val = fields["source_paths"]
            source_paths_raw = json.dumps(source_paths_val) if source_paths_val is not None else None
        else:
            source_paths_raw = current.get("source_paths")  # raw JSON string from _row_to_dict

        # Run governance gates before spec promotion
        if self._gate_registry is not None:
            spec_data = {
                "type": spec_type,
                "assertions": assertions_json,
                "title": title,
                "status": status,
            }
            if status == "verified":
                spec_data["linked_tests"] = self.get_tests_for_spec(id)
            self._gate_registry.run_pre_promote(id, current["status"], status, spec_data)

        # Step 8: INSERT new version row with resolved values
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO specifications
               (id, version, title, description, priority, scope, section,
                handle, tags, status, assertions, type,
                authority, provisional_until, constraints, affected_by, testability,
                source_paths,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                title,
                description,
                priority,
                scope,
                section,
                handle,
                tags_json,
                status,
                assertions_json,
                spec_type,
                authority,
                provisional_until,
                constraints_raw,
                affected_by_raw,
                testability,
                source_paths_raw,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        try:
            if current["status"] != status:
                self._record_event(
                    conn,
                    "spec_transition",
                    changed_by,
                    artifact_id=id,
                    artifact_type="spec",
                    artifact_version=version,
                    metadata={"from_status": current["status"], "to_status": status, "change_reason": change_reason},
                )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return self.get_spec(id)

    def get_spec(self, spec_id: str) -> dict[str, Any] | None:
        """Get the current (latest) version of a specification."""
        row = self._get_conn().execute("SELECT * FROM current_specifications WHERE id = ?", (spec_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def get_spec_history(self, spec_id: str) -> list[dict[str, Any]]:
        """Get all versions of a specification, newest first."""
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM specifications WHERE id = ? ORDER BY version DESC",
                (spec_id,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def link_spec_deliberation_source(
        self,
        spec_id: str,
        spec_version: int,
        deliberation_id: str,
        added_by: str,
        source_role: str | None = None,
        added_at: str | None = None,
    ) -> dict[str, Any]:
        """Create or return an idempotent specification-deliberation source link."""
        if not spec_id or not spec_id.strip():
            raise ValueError("spec_id is required")
        if not isinstance(spec_version, int) or spec_version < 1:
            raise ValueError("spec_version must be a positive integer")
        if not deliberation_id or not deliberation_id.strip():
            raise ValueError("deliberation_id is required")
        if not added_by or not added_by.strip():
            raise ValueError("added_by is required")

        conn = self._get_conn()
        timestamp = added_at or _now()
        conn.execute(
            """INSERT OR IGNORE INTO specification_deliberation_sources
               (spec_id, spec_version, deliberation_id, source_role, added_at, added_by)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (spec_id, spec_version, deliberation_id, source_role, timestamp, added_by),
        )
        conn.commit()
        row = conn.execute(
            """SELECT * FROM specification_deliberation_sources
               WHERE spec_id = ? AND spec_version = ? AND deliberation_id = ?""",
            (spec_id, spec_version, deliberation_id),
        ).fetchone()
        if row is None:
            raise RuntimeError("specification deliberation source link was not persisted")
        return _row_to_dict(row)

    def list_specs(
        self,
        *,
        status: str | None = None,
        priority: str | None = None,
        section: str | None = None,
        handle: str | None = None,
        tag: str | None = None,
        search: str | None = None,
        type: str | None = None,
        authority: str | None = None,
        testability: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current specifications with optional filters."""
        query = "SELECT * FROM current_specifications WHERE 1=1"
        params: list[Any] = []
        if type:
            query += " AND type = ?"
            params.append(type)
        if status:
            query += " AND status = ?"
            params.append(status)
        if priority:
            query += " AND priority = ?"
            params.append(priority)
        if section:
            query += " AND section LIKE ?"
            params.append(f"%{section}%")
        if handle:
            query += " AND handle = ?"
            params.append(handle)
        if tag:
            # Tags stored as JSON array — LIKE gives approximate containment.
            # Known limitation: "admin" matches both ["admin"] and ["non-admin"].
            # Exact matching would require a junction table (overkill at current scale).
            query += " AND tags LIKE ?"
            params.append(f'%"{tag}"%')
        if search:
            query += " AND (title LIKE ? OR description LIKE ?)"
            params.extend([f"%{search}%", f"%{search}%"])
        if authority:
            query += " AND authority = ?"
            params.append(authority)
        if testability:
            query += " AND testability = ?"
            params.append(testability)
        rows = self._get_conn().execute(query, params).fetchall()
        result = [_row_to_dict(r) for r in rows]
        result.sort(key=lambda r: spec_sort_key(r["id"]))
        return result

    def get_provisional_specs(self) -> list[dict[str, Any]]:
        """Return current specs where authority='provisional' and provisional_until IS NOT NULL."""
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM current_specifications WHERE authority = 'provisional' AND provisional_until IS NOT NULL"
            )
            .fetchall()
        )
        result = [_row_to_dict(r) for r in rows]
        result.sort(key=lambda r: spec_sort_key(r["id"]))
        return result

    def get_specs_affected_by(self, constraint_id: str) -> list[dict[str, Any]]:
        """Return current specs whose affected_by list contains exactly constraint_id.

        Uses JSON parsing for exact containment — not SQL LIKE substring matching.
        This prevents false positives like 'ADR-1' matching 'ADR-10'.
        """
        rows = self._get_conn().execute("SELECT * FROM current_specifications WHERE affected_by IS NOT NULL").fetchall()
        result = []
        for row in rows:
            d = _row_to_dict(row)
            parsed = d.get("affected_by_parsed")
            if parsed and isinstance(parsed, list) and constraint_id in parsed:
                result.append(d)
        result.sort(key=lambda r: spec_sort_key(r["id"]))
        return result

    # --- F3: Spec Quality Gate ---

    def score_spec_quality(self, spec: dict[str, Any]) -> dict[str, Any]:
        """Compute quality score for a single spec.

        Returns dict with overall, d1-d5 dimension scores, tier, and flags.
        Gracefully degrades when F1 fields are absent (adjusts denominators).
        """
        flags: list[str] = []
        assertions = spec.get("assertions_parsed") or spec.get("_assertions_parsed") or []

        # Executable assertion types per assertions.py
        _EXECUTABLE = {"grep", "glob", "grep_absent", "file_exists", "count", "json_path", "all_of", "any_of"}

        has_assertions = bool(assertions)
        has_executable = (
            any(isinstance(a, dict) and a.get("type") in _EXECUTABLE for a in assertions) if has_assertions else False
        )

        if not has_assertions:
            flags.append("NO_ASSERTIONS")
        elif not has_executable:
            flags.append("NO_EXECUTABLE_ASSERTIONS")

        # D1: Clarity
        d1 = 0.0
        title = spec.get("title", "")
        if title and 40 <= len(title) <= 120:
            d1 += 0.2
        if title and any(w in title.lower() for w in ("must", "shall", "should", "requires")):
            d1 += 0.3
        if spec.get("description") and len(spec.get("description", "")) > 50:
            d1 += 0.3
        if spec.get("description") and any(
            w in spec["description"].lower() for w in ("because", "rationale", "reason", "ensures")
        ):
            d1 += 0.2

        # D2: Testability
        d2 = 0.0
        if has_assertions:
            d2 += 0.3
        if has_executable:
            d2 += 0.4
        if has_assertions and any(isinstance(a, dict) and a.get("description") for a in assertions):
            d2 += 0.15
        if has_assertions and any(isinstance(a, dict) and a.get("file") for a in assertions):
            d2 += 0.15
        # F1 bonus: testability field
        if spec.get("testability"):
            d2 = min(1.0, d2 + 0.1)

        # D3: Completeness (dynamic denominator)
        d3_checks = 0
        d3_hits = 0
        for field in ("type", "tags", "section", "scope", "priority", "description"):
            d3_checks += 1
            if spec.get(field):
                d3_hits += 1
        # F1 fields: only count if present in spec dict (graceful degradation)
        for f1_field in ("authority", "constraints", "affected_by"):
            if f1_field in spec:
                d3_checks += 1
                val = spec.get(f1_field)
                if val is not None and val != "" and val != "[]" and val != "{}":
                    d3_hits += 1
        d3 = d3_hits / max(d3_checks, 1)

        # D4: Isolation
        d4 = 0.0
        if spec.get("section"):
            d4 += 0.4
        if spec.get("handle"):
            d4 += 0.3
        if spec.get("affected_by_parsed") or spec.get("_affected_by_parsed"):
            d4 += 0.3

        # D5: Freshness (simplified — based on version existence)
        d5 = 0.5  # Base freshness
        if has_assertions:
            d5 += 0.3
        if spec.get("version", 0) > 1:
            d5 += 0.2
        d5 = min(1.0, d5)

        overall = (d1 + d2 + d3 + d4 + d5) / 5.0

        # Tier classification
        if overall >= 0.8:
            tier = "gold"
        elif overall >= 0.6:
            tier = "silver"
        elif overall >= 0.4:
            tier = "bronze"
        else:
            tier = "needs-work"

        return {
            "overall": round(overall, 4),
            "d1_clarity": round(d1, 4),
            "d2_testability": round(d2, 4),
            "d3_completeness": round(d3, 4),
            "d4_isolation": round(d4, 4),
            "d5_freshness": round(d5, 4),
            "tier": tier,
            "flags": flags,
        }

    def persist_quality_scores(self, session_id: str) -> int:
        """Score all current specs and persist to spec_quality_scores. Returns row count."""
        specs = self.list_specs()
        conn = self._get_conn()
        count = 0
        for spec in specs:
            score = self.score_spec_quality(spec)
            flags_json = json.dumps(score["flags"]) if score["flags"] else None
            try:
                conn.execute(
                    """INSERT OR REPLACE INTO spec_quality_scores
                       (spec_id, spec_version, session_id, scored_at,
                        overall, d1_clarity, d2_testability, d3_completeness,
                        d4_isolation, d5_freshness, tier, flags)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        spec["id"],
                        spec["version"],
                        session_id,
                        _now(),
                        score["overall"],
                        score["d1_clarity"],
                        score["d2_testability"],
                        score["d3_completeness"],
                        score["d4_isolation"],
                        score["d5_freshness"],
                        score["tier"],
                        flags_json,
                    ),
                )
                count += 1
            except sqlite3.IntegrityError:
                pass  # Skip duplicate/constraint violations
        conn.commit()
        return count

    def get_quality_history(self, spec_id: str) -> list[dict[str, Any]]:
        """Historical quality scores for a spec, ordered by scored_at DESC."""
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM spec_quality_scores WHERE spec_id = ? ORDER BY scored_at DESC",
                (spec_id,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def get_quality_distribution(self) -> dict[str, Any]:
        """Aggregate quality distribution across latest scores per spec.

        Uses rowid as deterministic tie-breaker when multiple scores share
        the same scored_at timestamp for one spec.
        """
        rows = (
            self._get_conn()
            .execute(
                """SELECT tier, COUNT(*) as count, AVG(overall) as avg_score
                   FROM spec_quality_scores sq
                   INNER JOIN (
                       SELECT spec_id, MAX(rowid) as latest_rowid
                       FROM spec_quality_scores GROUP BY spec_id
                   ) latest ON sq.spec_id = latest.spec_id AND sq.rowid = latest.latest_rowid
                   GROUP BY tier"""
            )
            .fetchall()
        )
        dist: dict[str, Any] = {}
        total = 0
        for row in rows:
            d = dict(row)
            dist[d["tier"]] = {"count": d["count"], "avg_score": round(d["avg_score"], 4)}
            total += d["count"]
        dist["total"] = total
        return dist

    # --- F4-A: Constraint Propagation (Phase A — Read-Only) ---

    def _find_matching_constraints(
        self, *, section: str | None = None, scope: str | None = None, tags: list[str] | None = None
    ) -> list[dict[str, Any]]:
        """Shared helper: find ADR/DCL specs whose scope overlaps the given criteria."""
        constraints: list[dict[str, Any]] = []
        for ctype in ("architecture_decision", "design_constraint"):
            for spec in self.list_specs(type=ctype):
                match = False
                if section and spec.get("section") and section.lower() in spec["section"].lower():
                    match = True
                if scope and spec.get("scope") and scope.lower() in spec["scope"].lower():
                    match = True
                if tags and spec.get("tags_parsed"):
                    spec_tags = spec["tags_parsed"] if isinstance(spec["tags_parsed"], list) else []
                    if set(tags) & set(spec_tags):
                        match = True
                if match:
                    constraints.append(spec)
        return constraints

    def check_constraints_for_spec(
        self,
        spec_id: str | None = None,
        *,
        section: str | None = None,
        scope: str | None = None,
        tags: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Return ADR/DCL specs whose scope overlaps. Read-only advisory lookup.

        If spec_id is provided, uses that spec's section/scope/tags for matching.
        Otherwise uses the explicit section/scope/tags parameters.
        """
        if spec_id is not None:
            spec = self.get_spec(spec_id)
            if spec:
                section = section or spec.get("section")
                scope = scope or spec.get("scope")
                if tags is None and spec.get("tags_parsed"):
                    tags = spec["tags_parsed"] if isinstance(spec["tags_parsed"], list) else None
        return self._find_matching_constraints(section=section, scope=scope, tags=tags)

    def get_constraint_coverage(self) -> dict[str, Any]:
        """Report: which sections have ADR/DCL coverage and which don't."""
        all_specs = self.list_specs()
        constraint_specs = [s for s in all_specs if s.get("type") in ("architecture_decision", "design_constraint")]

        # Collect sections from all specs
        all_sections: set[str] = set()
        for s in all_specs:
            if s.get("section"):
                all_sections.add(s["section"])

        # Collect sections covered by constraints
        covered_sections: set[str] = set()
        for cs in constraint_specs:
            if cs.get("section"):
                covered_sections.add(cs["section"])

        uncovered = all_sections - covered_sections
        return {
            "total_sections": len(all_sections),
            "covered_sections": sorted(covered_sections),
            "uncovered_sections": sorted(uncovered),
            "coverage_ratio": len(covered_sections) / max(len(all_sections), 1),
            "constraint_count": len(constraint_specs),
        }

    # --- F4-B: Constraint Propagation (Phase B — Linkage Writes) ---

    def _find_specs_for_constraint(self, constraint: dict[str, Any]) -> list[dict[str, Any]]:
        """Inverse of _find_matching_constraints: find functional specs
        whose section/scope/tags overlap with a constraint spec.

        Excludes ADR/DCL peer specs and the source constraint itself.
        """
        c_section = constraint.get("section")
        c_scope = constraint.get("scope")
        c_tags_raw = constraint.get("tags_parsed")
        c_tags = set(c_tags_raw) if isinstance(c_tags_raw, list) else set()
        c_id = constraint.get("id")

        result: list[dict[str, Any]] = []
        for spec in self.list_specs():
            if spec.get("type") in ("architecture_decision", "design_constraint"):
                continue
            if spec["id"] == c_id:
                continue
            match = False
            if c_section and spec.get("section") and spec["section"] == c_section:
                match = True
            if c_scope and spec.get("scope") and spec["scope"] == c_scope:
                match = True
            if c_tags and not match:
                s_tags_raw = spec.get("tags_parsed")
                s_tags = set(s_tags_raw) if isinstance(s_tags_raw, list) else set()
                if c_tags & s_tags:
                    match = True
            if match:
                result.append(spec)
        return result

    def propagate_constraint(
        self,
        constraint_id: str,
        *,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Link a constraint to all matching functional specs via affected_by.

        Each linkage creates a new spec version (append-only).
        """
        constraint = self.get_spec(constraint_id)
        if constraint is None:
            return {"error": f"Constraint {constraint_id} not found"}

        matching = self._find_specs_for_constraint(constraint)
        affected: list[dict[str, Any]] = []
        newly_linked = 0
        already_linked = 0

        for spec in matching:
            current_affected_by = spec.get("affected_by_parsed") or []
            if not isinstance(current_affected_by, list):
                current_affected_by = []

            if constraint_id in current_affected_by:
                affected.append({"id": spec["id"], "title": spec["title"], "action": "already_linked"})
                already_linked += 1
            else:
                if not dry_run:
                    new_affected_by = current_affected_by + [constraint_id]
                    self.update_spec(
                        spec["id"],
                        "constraint-propagation",
                        f"Linked constraint {constraint_id}: {constraint.get('title', '')}",
                        affected_by=new_affected_by,
                    )
                affected.append({"id": spec["id"], "title": spec["title"], "action": "linked"})
                newly_linked += 1

        return {
            "constraint_id": constraint_id,
            "constraint_title": constraint.get("title", ""),
            "dry_run": dry_run,
            "affected_specs": affected,
            "newly_linked": newly_linked,
            "already_linked": already_linked,
        }

    def remove_constraint_link(
        self,
        spec_id: str,
        constraint_id: str,
        *,
        changed_by: str = "constraint-propagation",
        change_reason: str,
    ) -> dict[str, Any]:
        """Remove a constraint from a spec's affected_by list.

        Creates a new spec version (append-only audit trail).
        """
        spec = self.get_spec(spec_id)
        if spec is None:
            return {"spec_id": spec_id, "constraint_id": constraint_id, "removed": False}

        current = spec.get("affected_by_parsed") or []
        if not isinstance(current, list):
            current = []

        if constraint_id not in current:
            return {"spec_id": spec_id, "constraint_id": constraint_id, "removed": False}

        new_affected_by = [x for x in current if x != constraint_id]
        self.update_spec(
            spec_id,
            changed_by,
            change_reason,
            affected_by=new_affected_by if new_affected_by else None,
        )
        return {"spec_id": spec_id, "constraint_id": constraint_id, "removed": True}

    # --- F2-A: Change Impact Analysis (Phase A — Advisory) ---

    def compute_impact(
        self,
        operation: str,
        spec_data: dict[str, Any],
        *,
        config: Any | None = None,
    ) -> dict[str, Any]:
        """Compute advisory change-impact analysis for a specification.

        Args:
            operation: Planned operation — "add", "modify", or "remove".
            spec_data: Spec dict (may or may not be persisted yet).
            config: Optional :class:`~groundtruth_kb.impact.ImpactConfig`.

        Delegates to :func:`groundtruth_kb.impact.compute_impact_analysis`.
        """
        from groundtruth_kb.impact import ImpactConfig, compute_impact_analysis

        if config is not None and not isinstance(config, ImpactConfig):
            msg = f"config must be an ImpactConfig instance, got {type(config).__name__}"
            raise TypeError(msg)
        return compute_impact_analysis(self, operation, spec_data, config=config)

    # --- F7: Session Health Dashboard ---

    def capture_session_snapshot(self, session_id: str) -> dict[str, Any]:
        """Capture a health snapshot of current DB state.

        Uses INSERT OR REPLACE — repeated captures for the same session_id
        replace the previous snapshot (latest-snapshot replacement contract).
        """
        data = {
            "lifecycle_metrics": self.get_lifecycle_metrics(),
            "summary": self.get_summary(),
            "quality_distribution": self.get_quality_distribution(),
            "constraint_coverage": self.get_constraint_coverage(),
            "captured_at": _now(),
        }
        data_json = json.dumps(data)
        self._get_conn().execute(
            "INSERT OR REPLACE INTO session_snapshots (session_id, captured_at, data) VALUES (?, ?, ?)",
            (session_id, data["captured_at"], data_json),
        )
        self._get_conn().commit()
        return {"session_id": session_id, **data}

    def get_session_snapshot(self, session_id: str) -> dict[str, Any] | None:
        """Retrieve a stored snapshot by session ID."""
        row = self._get_conn().execute("SELECT * FROM session_snapshots WHERE session_id = ?", (session_id,)).fetchone()
        if row is None:
            return None
        d = dict(row)
        d["data_parsed"] = json.loads(d["data"]) if d.get("data") else {}
        return d

    def get_snapshot_history(self, limit: int = 10) -> list[dict[str, Any]]:
        """Retrieve recent snapshots ordered by latest write.

        Uses ``(captured_at DESC, rowid DESC)`` so same-second captures
        resolve deterministically to latest-write-wins.
        """
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM session_snapshots ORDER BY captured_at DESC, rowid DESC LIMIT ?",
                (limit,),
            )
            .fetchall()
        )
        result = []
        for row in rows:
            d = dict(row)
            d["data_parsed"] = json.loads(d["data"]) if d.get("data") else {}
            result.append(d)
        return result

    def compute_session_delta(self, current_session: str | None = None) -> dict[str, Any]:
        """Compute health metric deltas.

        When current_session is None: compares live DB state with the most
        recent stored snapshot.
        When current_session is provided: compares that snapshot with the
        previous one.
        """
        if current_session is None:
            # Live state vs last snapshot
            current_data = {
                "lifecycle_metrics": self.get_lifecycle_metrics(),
                "summary": self.get_summary(),
                "quality_distribution": self.get_quality_distribution(),
                "constraint_coverage": self.get_constraint_coverage(),
            }
            history = self.get_snapshot_history(limit=1)
            if not history:
                return {"current": current_data, "previous": None, "deltas": {}, "no_prior": True}
            previous_data = history[0].get("data_parsed", {})
        else:
            snap = self.get_session_snapshot(current_session)
            if snap is None:
                return {"current": None, "previous": None, "deltas": {}, "no_prior": True}
            current_data = snap.get("data_parsed", {})
            # Find the snapshot just before this one (by rowid, not timestamp,
            # to handle same-second captures deterministically)
            rows = (
                self._get_conn()
                .execute(
                    "SELECT * FROM session_snapshots WHERE rowid < (SELECT rowid FROM session_snapshots WHERE session_id = ?) ORDER BY rowid DESC LIMIT 1",
                    (current_session,),
                )
                .fetchall()
            )
            if not rows:
                return {"current": current_data, "previous": None, "deltas": {}, "no_prior": True}
            prev = dict(rows[0])
            previous_data = json.loads(prev["data"]) if prev.get("data") else {}

        # Compute deltas for lifecycle metrics
        deltas: dict[str, Any] = {}
        cur_metrics = current_data.get("lifecycle_metrics", {})
        prev_metrics = previous_data.get("lifecycle_metrics", {})
        for key in cur_metrics:
            cur_val = cur_metrics[key].get("value") if isinstance(cur_metrics[key], dict) else None
            prev_val = prev_metrics.get(key, {}).get("value") if isinstance(prev_metrics.get(key), dict) else None
            if cur_val is not None and prev_val is not None:
                try:
                    deltas[key] = round(float(cur_val) - float(prev_val), 6)
                except (TypeError, ValueError):
                    pass

        return {"current": current_data, "previous": previous_data, "deltas": deltas, "no_prior": False}

    def list_children(self, parent_id: str) -> list[dict[str, Any]]:
        """List current specs that are direct or nested children of parent_id.

        E.g., parent_id="245" returns 245.1, 245.2, 245.1.1, etc.
        """
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM current_specifications WHERE id LIKE ?",
                (f"{parent_id}.%",),
            )
            .fetchall()
        )
        result = [_row_to_dict(r) for r in rows]
        result.sort(key=lambda r: spec_sort_key(r["id"]))
        return result

    def list_direct_children(self, parent_id: str) -> list[dict[str, Any]]:
        """List current specs that are immediate children of parent_id.

        E.g., parent_id="245" returns 245.1, 245.2 but NOT 245.1.1.
        """
        target_depth = get_depth(parent_id) + 1
        all_children = self.list_children(parent_id)
        return [r for r in all_children if get_depth(r["id"]) == target_depth]

    # ------------------------------------------------------------------
    # Test Procedures
    # ------------------------------------------------------------------

    def _next_test_proc_version(self, proc_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM test_procedures WHERE id = ?", (proc_id,)).fetchone()
        return (row[0] or 0) + 1

    def insert_test_procedure(
        self,
        id: str,
        title: str,
        changed_by: str,
        change_reason: str,
        *,
        type: str | None = None,
        content: str | None = None,
        assertion_count: int | None = None,
        last_execution_status: str | None = None,
        last_executed_at: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of a test procedure into the knowledge database.

        Test procedures are append-only — each call creates a new version row
        keyed by ``id``. The latest version is exposed via ``get_test_procedure``.

        Args:
            id: Unique test procedure identifier (e.g. ``"TP-001"``).
            title: Short descriptive title.
            changed_by: Actor responsible for this version.
            change_reason: Human-readable rationale for the change.
            type: Optional procedure type classification.
            content: Full procedure content or script text.
            assertion_count: Number of assertions in the procedure.
            last_execution_status: Result of the most recent execution
                (e.g. ``"pass"``, ``"fail"``).
            last_executed_at: ISO-8601 timestamp of the most recent execution.

        Returns:
            The newly inserted version as a dict. Schema mirrors the
            ``test_procedures`` table row, with JSON fields pre-parsed.
        """
        version = self._next_test_proc_version(id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO test_procedures
               (id, version, title, type, content, assertion_count,
                last_execution_status, last_executed_at,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                title,
                type,
                content,
                assertion_count,
                last_execution_status,
                last_executed_at,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_test_procedure(id)

    def get_test_procedure(self, proc_id: str) -> dict[str, Any] | None:
        """Return the latest version of a test procedure, or None if not found.

        Args:
            proc_id: Test procedure identifier (e.g. ``"TP-001"``).

        Returns:
            A dict of the current test procedure row with JSON fields pre-parsed,
            or ``None`` if no procedure with that ID exists.
        """
        row = self._get_conn().execute("SELECT * FROM current_test_procedures WHERE id = ?", (proc_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def get_test_procedure_history(self, proc_id: str) -> list[dict[str, Any]]:
        """Return all versions of a test procedure, newest-first.

        Args:
            proc_id: Test procedure identifier (e.g. ``"TP-001"``).

        Returns:
            A list of version dicts ordered by ``version DESC``. Returns an
            empty list if no procedure with that ID exists.
        """
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM test_procedures WHERE id = ? ORDER BY version DESC",
                (proc_id,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_test_procedures(self, *, type: str | None = None) -> list[dict[str, Any]]:
        """List all current test procedures, optionally filtered by type.

        Args:
            type: Optional type filter. When provided, returns only procedures
                with a matching ``type`` value.

        Returns:
            A list of test procedure dicts ordered by ``id``. Returns an
            empty list if no matching procedures exist.
        """
        query = "SELECT * FROM current_test_procedures WHERE 1=1"
        params: list[Any] = []
        if type:
            query += " AND type = ?"
            params.append(type)
        query += " ORDER BY id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Operational Procedures
    # ------------------------------------------------------------------

    def _next_op_version(self, proc_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM operational_procedures WHERE id = ?", (proc_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_op_procedure(
        self,
        id: str,
        title: str,
        changed_by: str,
        change_reason: str,
        *,
        type: str | None = None,
        variables: dict[str, Any] | None = None,
        steps: list[dict[str, Any]] | None = None,
        known_failure_modes: list[dict[str, Any]] | None = None,
        last_verified_at: str | None = None,
        last_corrected_at: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of an operational procedure into the knowledge database.

        Operational procedures are append-only — each call creates a new version
        row keyed by ``id``. The latest version is exposed via ``get_op_procedure``.
        JSON fields (``variables``, ``steps``, ``known_failure_modes``) are
        serialized automatically.

        Args:
            id: Unique operational procedure identifier (e.g. ``"OP-001"``).
            title: Short descriptive title.
            changed_by: Actor responsible for this version.
            change_reason: Human-readable rationale for the change.
            type: Optional procedure type classification.
            variables: Optional dict of named variables used by the procedure steps.
            steps: Optional list of step dicts describing the procedure steps.
            known_failure_modes: Optional list of dicts documenting known failure
                modes and their mitigations.
            last_verified_at: ISO-8601 timestamp of the most recent verification.
            last_corrected_at: ISO-8601 timestamp of the most recent correction.

        Returns:
            The newly inserted version as a dict. Schema mirrors the
            ``operational_procedures`` table row, with JSON fields pre-parsed.
        """
        version = self._next_op_version(id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO operational_procedures
               (id, version, title, type, variables, steps, known_failure_modes,
                last_verified_at, last_corrected_at,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                title,
                type,
                json.dumps(variables) if variables else None,
                json.dumps(steps) if steps else None,
                json.dumps(known_failure_modes) if known_failure_modes else None,
                last_verified_at,
                last_corrected_at,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_op_procedure(id)

    def get_op_procedure(self, proc_id: str) -> dict[str, Any] | None:
        """Return the latest version of an operational procedure, or None if not found.

        Args:
            proc_id: Operational procedure identifier (e.g. ``"OP-001"``).

        Returns:
            A dict of the current operational procedure row with JSON fields
            (``variables``, ``steps``, ``known_failure_modes``) pre-parsed,
            or ``None`` if no procedure with that ID exists.
        """
        row = (
            self._get_conn().execute("SELECT * FROM current_operational_procedures WHERE id = ?", (proc_id,)).fetchone()
        )
        return _row_to_dict(row) if row else None

    def get_op_procedure_history(self, proc_id: str) -> list[dict[str, Any]]:
        """Return all versions of an operational procedure, newest-first.

        Args:
            proc_id: Operational procedure identifier (e.g. ``"OP-001"``).

        Returns:
            A list of version dicts ordered by ``version DESC``. Returns an
            empty list if no procedure with that ID exists.
        """
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM operational_procedures WHERE id = ? ORDER BY version DESC",
                (proc_id,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_op_procedures(self, *, type: str | None = None) -> list[dict[str, Any]]:
        """List all current operational procedures, optionally filtered by type.

        Args:
            type: Optional type filter. When provided, returns only procedures
                with a matching ``type`` value.

        Returns:
            A list of operational procedure dicts ordered by ``id``. Returns an
            empty list if no matching procedures exist.
        """
        query = "SELECT * FROM current_operational_procedures WHERE 1=1"
        params: list[Any] = []
        if type:
            query += " AND type = ?"
            params.append(type)
        query += " ORDER BY id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Environment Config
    # ------------------------------------------------------------------

    def _next_env_version(self, config_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM environment_config WHERE id = ?", (config_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_env_config(
        self,
        id: str,
        environment: str,
        category: str,
        key: str,
        value: str,
        changed_by: str,
        change_reason: str,
        *,
        sensitive: bool = False,
        notes: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of an environment config entry.

        Args:
            id: Unique identifier (e.g., "prod-api-gateway-fqdn", "prod-tenant-remaker-widget-key").
            environment: Environment name ("production", "staging", "shared").
            category: Config category ("url", "credential", "infrastructure", "tenant").
            key: Human-readable key name (e.g., "API Gateway FQDN", "Widget Key").
            value: The actual value (URL, key, etc.).
            sensitive: If True, value is masked in web UI display (shown as ****).
            notes: Optional context (e.g., "Re-seeded S95", "Tenant: remaker-digital-001").
        """
        version = self._next_env_version(id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO environment_config
               (id, version, environment, category, key, value, sensitive,
                notes, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (id, version, environment, category, key, value, int(sensitive), notes, changed_by, _now(), change_reason),
        )
        conn.commit()
        return self.get_env_config(id)

    def update_env_config(
        self,
        id: str,
        changed_by: str,
        change_reason: str,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """Create a new version of an env config entry, carrying forward unchanged fields."""
        current = self.get_env_config(id)
        if not current:
            raise ValueError(f"Environment config {id} not found")

        version = self._next_env_version(id)
        environment = fields.get("environment", current["environment"])
        category = fields.get("category", current["category"])
        key = fields.get("key", current["key"])
        value = fields.get("value", current["value"])
        sensitive = fields.get("sensitive", current["sensitive"])
        notes = fields.get("notes", current["notes"])

        conn = self._get_conn()
        conn.execute(
            """INSERT INTO environment_config
               (id, version, environment, category, key, value, sensitive,
                notes, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (id, version, environment, category, key, value, int(sensitive), notes, changed_by, _now(), change_reason),
        )
        conn.commit()
        return self.get_env_config(id)

    def get_env_config(self, config_id: str) -> dict[str, Any] | None:
        """Get the current (latest) version of an environment config entry."""
        row = self._get_conn().execute("SELECT * FROM current_environment_config WHERE id = ?", (config_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def list_env_config(
        self,
        *,
        environment: str | None = None,
        category: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current environment config entries with optional filters."""
        query = "SELECT * FROM current_environment_config WHERE 1=1"
        params: list[Any] = []
        if environment:
            query += " AND environment = ?"
            params.append(environment)
        if category:
            query += " AND category = ?"
            params.append(category)
        query += " ORDER BY environment, category, key"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_env_config_history(self, config_id: str) -> list[dict[str, Any]]:
        """Get all versions of an environment config entry, newest first."""
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM environment_config WHERE id = ? ORDER BY version DESC",
                (config_id,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Documents
    # ------------------------------------------------------------------

    def _next_doc_version(self, doc_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM documents WHERE id = ?", (doc_id,)).fetchone()
        return (row[0] or 0) + 1

    def insert_document(
        self,
        id: str,
        title: str,
        category: str,
        status: str,
        changed_by: str,
        change_reason: str,
        *,
        content: str | None = None,
        tags: list[str] | None = None,
        source_path: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of a document."""
        version = self._next_doc_version(id)
        tags_json = json.dumps(tags) if tags else None
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO documents
               (id, version, title, category, content, tags, status,
                source_path, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (id, version, title, category, content, tags_json, status, source_path, changed_by, _now(), change_reason),
        )
        conn.commit()
        return self.get_document(id)

    def update_document(
        self,
        id: str,
        changed_by: str,
        change_reason: str,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """Create a new version of a document, carrying forward unchanged fields."""
        current = self.get_document(id)
        if not current:
            raise ValueError(f"Document {id} not found")

        version = self._next_doc_version(id)
        _UNSET = object()
        title = fields.get("title", current["title"])
        category = fields.get("category", current["category"])
        content = fields.get("content", current["content"])
        status = fields.get("status", current["status"])
        source_path = fields.get("source_path", current["source_path"])

        raw_tags = fields.get("tags", _UNSET)
        if raw_tags is not _UNSET:
            tags_json = json.dumps(raw_tags) if raw_tags is not None else None
        else:
            tags_json = current["tags"]

        conn = self._get_conn()
        conn.execute(
            """INSERT INTO documents
               (id, version, title, category, content, tags, status,
                source_path, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (id, version, title, category, content, tags_json, status, source_path, changed_by, _now(), change_reason),
        )
        conn.commit()
        return self.get_document(id)

    def get_document(self, doc_id: str) -> dict[str, Any] | None:
        """Return the latest version of a document, or None if not found.

        Args:
            doc_id: Document identifier (e.g. ``"DOC-001"``).

        Returns:
            A dict of the current document row with JSON fields pre-parsed,
            or ``None`` if no document with that ID exists.
        """
        row = self._get_conn().execute("SELECT * FROM current_documents WHERE id = ?", (doc_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def list_documents(
        self,
        *,
        category: str | None = None,
        status: str | None = None,
        tag: str | None = None,
    ) -> list[dict[str, Any]]:
        """List all current documents, optionally filtered by category, status, or tag.

        Args:
            category: Optional category filter (e.g. ``"implementation_proposal"``).
            status: Optional status filter (e.g. ``"published"``).
            tag: Optional tag filter. Matches documents where the ``tags`` JSON
                array contains an element equal to ``tag``.

        Returns:
            A list of document dicts ordered by ``id``. Returns an empty list
            if no matching documents exist.
        """
        query = "SELECT * FROM current_documents WHERE 1=1"
        params: list[Any] = []
        if category:
            query += " AND category = ?"
            params.append(category)
        if status:
            query += " AND status = ?"
            params.append(status)
        if tag:
            query += " AND tags LIKE ?"
            params.append(f'%"{tag}"%')
        query += " ORDER BY id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # GOV-20: Architecture Decision Governance helpers
    # ------------------------------------------------------------------

    def list_design_constraints(self, *, status: str | None = None) -> list[dict[str, Any]]:
        """List all current design constraint specs (DCL-*)."""
        return self.list_specs(type="design_constraint", status=status)

    def validate_dcl_constraints(
        self,
        dcl_id: str | None = None,
        project_root: Path | None = None,
    ) -> list[dict[str, Any]]:
        """Validate design constraint assertions against the codebase.

        If dcl_id is provided, validates only that constraint.
        Otherwise validates all implemented/verified DCL-* specs with assertions.

        Args:
            dcl_id: Optional single DCL spec ID to validate.
            project_root: Project root for file resolution. Falls back to cwd.

        Returns list of {dcl_id, title, passed, results: [...]} dicts.
        """
        from groundtruth_kb.assertions import run_single_assertion

        if project_root is None:
            project_root = Path.cwd()

        if dcl_id:
            spec = self.get_spec(dcl_id)
            if not spec:
                return [{"dcl_id": dcl_id, "error": f"DCL {dcl_id} not found"}]
            specs: list[dict[str, Any]] = [spec]
        else:
            specs = self.list_design_constraints(status="implemented")
            specs += self.list_design_constraints(status="verified")

        results = []
        for spec in specs:
            if not spec or not spec.get("assertions"):
                continue
            assertion_list = (
                json.loads(spec["assertions"]) if isinstance(spec["assertions"], str) else spec["assertions"]
            )
            spec_results = []
            all_passed = True
            for assertion in assertion_list:
                r = run_single_assertion(assertion, project_root)
                spec_results.append(r)
                if not r.get("passed") and not r.get("skipped"):
                    all_passed = False
            results.append(
                {
                    "dcl_id": spec["id"],
                    "title": spec["title"],
                    "passed": all_passed,
                    "results": spec_results,
                }
            )
        return results

    def list_implementation_proposals(self, *, wi_id: str | None = None) -> list[dict[str, Any]]:
        """List IPR-* documents (implementation proposals). Optionally filter by WI reference."""
        docs = self.list_documents(category="implementation_proposal")
        if wi_id:
            docs = [d for d in docs if wi_id in (d.get("content") or "")]
        return docs

    def list_constraint_verifications(self, *, wi_id: str | None = None) -> list[dict[str, Any]]:
        """List CVR-* documents (constraint verifications). Optionally filter by WI reference."""
        docs = self.list_documents(category="constraint_verification")
        if wi_id:
            docs = [d for d in docs if wi_id in (d.get("content") or "")]
        return docs

    # ------------------------------------------------------------------
    # Test Coverage
    # ------------------------------------------------------------------

    def insert_test_coverage(
        self,
        spec_id: str,
        test_file: str,
        test_function: str,
        created_by: str,
        *,
        test_class: str | None = None,
        confidence: str = "high",
        match_reason: str | None = None,
    ) -> None:
        """Record a test-to-spec mapping."""
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO test_coverage
               (spec_id, test_file, test_class, test_function,
                confidence, match_reason, created_at, created_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (spec_id, test_file, test_class, test_function, confidence, match_reason, _now(), created_by),
        )
        conn.commit()

    def insert_test_coverage_batch(
        self,
        mappings: list[dict[str, Any]],
        created_by: str,
    ) -> int:
        """Batch-insert test coverage mappings. Returns count inserted."""
        conn = self._get_conn()
        count = 0
        for m in mappings:
            conn.execute(
                """INSERT INTO test_coverage
                   (spec_id, test_file, test_class, test_function,
                    confidence, match_reason, created_at, created_by)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    m["spec_id"],
                    m["test_file"],
                    m.get("test_class"),
                    m["test_function"],
                    m.get("confidence", "high"),
                    m.get("match_reason"),
                    _now(),
                    created_by,
                ),
            )
            count += 1
        conn.commit()
        return count

    def get_test_coverage_for_spec(self, spec_id: str) -> list[dict[str, Any]]:
        """Get all test mappings for a spec."""
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM test_coverage WHERE spec_id = ? ORDER BY test_file, test_function",
                (spec_id,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def get_test_coverage_summary(self) -> dict[str, Any]:
        """Get coverage statistics."""
        conn = self._get_conn()
        total_mappings = conn.execute("SELECT COUNT(*) FROM test_coverage").fetchone()[0]
        specs_covered = conn.execute("SELECT COUNT(DISTINCT spec_id) FROM test_coverage").fetchone()[0]
        tests_mapped = conn.execute(
            "SELECT COUNT(DISTINCT test_file || ':' || test_function) FROM test_coverage"
        ).fetchone()[0]
        by_confidence = dict(
            conn.execute("SELECT confidence, COUNT(*) FROM test_coverage GROUP BY confidence").fetchall()
        )
        return {
            "total_mappings": total_mappings,
            "specs_covered": specs_covered,
            "tests_mapped": tests_mapped,
            "by_confidence": by_confidence,
        }

    # ------------------------------------------------------------------
    # Tests (individual test artifacts)
    # ------------------------------------------------------------------

    def _next_test_version(self, test_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM tests WHERE id = ?", (test_id,)).fetchone()
        return (row[0] or 0) + 1

    def insert_test(
        self,
        id: str,
        title: str,
        spec_id: str,
        test_type: str,
        expected_outcome: str,
        changed_by: str,
        change_reason: str,
        *,
        test_file: str | None = None,
        test_class: str | None = None,
        test_function: str | None = None,
        description: str | None = None,
        last_result: str | None = None,
        last_executed_at: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of a test artifact.

        Args:
            id: Unique identifier (e.g., "TEST-0001").
            spec_id: The specification this test verifies (required).
            test_type: 'unit', 'integration', 'e2e', 'manual', or 'assertion'.
            expected_outcome: What constitutes PASS — stated in human-readable terms.
        """
        # Run governance gates on test pass
        if last_result == "pass" and self._gate_registry is not None:
            test_data = {"test_type": test_type, "test_file": test_file, "spec_id": spec_id}
            self._gate_registry.run_pre_test_pass(id, spec_id, test_file, test_data)
        version = self._next_test_version(id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO tests
               (id, version, title, spec_id, test_type, test_file, test_class,
                test_function, description, expected_outcome, last_result,
                last_executed_at, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                title,
                spec_id,
                test_type,
                test_file,
                test_class,
                test_function,
                description,
                expected_outcome,
                last_result,
                last_executed_at,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        try:
            self._record_event(
                conn,
                "test_created",
                changed_by,
                artifact_id=id,
                artifact_type="test",
                artifact_version=version,
                metadata={
                    "spec_id": spec_id,
                    "test_type": test_type,
                    "test_file": test_file,
                    "last_result": last_result,
                    "last_executed_at": last_executed_at,
                },
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return self.get_test(id)

    def update_test(
        self,
        id: str,
        changed_by: str,
        change_reason: str,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """Create a new version of a test, carrying forward unchanged fields."""
        current = self.get_test(id)
        if not current:
            raise ValueError(f"Test {id} not found")
        version = self._next_test_version(id)
        title = fields.get("title", current["title"])
        spec_id = fields.get("spec_id", current["spec_id"])
        test_type = fields.get("test_type", current["test_type"])
        test_file = fields.get("test_file", current["test_file"])
        test_class = fields.get("test_class", current["test_class"])
        test_function = fields.get("test_function", current["test_function"])
        description = fields.get("description", current["description"])
        expected_outcome = fields.get("expected_outcome", current["expected_outcome"])
        last_result = fields.get("last_result", current["last_result"])
        last_executed_at = fields.get("last_executed_at", current["last_executed_at"])
        # Run governance gates on test pass
        if last_result == "pass" and self._gate_registry is not None:
            test_data = {"test_type": test_type, "test_file": test_file, "spec_id": spec_id}
            self._gate_registry.run_pre_test_pass(id, spec_id, test_file, test_data)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO tests
               (id, version, title, spec_id, test_type, test_file, test_class,
                test_function, description, expected_outcome, last_result,
                last_executed_at, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                title,
                spec_id,
                test_type,
                test_file,
                test_class,
                test_function,
                description,
                expected_outcome,
                last_result,
                last_executed_at,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        try:
            result_changed = last_result != current["last_result"]
            executed_changed = last_executed_at != current["last_executed_at"]
            if result_changed or executed_changed:
                self._record_event(
                    conn,
                    "test_executed",
                    changed_by,
                    artifact_id=id,
                    artifact_type="test",
                    artifact_version=version,
                    metadata={
                        "spec_id": spec_id,
                        "test_type": test_type,
                        "test_file": test_file,
                        "previous_last_result": current["last_result"],
                        "last_result": last_result,
                        "previous_last_executed_at": current["last_executed_at"],
                        "last_executed_at": last_executed_at,
                    },
                )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return self.get_test(id)

    def get_test(self, test_id: str) -> dict[str, Any] | None:
        """Return the latest version of a test artifact, or None if not found.

        Args:
            test_id: Test artifact identifier (e.g. ``"TEST-0001"``).

        Returns:
            A dict of the current test row with JSON fields pre-parsed,
            or ``None`` if no test with that ID exists.
        """
        row = self._get_conn().execute("SELECT * FROM current_tests WHERE id = ?", (test_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def get_test_history(self, test_id: str) -> list[dict[str, Any]]:
        """Return all versions of a test artifact, newest-first.

        Args:
            test_id: Test artifact identifier (e.g. ``"TEST-0001"``).

        Returns:
            A list of version dicts ordered by ``version DESC``. Returns an
            empty list if no test with that ID exists.
        """
        rows = self._get_conn().execute("SELECT * FROM tests WHERE id = ? ORDER BY version DESC", (test_id,)).fetchall()
        return [_row_to_dict(r) for r in rows]

    def list_tests(
        self,
        *,
        spec_id: str | None = None,
        test_type: str | None = None,
        last_result: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current tests with optional filters."""
        query = "SELECT * FROM current_tests WHERE 1=1"
        params: list[Any] = []
        if spec_id:
            query += " AND spec_id = ?"
            params.append(spec_id)
        if test_type:
            query += " AND test_type = ?"
            params.append(test_type)
        if last_result:
            query += " AND last_result = ?"
            params.append(last_result)
        query += " ORDER BY id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_tests_for_spec(self, spec_id: str) -> list[dict[str, Any]]:
        """Get all current tests that verify a given specification."""
        return self.list_tests(spec_id=spec_id)

    def get_untested_specs(self) -> list[dict[str, Any]]:
        """Get specifications that have no tests linked to them (excludes retired)."""
        rows = (
            self._get_conn()
            .execute(
                """SELECT s.* FROM current_specifications s
               LEFT JOIN current_tests t ON t.spec_id = s.id
               WHERE t.id IS NULL AND s.status != 'retired'
               ORDER BY s.id"""
            )
            .fetchall()
        )
        result = [_row_to_dict(r) for r in rows]
        result.sort(key=lambda r: spec_sort_key(r["id"]))
        return result

    # ------------------------------------------------------------------
    # Test Plans
    # ------------------------------------------------------------------

    def _next_plan_version(self, plan_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM test_plans WHERE id = ?", (plan_id,)).fetchone()
        return (row[0] or 0) + 1

    def insert_test_plan(
        self,
        id: str,
        title: str,
        status: str,
        changed_by: str,
        change_reason: str,
        *,
        description: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of a test plan.

        Args:
            status: 'draft', 'active', or 'retired'.
        """
        version = self._next_plan_version(id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO test_plans
               (id, version, title, description, status,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (id, version, title, description, status, changed_by, _now(), change_reason),
        )
        conn.commit()
        return self.get_test_plan(id)

    def update_test_plan(
        self,
        id: str,
        changed_by: str,
        change_reason: str,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """Create a new version of a test plan, carrying forward unchanged fields."""
        current = self.get_test_plan(id)
        if not current:
            raise ValueError(f"Test plan {id} not found")
        version = self._next_plan_version(id)
        title = fields.get("title", current["title"])
        description = fields.get("description", current["description"])
        status = fields.get("status", current["status"])
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO test_plans
               (id, version, title, description, status,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (id, version, title, description, status, changed_by, _now(), change_reason),
        )
        conn.commit()
        return self.get_test_plan(id)

    def get_test_plan(self, plan_id: str) -> dict[str, Any] | None:
        """Return the latest version of a test plan, or None if not found.

        Args:
            plan_id: Test plan identifier (e.g. ``"PLAN-001"``).

        Returns:
            A dict of the current test plan row with JSON fields pre-parsed,
            or ``None`` if no test plan with that ID exists.
        """
        row = self._get_conn().execute("SELECT * FROM current_test_plans WHERE id = ?", (plan_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def get_test_plan_history(self, plan_id: str) -> list[dict[str, Any]]:
        """Return all versions of a test plan, newest-first.

        Args:
            plan_id: Test plan identifier (e.g. ``"PLAN-001"``).

        Returns:
            A list of version dicts ordered by ``version DESC``. Returns an
            empty list if no test plan with that ID exists.
        """
        rows = (
            self._get_conn()
            .execute("SELECT * FROM test_plans WHERE id = ? ORDER BY version DESC", (plan_id,))
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_test_plans(self, *, status: str | None = None) -> list[dict[str, Any]]:
        """List all current test plans, optionally filtered by status.

        Args:
            status: Optional status filter (e.g. ``"active"``, ``"draft"``,
                ``"retired"``). When provided, returns only plans with a
                matching ``status`` value.

        Returns:
            A list of test plan dicts ordered by ``id``. Returns an empty
            list if no matching test plans exist.
        """
        query = "SELECT * FROM current_test_plans WHERE 1=1"
        params: list[Any] = []
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_active_test_plan(self) -> dict[str, Any] | None:
        """Get the currently active test plan (status='active'). Returns None if no active plan."""
        plans = self.list_test_plans(status="active")
        return plans[0] if plans else None

    # ------------------------------------------------------------------
    # Test Plan Phases
    # ------------------------------------------------------------------

    def _next_phase_version(self, phase_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM test_plan_phases WHERE id = ?", (phase_id,)).fetchone()
        return (row[0] or 0) + 1

    def insert_test_plan_phase(
        self,
        id: str,
        plan_id: str,
        phase_order: int,
        title: str,
        gate_criteria: str,
        changed_by: str,
        change_reason: str,
        *,
        description: str | None = None,
        test_ids: list[str] | None = None,
        last_result: str | None = None,
        last_executed_at: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of a test plan phase.

        Args:
            plan_id: Which test plan this phase belongs to.
            phase_order: Execution sequence (1, 2, 3...).
            gate_criteria: What constitutes PASS for this phase.
            test_ids: JSON-serializable list of test IDs in this phase.
        """
        version = self._next_phase_version(id)
        test_ids_json = json.dumps(test_ids) if test_ids else None
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO test_plan_phases
               (id, version, plan_id, phase_order, title, description,
                gate_criteria, test_ids, last_result, last_executed_at,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                plan_id,
                phase_order,
                title,
                description,
                gate_criteria,
                test_ids_json,
                last_result,
                last_executed_at,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_test_plan_phase(id)

    def update_test_plan_phase(
        self,
        id: str,
        changed_by: str,
        change_reason: str,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """Create a new version of a test plan phase, carrying forward unchanged fields."""
        current = self.get_test_plan_phase(id)
        if not current:
            raise ValueError(f"Test plan phase {id} not found")
        version = self._next_phase_version(id)
        _UNSET = object()
        plan_id = fields.get("plan_id", current["plan_id"])
        phase_order = fields.get("phase_order", current["phase_order"])
        title = fields.get("title", current["title"])
        description = fields.get("description", current["description"])
        gate_criteria = fields.get("gate_criteria", current["gate_criteria"])
        last_result = fields.get("last_result", current["last_result"])
        last_executed_at = fields.get("last_executed_at", current["last_executed_at"])
        raw_test_ids = fields.get("test_ids", _UNSET)
        if raw_test_ids is not _UNSET:
            test_ids_json = json.dumps(raw_test_ids) if raw_test_ids is not None else None
        else:
            test_ids_json = current["test_ids"]
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO test_plan_phases
               (id, version, plan_id, phase_order, title, description,
                gate_criteria, test_ids, last_result, last_executed_at,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                plan_id,
                phase_order,
                title,
                description,
                gate_criteria,
                test_ids_json,
                last_result,
                last_executed_at,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_test_plan_phase(id)

    def get_test_plan_phase(self, phase_id: str) -> dict[str, Any] | None:
        """Return the latest version of a test plan phase, or None if not found.

        Args:
            phase_id: Test plan phase identifier (e.g. ``"PLAN-001-P1"``).

        Returns:
            A dict of the current test plan phase row with JSON fields
            (e.g. ``test_ids``) pre-parsed, or ``None`` if no phase with
            that ID exists.
        """
        row = self._get_conn().execute("SELECT * FROM current_test_plan_phases WHERE id = ?", (phase_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def list_test_plan_phases(self, plan_id: str) -> list[dict[str, Any]]:
        """List current phases for a test plan, ordered by phase_order."""
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM current_test_plan_phases WHERE plan_id = ? ORDER BY phase_order",
                (plan_id,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Work Items
    # ------------------------------------------------------------------

    def _next_work_item_version(self, item_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM work_items WHERE id = ?", (item_id,)).fetchone()
        return (row[0] or 0) + 1

    # Valid stage transitions: created → tested → backlogged → implementing → resolved
    _VALID_STAGE_TRANSITIONS: dict[str, set[str]] = {
        "created": {"tested", "resolved"},
        "tested": {"backlogged", "resolved"},
        "backlogged": {"implementing", "resolved"},
        "implementing": {"resolved"},
        "resolved": {"resolved"},  # idempotent
    }

    def _validate_stage_transition(
        self,
        wi_id: str,
        current_stage: str,
        new_stage: str,
        *,
        owner_approved: bool = False,
    ) -> None:
        """Enforce valid work item stage transitions per SPEC-1602."""
        if new_stage == current_stage:
            return  # no-op
        valid = self._VALID_STAGE_TRANSITIONS.get(current_stage, set())
        if new_stage not in valid:
            raise ValueError(
                f"Invalid stage transition for {wi_id}: "
                f"'{current_stage}' → '{new_stage}'. "
                f"Valid transitions from '{current_stage}': {sorted(valid)}"
            )
        # Structural guards: tested requires linked test, implementing requires backlog
        if new_stage == "tested":
            if not self._wi_has_linked_test(wi_id):
                raise ValueError(
                    f"Cannot advance {wi_id} to 'tested': no linked test found. "
                    f"Create a test linked to this WI's source_spec_id first (GOV-12)."
                )
        if new_stage == "implementing":
            if not self._wi_in_backlog(wi_id):
                raise ValueError(
                    f"Cannot advance {wi_id} to 'implementing': not found in any "
                    f"backlog snapshot. Add to backlog first."
                )
        # Run governance gates before WI resolution
        if new_stage == "resolved" and self._gate_registry is not None:
            wi = self.get_work_item(wi_id)
            if wi:
                self._gate_registry.run_pre_resolve_work_item(
                    wi_id,
                    wi.get("origin", ""),
                    "resolved",
                    owner_approved,
                    wi,
                )

    def _wi_has_linked_test(self, wi_id: str) -> bool:
        """Check if a work item has a linked test via its source_spec_id."""
        wi = self.get_work_item(wi_id)
        if not wi or not wi.get("source_spec_id"):
            return False
        tests = self.get_tests_for_spec(wi["source_spec_id"])
        return len(tests) > 0

    def _wi_in_backlog(self, wi_id: str) -> bool:
        """Check if a work item ID appears in any backlog snapshot description."""
        rows = self._get_conn().execute("SELECT description FROM current_backlog_snapshots").fetchall()
        for row in rows:
            if row[0] and wi_id in row[0]:
                return True
        return False

    def insert_work_item(
        self,
        id: str,
        title: str,
        origin: str,
        component: str,
        resolution_status: str,
        changed_by: str,
        change_reason: str,
        *,
        description: str | None = None,
        source_spec_id: str | None = None,
        source_test_id: str | None = None,
        failure_description: str | None = None,
        priority: str | None = None,
        stage: str = "created",
        approval_state: str = "unapproved",
        project_name: str | None = None,
        subproject_name: str | None = None,
        implementation_order: int | None = None,
        status_detail: str | None = None,
        source_owner_directive: str | None = None,
        source_deliberation_query: str | None = None,
        related_deliberation_ids: str | None = None,
        related_spec_ids_at_creation: str | None = None,
        related_bridge_threads: str | None = None,
        depends_on_work_items: str | None = None,
        blocks_work_items: str | None = None,
        acceptance_summary: str | None = None,
        regression_visibility: str | None = None,
        completion_evidence: str | None = None,
        supersedes: str | None = None,
        superseded_by: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of a work item.

        Args:
            origin: 'regression', 'defect', 'new', or 'hygiene'.
            component: From the component taxonomy (e.g., 'agent_implementation', 'customer_interface').
            resolution_status: 'open', 'in_progress', 'resolved', or 'verified'.
            stage: Lifecycle stage — 'created', 'tested', 'backlogged', 'implementing', or 'resolved'.
                   Defaults to 'created'. For resolved WIs, pass stage='resolved'.
            source_spec_id: The specification this work item relates to (required for all origins).
            source_test_id: The test that revealed the failure (required for regression/defect).
            failure_description: What failed and why (required for regression/defect).
        """
        version = self._next_work_item_version(id)
        backlog_values = {
            "approval_state": approval_state,
            "project_name": project_name,
            "subproject_name": subproject_name,
            "implementation_order": implementation_order,
            "status_detail": status_detail,
            "source_owner_directive": source_owner_directive,
            "source_deliberation_query": source_deliberation_query,
            "related_deliberation_ids": related_deliberation_ids,
            "related_spec_ids_at_creation": related_spec_ids_at_creation,
            "related_bridge_threads": related_bridge_threads,
            "depends_on_work_items": depends_on_work_items,
            "blocks_work_items": blocks_work_items,
            "acceptance_summary": acceptance_summary,
            "regression_visibility": regression_visibility,
            "completion_evidence": completion_evidence,
            "supersedes": supersedes,
            "superseded_by": superseded_by,
        }
        columns = [
            "id",
            "version",
            "title",
            "description",
            "origin",
            "component",
            "source_spec_id",
            "source_test_id",
            "failure_description",
            "resolution_status",
            "priority",
            "stage",
            *WORK_ITEM_BACKLOG_FIELDS,
            "changed_by",
            "changed_at",
            "change_reason",
        ]
        values = [
            id,
            version,
            title,
            description,
            origin,
            component,
            source_spec_id,
            source_test_id,
            failure_description,
            resolution_status,
            priority,
            stage,
            *(backlog_values[field] for field in WORK_ITEM_BACKLOG_FIELDS),
            changed_by,
            _now(),
            change_reason,
        ]
        conn = self._get_conn()
        conn.execute(
            f"INSERT INTO work_items ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})",
            values,
        )
        try:
            self._record_event(
                conn,
                "wi_created",
                changed_by,
                artifact_id=id,
                artifact_type="work_item",
                artifact_version=version,
                metadata={
                    "origin": origin,
                    "component": component,
                    "priority": priority,
                    "resolution_status": resolution_status,
                    "stage": stage,
                    "project_name": project_name,
                    "subproject_name": subproject_name,
                    "implementation_order": implementation_order,
                    "status_detail": status_detail,
                    "source_spec_id": source_spec_id,
                    "source_test_id": source_test_id,
                },
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return self.get_work_item(id)

    def update_work_item(
        self,
        id: str,
        changed_by: str,
        change_reason: str,
        *,
        owner_approved: bool = False,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """Create a new version of a work item, carrying forward unchanged fields.

        Stage transitions are enforced per SPEC-1602:
        created → tested → backlogged → implementing → resolved.
        Any stage can transition to 'resolved' (early closure).

        Args:
            owner_approved: Required ``True`` for resolving defect/regression
                WIs (GOV-15 enforcement).  The caller must have received
                explicit owner approval in the conversation before setting this.
        """
        current = self.get_work_item(id)
        if not current:
            raise ValueError(f"Work item {id} not found")
        version = self._next_work_item_version(id)
        title = fields.get("title", current["title"])
        description = fields.get("description", current["description"])
        origin = fields.get("origin", current["origin"])
        component = fields.get("component", current["component"])
        source_spec_id = fields.get("source_spec_id", current["source_spec_id"])
        source_test_id = fields.get("source_test_id", current["source_test_id"])
        failure_description = fields.get("failure_description", current["failure_description"])
        resolution_status = fields.get("resolution_status", current["resolution_status"])
        priority = fields.get("priority", current["priority"])
        current_stage = current.get("stage", "created")
        new_stage = fields.get("stage", current_stage)
        backlog_values = {field: fields.get(field, current.get(field)) for field in WORK_ITEM_BACKLOG_FIELDS}
        # Enforce stage transitions (includes GOV-15 owner approval gate)
        self._validate_stage_transition(
            id,
            current_stage,
            new_stage,
            owner_approved=owner_approved,
        )
        conn = self._get_conn()
        columns = [
            "id",
            "version",
            "title",
            "description",
            "origin",
            "component",
            "source_spec_id",
            "source_test_id",
            "failure_description",
            "resolution_status",
            "priority",
            "stage",
            *WORK_ITEM_BACKLOG_FIELDS,
            "changed_by",
            "changed_at",
            "change_reason",
        ]
        values = [
            id,
            version,
            title,
            description,
            origin,
            component,
            source_spec_id,
            source_test_id,
            failure_description,
            resolution_status,
            priority,
            new_stage,
            *(backlog_values[field] for field in WORK_ITEM_BACKLOG_FIELDS),
            changed_by,
            _now(),
            change_reason,
        ]
        conn.execute(
            f"INSERT INTO work_items ({', '.join(columns)}) VALUES ({', '.join('?' for _ in columns)})",
            values,
        )
        try:
            actually_resolving = resolution_status == "resolved" and current["resolution_status"] != "resolved"
            if actually_resolving:
                self._record_event(
                    conn,
                    "wi_resolved",
                    changed_by,
                    artifact_id=id,
                    artifact_type="work_item",
                    artifact_version=version,
                    metadata={
                        "origin": origin,
                        "component": component,
                        "priority": priority,
                        "resolution_status": resolution_status,
                        "stage": new_stage,
                        "project_name": backlog_values.get("project_name"),
                        "subproject_name": backlog_values.get("subproject_name"),
                        "implementation_order": backlog_values.get("implementation_order"),
                        "status_detail": backlog_values.get("status_detail"),
                        "previous_resolution_status": current["resolution_status"],
                        "previous_stage": current.get("stage"),
                        "source_spec_id": source_spec_id,
                        "source_test_id": source_test_id,
                    },
                )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return self.get_work_item(id)

    def get_work_item(self, item_id: str) -> dict[str, Any] | None:
        """Return the latest version of a work item, or None if not found.

        Args:
            item_id: Work item identifier (e.g. ``"WI-0042"``).

        Returns:
            A dict of the current work item row with JSON fields pre-parsed,
            or ``None`` if no work item with that ID exists.
        """
        row = self._get_conn().execute("SELECT * FROM current_work_items WHERE id = ?", (item_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def get_work_item_history(self, item_id: str) -> list[dict[str, Any]]:
        """Return all versions of a work item, newest-first.

        Args:
            item_id: Work item identifier (e.g. ``"WI-0042"``).

        Returns:
            A list of version dicts ordered by ``version DESC``. Returns an
            empty list if no work item with that ID exists.
        """
        rows = (
            self._get_conn()
            .execute("SELECT * FROM work_items WHERE id = ? ORDER BY version DESC", (item_id,))
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_work_items(
        self,
        *,
        origin: str | None = None,
        component: str | None = None,
        resolution_status: str | None = None,
        priority: str | None = None,
        source_spec_id: str | None = None,
        project_name: str | None = None,
        subproject_name: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current work items with optional filters."""
        query = "SELECT * FROM current_work_items WHERE 1=1"
        params: list[Any] = []
        if origin:
            query += " AND origin = ?"
            params.append(origin)
        if component:
            query += " AND component = ?"
            params.append(component)
        if resolution_status:
            query += " AND resolution_status = ?"
            params.append(resolution_status)
        if priority:
            query += " AND priority = ?"
            params.append(priority)
        if source_spec_id:
            query += " AND source_spec_id = ?"
            params.append(source_spec_id)
        if project_name:
            query += " AND project_name = ?"
            params.append(project_name)
        if subproject_name:
            query += " AND subproject_name = ?"
            params.append(subproject_name)
        query += " ORDER BY implementation_order IS NULL, implementation_order, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_open_work_items(self) -> list[dict[str, Any]]:
        """Get all work items that are not terminal (the active backlog)."""
        placeholders = ", ".join("?" for _ in WORK_ITEM_TERMINAL_RESOLUTION_STATUSES)
        rows = (
            self._get_conn()
            .execute(
                f"""SELECT * FROM current_work_items
               WHERE resolution_status NOT IN ({placeholders})
               ORDER BY implementation_order IS NULL, implementation_order, priority, id""",
                WORK_ITEM_TERMINAL_RESOLUTION_STATUSES,
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Projects
    # ------------------------------------------------------------------

    def _next_project_version(self, project_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM projects WHERE id = ?", (project_id,)).fetchone()
        return (row[0] or 0) + 1

    def _next_project_membership_version(self, membership_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM project_work_item_memberships WHERE id = ?", (membership_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def _next_project_dependency_version(self, dependency_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM project_dependencies WHERE id = ?", (dependency_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def _next_project_artifact_link_version(self, link_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM project_artifact_links WHERE id = ?", (link_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def _next_project_authorization_version(self, authorization_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM project_authorizations WHERE id = ?", (authorization_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_project(
        self,
        name: str,
        changed_by: str,
        change_reason: str,
        *,
        id: str | None = None,
        status: str = "active",
        rank: int | None = None,
        parent_project_id: str | None = None,
        purpose: str | None = None,
        target_outcome: str | None = None,
        scope_note: str | None = None,
        start_date: str | None = None,
        target_date: str | None = None,
        completed_at: str | None = None,
        notes: str | None = None,
        source_project_name: str | None = None,
        source_subproject_name: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new project version.

        Projects are lifecycle/planning artifacts over work items. They do not
        replace ``work_items`` or ``current_work_items`` as backlog authority.
        """
        project_id = id or _project_id_from_names(name)
        version = self._next_project_version(project_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO projects
               (id, version, name, status, rank, parent_project_id, purpose, target_outcome,
                scope_note, start_date, target_date, completed_at, notes, source_project_name,
                source_subproject_name, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                project_id,
                version,
                name,
                status,
                rank,
                parent_project_id,
                purpose,
                target_outcome,
                scope_note,
                start_date,
                target_date,
                completed_at,
                notes,
                source_project_name,
                source_subproject_name,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_project(project_id)

    def get_project(self, project_id: str) -> dict[str, Any] | None:
        """Retrieve a project by its identifier.

        Args:
            project_id: Unique string identifier for the project.

        Returns:
            The project row as a dictionary, or None if not found.
        """
        row = self._get_conn().execute("SELECT * FROM current_projects WHERE id = ?", (project_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def list_projects(
        self,
        *,
        status: str | None = None,
        include_terminal: bool = False,
    ) -> list[dict[str, Any]]:
        """List current projects with optional status filtering.

        Args:
            status: Optional status string to filter projects.
            include_terminal: If True, terminal/completed projects are included.

        Returns:
            A list of project dictionaries matching the criteria.
        """
        query = "SELECT * FROM current_projects WHERE 1=1"
        params: list[Any] = []
        if status:
            query += " AND status = ?"
            params.append(status)
        elif not include_terminal:
            placeholders = ", ".join("?" for _ in PROJECT_TERMINAL_STATUSES)
            query += f" AND status NOT IN ({placeholders})"
            params.extend(PROJECT_TERMINAL_STATUSES)
        query += " ORDER BY rank IS NULL, rank, name, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def link_project_work_item(
        self,
        project_id: str,
        work_item_id: str,
        changed_by: str,
        change_reason: str,
        *,
        membership_role: str = "member",
        membership_order: int | None = None,
        status: str = "active",
        source: str | None = None,
        id: str | None = None,
    ) -> dict[str, Any] | None:
        """Link a project to a canonical work item without duplicating the work item."""
        if self.get_project(project_id) is None:
            raise ValueError(f"Project {project_id} not found")
        if self.get_work_item(work_item_id) is None:
            raise ValueError(f"Work item {work_item_id} not found")
        membership_id = id or _stable_project_link_id("PWM", project_id, work_item_id)
        version = self._next_project_membership_version(membership_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO project_work_item_memberships
               (id, version, project_id, work_item_id, membership_role, membership_order,
                status, source, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                membership_id,
                version,
                project_id,
                work_item_id,
                membership_role,
                membership_order,
                status,
                source,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_project_work_item_membership(membership_id)

    def get_project_work_item_membership(self, membership_id: str) -> dict[str, Any] | None:
        """Retrieve a project work item membership by ID.

        Args:
            membership_id: The membership identifier.

        Returns:
            The membership dictionary, or None if not found.
        """
        row = (
            self._get_conn()
            .execute("SELECT * FROM current_project_work_item_memberships WHERE id = ?", (membership_id,))
            .fetchone()
        )
        return _row_to_dict(row) if row else None

    def list_project_work_items(
        self,
        project_id: str,
        *,
        include_inactive: bool = False,
    ) -> list[dict[str, Any]]:
        """List work items linked to a given project.

        Args:
            project_id: The project identifier.
            include_inactive: If True, inactive memberships are included.

        Returns:
            A list of work item dictionaries with membership details.
        """
        query = """SELECT
                      m.id AS membership_id,
                      m.project_id AS project_id,
                      m.membership_role AS membership_role,
                      m.membership_order AS membership_order,
                      m.status AS membership_status,
                      m.source AS membership_source,
                      w.id AS work_item_id,
                      w.title AS work_item_title,
                      w.description AS work_item_description,
                      w.origin AS work_item_origin,
                      w.component AS work_item_component,
                      w.resolution_status AS resolution_status,
                      w.priority AS priority,
                      w.stage AS stage,
                      w.project_name AS compatibility_project_name,
                      w.subproject_name AS compatibility_subproject_name,
                      w.implementation_order AS implementation_order,
                      w.status_detail AS status_detail
                   FROM current_project_work_item_memberships m
                   INNER JOIN current_work_items w ON w.id = m.work_item_id
                   WHERE m.project_id = ?"""
        params: list[Any] = [project_id]
        if not include_inactive:
            query += " AND m.status = 'active'"
        query += " ORDER BY m.membership_order IS NULL, m.membership_order, w.implementation_order IS NULL, w.implementation_order, w.id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def add_project_dependency(
        self,
        from_project_id: str,
        to_project_id: str,
        changed_by: str,
        change_reason: str,
        *,
        dependency_type: str = "depends_on",
        rationale: str | None = None,
        blocking_status: str = "open",
        related_work_item_id: str | None = None,
        status: str = "active",
        id: str | None = None,
    ) -> dict[str, Any] | None:
        """Record a dependency between two projects.

        Args:
            from_project_id: Project that has the dependency.
            to_project_id: Project that is depended upon.
            changed_by: Person or agent performing the change.
            change_reason: Explanatory rationale for the change.
            dependency_type: Type classification of the dependency.
            rationale: Optional text rationale for the dependency.
            blocking_status: The current block status.
            related_work_item_id: Optional linked work item ID.
            status: Dependency record lifecycle status.
            id: Optional stable record identifier.

        Returns:
            The newly created project dependency record.
        """
        if self.get_project(from_project_id) is None:
            raise ValueError(f"Project {from_project_id} not found")
        if self.get_project(to_project_id) is None:
            raise ValueError(f"Project {to_project_id} not found")
        if related_work_item_id and self.get_work_item(related_work_item_id) is None:
            raise ValueError(f"Work item {related_work_item_id} not found")
        dependency_id = id or _stable_project_link_id("PDEP", from_project_id, to_project_id, dependency_type)
        version = self._next_project_dependency_version(dependency_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO project_dependencies
               (id, version, from_project_id, to_project_id, dependency_type, rationale,
                blocking_status, related_work_item_id, status, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                dependency_id,
                version,
                from_project_id,
                to_project_id,
                dependency_type,
                rationale,
                blocking_status,
                related_work_item_id,
                status,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_project_dependency(dependency_id)

    def get_project_dependency(self, dependency_id: str) -> dict[str, Any] | None:
        """Retrieve a project dependency record by ID.

        Args:
            dependency_id: The dependency identifier.

        Returns:
            The dependency dictionary, or None if not found.
        """
        row = (
            self._get_conn()
            .execute("SELECT * FROM current_project_dependencies WHERE id = ?", (dependency_id,))
            .fetchone()
        )
        return _row_to_dict(row) if row else None

    def list_project_dependencies(
        self,
        project_id: str,
        *,
        include_inactive: bool = False,
    ) -> list[dict[str, Any]]:
        """List dependencies where the given project is the source or target.

        Args:
            project_id: The project identifier.
            include_inactive: If True, inactive records are included.

        Returns:
            A list of project dependency dictionaries.
        """
        query = """SELECT * FROM current_project_dependencies
                   WHERE (from_project_id = ? OR to_project_id = ?)"""
        params: list[Any] = [project_id, project_id]
        if not include_inactive:
            query += " AND status = 'active'"
        query += " ORDER BY blocking_status, dependency_type, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def add_project_artifact_link(
        self,
        project_id: str,
        artifact_type: str,
        artifact_ref: str,
        changed_by: str,
        change_reason: str,
        *,
        relationship: str = "related",
        status: str = "active",
        notes: str | None = None,
        id: str | None = None,
    ) -> dict[str, Any] | None:
        """Create a link between a project and an artifact.

        Args:
            project_id: The project identifier.
            artifact_type: The type of artifact (e.g. spec, ADR).
            artifact_ref: Reference to the artifact.
            changed_by: Person or agent performing the change.
            change_reason: Explanatory rationale for the change.
            relationship: The relationship type.
            status: Lifecycle status of the link record.
            notes: Optional descriptive notes.
            id: Optional stable record identifier.

        Returns:
            The newly created project artifact link dictionary.
        """
        if self.get_project(project_id) is None:
            raise ValueError(f"Project {project_id} not found")
        link_id = id or _stable_project_link_id("PAL", project_id, artifact_type, artifact_ref, relationship)
        version = self._next_project_artifact_link_version(link_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO project_artifact_links
               (id, version, project_id, artifact_type, artifact_ref, relationship, status,
                notes, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                link_id,
                version,
                project_id,
                artifact_type,
                artifact_ref,
                relationship,
                status,
                notes,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_project_artifact_link(link_id)

    def get_project_artifact_link(self, link_id: str) -> dict[str, Any] | None:
        """Retrieve a project artifact link by its ID.

        Args:
            link_id: The link identifier.

        Returns:
            The artifact link dictionary, or None if not found.
        """
        row = (
            self._get_conn().execute("SELECT * FROM current_project_artifact_links WHERE id = ?", (link_id,)).fetchone()
        )
        return _row_to_dict(row) if row else None

    def list_project_artifact_links(
        self,
        project_id: str,
        *,
        include_inactive: bool = False,
    ) -> list[dict[str, Any]]:
        """List all artifact links associated with a project.

        Args:
            project_id: The project identifier.
            include_inactive: If True, inactive links are included.

        Returns:
            A list of project artifact link dictionaries.
        """
        query = "SELECT * FROM current_project_artifact_links WHERE project_id = ?"
        params: list[Any] = [project_id]
        if not include_inactive:
            query += " AND status = 'active'"
        query += " ORDER BY artifact_type, artifact_ref, relationship, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def list_project_artifact_links_for_artifact(
        self,
        artifact_type: str,
        artifact_ref: str,
        *,
        include_inactive: bool = False,
    ) -> list[dict[str, Any]]:
        """List all project links associated with a specific artifact.

        Args:
            artifact_type: The type of artifact.
            artifact_ref: Reference to the artifact.
            include_inactive: If True, inactive links are included.

        Returns:
            A list of project artifact link dictionaries.
        """
        query = """SELECT * FROM current_project_artifact_links
                   WHERE artifact_type = ? AND artifact_ref = ?"""
        params: list[Any] = [artifact_type, artifact_ref]
        if not include_inactive:
            query += " AND status = 'active'"
        query += " ORDER BY project_id, relationship, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def _validate_active_authorization_specs(self, included_spec_ids: list[str] | None) -> None:
        """Raise ValueError if an active project authorization cites no approved
        specification (GOV-PROJECT-REQUIRES-LINKED-SPECIFICATIONS-001 / WI-3312).

        A cited spec id satisfies the requirement when it resolves via
        ``get_spec()`` to a current ``specifications``-table row whose lifecycle
        ``status`` is in the approved set ``{specified, implemented, verified}``.
        No ``type`` allowlist is applied: membership in the ``specifications``
        table is itself the "is a specification" predicate -- the ``type``
        column is heterogeneous descriptive metadata, not an authorization
        discriminator.
        """
        approved_lifecycle = {"specified", "implemented", "verified"}
        if not included_spec_ids:
            raise ValueError(
                "Project authorization status='active' requires at least one "
                "included_spec_id "
                "(GOV-PROJECT-REQUIRES-LINKED-SPECIFICATIONS-001)."
            )
        resolved = 0
        invalid: list[str] = []
        for spec_id in included_spec_ids:
            row = self.get_spec(spec_id)
            if row is None:
                invalid.append(f"{spec_id}: not-found")
            elif row.get("status") not in approved_lifecycle:
                invalid.append(f"{spec_id}: status={row.get('status')}-not-approved")
            else:
                resolved += 1
        if resolved == 0:
            raise ValueError(
                "Project authorization status='active' requires at least one "
                "approved specification "
                "(GOV-PROJECT-REQUIRES-LINKED-SPECIFICATIONS-001). "
                f"Cited spec IDs failed resolution: {'; '.join(invalid)}"
            )

    def _validate_spec_amendment_approval_packet(
        self,
        *,
        prior_included: list[str] | None,
        prior_excluded: list[str] | None,
        new_included: list[str] | None,
        new_excluded: list[str] | None,
        change_reason: str,
        project_id: str,
        authorization_id: str,
    ) -> None:
        """Raise ValueError when a project-authorization version mutates its
        included/excluded spec sets without a real, owner-approved, covering
        formal-artifact-approval packet cited in ``change_reason``
        (DCL-PROJECT-SPECIFICATION-AMENDMENT-APPROVAL-REQUIRED-001 / WI-3313).

        Substring text alone is insufficient: the cited packet must resolve
        inside the project root's ``.groundtruth/formal-artifact-approvals/``,
        exist, parse as JSON, pass ``validate_packet()``, carry
        ``approved_by == "owner"``, and textually cover the amendment.
        """
        from groundtruth_kb.governance.approval_packet import (
            packet_covers_amendment,
            parse_packet_path_from_change_reason,
            validate_packet,
        )

        prior_inc, prior_exc = set(prior_included or []), set(prior_excluded or [])
        new_inc, new_exc = set(new_included or []), set(new_excluded or [])
        if prior_inc == new_inc and prior_exc == new_exc:
            return  # no spec amendment -- nothing to gate

        clause = "DCL-PROJECT-SPECIFICATION-AMENDMENT-APPROVAL-REQUIRED-001/CLAUSE-AMENDMENT-APPROVAL-REQUIRED"
        added = (new_inc - prior_inc) | (new_exc - prior_exc)
        removed = (prior_inc - new_inc) | (prior_exc - new_exc)

        rel_path = parse_packet_path_from_change_reason(change_reason or "")
        if rel_path is None:
            raise ValueError(
                "Project-authorization spec amendment requires an owner-approved "
                f"approval-packet path in change_reason ({clause}). "
                "No packet path detected."
            )
        project_root = self.db_path.resolve().parent
        packet_path = (project_root / rel_path).resolve()
        try:
            packet_path.relative_to(project_root)
        except ValueError as exc:
            raise ValueError(f"Approval-packet path resolves outside the project root ({clause}): {rel_path}") from exc
        if not packet_path.is_file():
            raise ValueError(f"Cited approval packet not found ({clause}): {rel_path}")
        try:
            packet = json.loads(packet_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            raise ValueError(f"Cited approval packet is not readable JSON ({clause}): {rel_path}: {exc}") from exc
        if not isinstance(packet, dict):
            raise ValueError(f"Cited approval packet is not a JSON object ({clause}): {rel_path}")
        result = validate_packet(packet)
        if not result.is_valid:
            detail = result.errors[0] if result.errors else "invalid packet"
            raise ValueError(f"Cited approval packet fails schema validation ({clause}): {rel_path}: {detail}")
        if packet.get("approved_by") != "owner":
            raise ValueError(f"Cited approval packet is not owner-approved ({clause}): {rel_path}")
        covers, reason = packet_covers_amendment(packet, project_id, authorization_id, added, removed)
        if not covers:
            raise ValueError(f"Cited approval packet does not cover the amendment ({clause}): {rel_path}: {reason}")

    def insert_project_authorization(
        self,
        project_id: str,
        authorization_name: str,
        owner_decision_deliberation_id: str,
        scope_summary: str,
        changed_by: str,
        change_reason: str,
        *,
        id: str | None = None,
        status: str = "active",
        allowed_mutation_classes: list[str] | None = None,
        forbidden_operations: list[str] | None = None,
        included_work_item_ids: list[str] | None = None,
        excluded_work_item_ids: list[str] | None = None,
        included_spec_ids: list[str] | None = None,
        excluded_spec_ids: list[str] | None = None,
        expires_at: str | None = None,
        supersedes: list[str] | None = None,
        superseded_by: list[str] | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new append-only project authorization version."""
        if self.get_project(project_id) is None:
            raise ValueError(f"Project {project_id} not found")
        if self.get_deliberation(owner_decision_deliberation_id) is None:
            raise ValueError(f"Owner decision deliberation {owner_decision_deliberation_id} not found")
        if not authorization_name.strip():
            raise ValueError("authorization_name is required")
        if not scope_summary.strip():
            raise ValueError("scope_summary is required")
        if status == "active":
            self._validate_active_authorization_specs(included_spec_ids)

        authorization_id = id or _stable_project_link_id("PAUTH", project_id, authorization_name)
        version = self._next_project_authorization_version(authorization_id)
        if version > 1:
            prior_authorization = self.get_project_authorization(authorization_id)
            if prior_authorization is not None:
                self._validate_spec_amendment_approval_packet(
                    prior_included=prior_authorization.get("included_spec_ids_parsed"),
                    prior_excluded=prior_authorization.get("excluded_spec_ids_parsed"),
                    new_included=included_spec_ids,
                    new_excluded=excluded_spec_ids,
                    change_reason=change_reason,
                    project_id=project_id,
                    authorization_id=authorization_id,
                )

        def encode(values: list[str] | None) -> str | None:
            if values is None:
                return None
            return json.dumps([str(value).strip() for value in values if str(value).strip()])

        conn = self._get_conn()
        conn.execute(
            """INSERT INTO project_authorizations
               (id, version, project_id, status, authorization_name, owner_decision_deliberation_id,
                scope_summary, allowed_mutation_classes, forbidden_operations, included_work_item_ids,
                excluded_work_item_ids, included_spec_ids, excluded_spec_ids, expires_at, supersedes,
                superseded_by, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                authorization_id,
                version,
                project_id,
                status,
                authorization_name,
                owner_decision_deliberation_id,
                scope_summary,
                encode(allowed_mutation_classes),
                encode(forbidden_operations),
                encode(included_work_item_ids),
                encode(excluded_work_item_ids),
                encode(included_spec_ids),
                encode(excluded_spec_ids),
                expires_at,
                encode(supersedes),
                encode(superseded_by),
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_project_authorization(authorization_id)

    def get_project_authorization(self, authorization_id: str) -> dict[str, Any] | None:
        """Retrieve a project authorization record by ID.

        Args:
            authorization_id: The authorization identifier.

        Returns:
            The authorization dictionary, or None if not found.
        """
        row = (
            self._get_conn()
            .execute("SELECT * FROM current_project_authorizations WHERE id = ?", (authorization_id,))
            .fetchone()
        )
        return _row_to_dict(row) if row else None

    def list_project_authorizations(
        self,
        project_id: str | None = None,
        *,
        status: str | None = None,
        include_terminal: bool = False,
    ) -> list[dict[str, Any]]:
        """List project authorizations matching filters.

        Args:
            project_id: Optional project identifier to filter by.
            status: Optional lifecycle status to filter by.
            include_terminal: If True, terminal/expired records are included.

        Returns:
            A list of project authorization dictionaries.
        """
        query = "SELECT * FROM current_project_authorizations WHERE 1=1"
        params: list[Any] = []
        if project_id:
            query += " AND project_id = ?"
            params.append(project_id)
        if status:
            query += " AND status = ?"
            params.append(status)
        elif not include_terminal:
            query += " AND status = 'active'"
        query += " ORDER BY project_id, authorization_name, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Typed Artifact-Flow Engine: flow definitions
    # ------------------------------------------------------------------

    def _next_flow_definition_version(self, definition_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM flow_definitions WHERE id = ?", (definition_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_flow_definition(
        self,
        id: str,
        flow_type: str,
        title: str,
        stage_sequence: list[str],
        required_roles_by_stage: dict[str, str],
        changed_by: str,
        change_reason: str,
        *,
        description: str | None = None,
        status: str = "active",
        auq_gate_positions: list[str] | None = None,
        never_self_review_stages: list[str] | None = None,
        deterministic_carve_outs: list[str] | dict[str, Any] | None = None,
        workspace_isolation: dict[str, Any] | None = None,
        source_spec_ids: list[str] | None = None,
    ) -> dict[str, Any] | None:
        """Append a versioned TAFE flow-definition record.

        Flow definitions are schema-level templates for later TAFE runtime
        work. This method stores JSON-shaped template metadata but does not
        seed canonical flow records, start a flow instance, or affect bridge
        dispatch authority.
        """
        if not id.strip():
            raise ValueError("flow definition id is required")
        if not flow_type.strip():
            raise ValueError("flow_type is required")
        if not title.strip():
            raise ValueError("title is required")
        if not stage_sequence:
            raise ValueError("stage_sequence must contain at least one stage")
        if not required_roles_by_stage:
            raise ValueError("required_roles_by_stage is required")

        missing_roles = [stage for stage in stage_sequence if stage not in required_roles_by_stage]
        if missing_roles:
            raise ValueError(f"required_roles_by_stage missing stages: {missing_roles}")

        def encode(value: Any) -> str | None:
            return json.dumps(value) if value is not None else None

        definition_id = id.strip()
        version = self._next_flow_definition_version(definition_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO flow_definitions
               (id, version, flow_type, title, name, description, status, lifecycle_status,
                stage_sequence, stages, required_roles_by_stage, required_roles,
                auq_gate_positions, never_self_review_stages, never_self_review_points,
                deterministic_carve_outs, deterministic_carveouts, workspace_isolation,
                source_spec_ids, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                definition_id,
                version,
                flow_type.strip(),
                title,
                title,
                description,
                status,
                status,
                encode(stage_sequence),
                encode(stage_sequence),
                encode(required_roles_by_stage),
                encode(required_roles_by_stage),
                encode(auq_gate_positions or []),
                encode(never_self_review_stages or []),
                encode(never_self_review_stages or []),
                encode(deterministic_carve_outs if deterministic_carve_outs is not None else []),
                encode(deterministic_carve_outs if deterministic_carve_outs is not None else []),
                encode(workspace_isolation or {}),
                encode(source_spec_ids or []),
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_flow_definition(definition_id)

    def get_flow_definition(self, definition_id: str) -> dict[str, Any] | None:
        """Return the latest version of a TAFE flow definition."""
        row = (
            self._get_conn().execute("SELECT * FROM current_flow_definitions WHERE id = ?", (definition_id,)).fetchone()
        )
        return _row_to_dict(row) if row else None

    def list_flow_definitions(
        self,
        *,
        flow_type: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current TAFE flow definitions with optional filters."""
        query = "SELECT * FROM current_flow_definitions WHERE 1=1"
        params: list[Any] = []
        if flow_type:
            query += " AND flow_type = ?"
            params.append(flow_type)
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY flow_type, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_flow_definition_history(self, definition_id: str) -> list[dict[str, Any]]:
        """Return all versions of a TAFE flow definition, newest-first."""
        rows = (
            self._get_conn()
            .execute("SELECT * FROM flow_definitions WHERE id = ? ORDER BY version DESC", (definition_id,))
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Typed Artifact-Flow Engine: runtime substrate
    # ------------------------------------------------------------------

    def _next_flow_instance_version(self, instance_id: str) -> int:
        row = (
            self._get_conn().execute("SELECT MAX(version) FROM flow_instances WHERE id = ?", (instance_id,)).fetchone()
        )
        return (row[0] or 0) + 1

    def insert_flow_instance(
        self,
        id: str,
        flow_definition_id: str,
        subject_type: str,
        subject_id: str,
        changed_by: str,
        change_reason: str,
        *,
        flow_definition_version: int | None = None,
        flow_type: str | None = None,
        status: str = "created",
        current_stage_instance_id: str | None = None,
        started_at: str | None = None,
        completed_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Append a versioned TAFE flow-instance row."""
        instance_id = self._insert_flow_instance_row(
            id,
            flow_definition_id,
            subject_type,
            subject_id,
            changed_by,
            change_reason,
            flow_definition_version=flow_definition_version,
            flow_type=flow_type,
            status=status,
            current_stage_instance_id=current_stage_instance_id,
            started_at=started_at,
            completed_at=completed_at,
            metadata=metadata,
        )
        self._get_conn().commit()
        return self.get_flow_instance(instance_id)

    def _insert_flow_instance_row(
        self,
        id: str,
        flow_definition_id: str,
        subject_type: str,
        subject_id: str,
        changed_by: str,
        change_reason: str,
        *,
        flow_definition_version: int | None = None,
        flow_type: str | None = None,
        status: str = "created",
        current_stage_instance_id: str | None = None,
        started_at: str | None = None,
        completed_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """No-commit core for the flow-instance INSERT (transaction-composable).

        Executes the append on the shared connection WITHOUT calling
        ``conn.commit()``, so it can be composed inside the single
        ``BEGIN IMMEDIATE … COMMIT`` of :meth:`insert_bridge_thread_atomic`. The
        public :meth:`insert_flow_instance` wraps this core with a commit, so its
        single-commit behavior is preserved byte-for-byte for every existing
        caller. Returns the inserted instance id.

        WI-4510 Phase 3 (``DCL-INDEX-GENERATED-VIEW-001`` #7): the
        ``tafe_canonical`` write path must persist the affected ``flow_instance``
        row and all its ``flow_artifacts`` rows in exactly one DB transaction; the
        per-row self-committing public methods must not be used on that path.
        """
        instance_id = _require_text("flow instance id", id)
        definition_id = _require_text("flow_definition_id", flow_definition_id)
        definition = self.get_flow_definition(definition_id)
        if definition is None:
            raise ValueError(f"unknown flow_definition_id: {definition_id}")
        definition_version = flow_definition_version if flow_definition_version is not None else definition["version"]
        instance_flow_type = flow_type or definition.get("flow_type")
        version = self._next_flow_instance_version(instance_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO flow_instances
               (id, version, flow_definition_id, flow_definition_version, flow_type,
                subject_type, subject_id, status, current_stage_instance_id,
                started_at, completed_at, metadata, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                instance_id,
                version,
                definition_id,
                definition_version,
                instance_flow_type,
                _require_text("subject_type", subject_type),
                _require_text("subject_id", subject_id),
                _require_text("status", status),
                current_stage_instance_id,
                started_at,
                completed_at,
                _encode_json(metadata or {}),
                _require_text("changed_by", changed_by),
                _now(),
                _require_text("change_reason", change_reason),
            ),
        )
        return instance_id

    def insert_bridge_thread_atomic(
        self,
        planned_instances: list[dict[str, Any]],
        planned_artifacts: list[dict[str, Any]],
        *,
        changed_by: str,
        change_reason: str,
    ) -> None:
        """Persist a bridge thread's shadow rows for ONE authoritative write atomically.

        Writes every planned ``flow_instances`` version and every planned
        ``flow_artifacts`` row for a single authoritative ``tafe_canonical`` bridge
        write inside one ``BEGIN IMMEDIATE … COMMIT`` transaction, fixing the
        independent-commit hazard where ``insert_flow_instance`` /
        ``insert_flow_artifact`` each commit separately (a crash between them could
        leave a half-written thread). Instances are inserted before artifacts so an
        artifact's instance-existence check passes within the same uncommitted
        transaction.

        ``planned_instances`` / ``planned_artifacts`` are lists of keyword-argument
        dicts for the no-commit cores (without ``changed_by`` / ``change_reason``,
        which are supplied uniformly here). The lists are usually length 1 / N for a
        single status write; an empty pair is a no-op. On any exception the whole
        transaction is rolled back and re-raised, so a divergent or interrupted
        write leaves zero rows from the attempt.

        WI-4510 Phase 3; ``DCL-INDEX-GENERATED-VIEW-001`` #7 (single DB commit) and
        the atomicity regression. Mirrors the ``BEGIN IMMEDIATE`` idiom already used
        by the stage-lease methods.
        """
        conn = self._get_conn()
        try:
            conn.execute("BEGIN IMMEDIATE")
            for instance_kwargs in planned_instances:
                self._insert_flow_instance_row(changed_by=changed_by, change_reason=change_reason, **instance_kwargs)
            for artifact_kwargs in planned_artifacts:
                self._insert_flow_artifact_row(changed_by=changed_by, change_reason=change_reason, **artifact_kwargs)
            conn.commit()
        except BaseException:
            conn.rollback()
            raise

    def get_flow_instance(self, instance_id: str) -> dict[str, Any] | None:
        """Return the current version of a TAFE flow instance."""
        row = self._get_conn().execute("SELECT * FROM current_flow_instances WHERE id = ?", (instance_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def get_flow_instance_history(self, instance_id: str) -> list[dict[str, Any]]:
        """Return all versions of a TAFE flow instance, newest-first."""
        rows = (
            self._get_conn()
            .execute("SELECT * FROM flow_instances WHERE id = ? ORDER BY version DESC", (instance_id,))
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_flow_instances(
        self,
        *,
        flow_definition_id: str | None = None,
        flow_type: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current TAFE flow instances with optional filters."""
        query = "SELECT * FROM current_flow_instances WHERE 1=1"
        params: list[Any] = []
        if flow_definition_id:
            query += " AND flow_definition_id = ?"
            params.append(flow_definition_id)
        if flow_type:
            query += " AND flow_type = ?"
            params.append(flow_type)
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY changed_at, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def _next_stage_instance_version(self, stage_instance_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM stage_instances WHERE id = ?", (stage_instance_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_stage_instance(
        self,
        id: str,
        flow_instance_id: str,
        stage_id: str,
        stage_index: int,
        required_role: str,
        changed_by: str,
        change_reason: str,
        *,
        status: str = "pending",
        claim_status: str = "unclaimed",
        claimed_by_harness_id: str | None = None,
        claimed_by_session_id: str | None = None,
        started_at: str | None = None,
        completed_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Append a versioned TAFE stage-instance row."""
        stage_instance_id = _require_text("stage instance id", id)
        instance_id = _require_text("flow_instance_id", flow_instance_id)
        if self.get_flow_instance(instance_id) is None:
            raise ValueError(f"unknown flow_instance_id: {instance_id}")
        if stage_index < 0:
            raise ValueError("stage_index must be non-negative")
        version = self._next_stage_instance_version(stage_instance_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO stage_instances
               (id, version, flow_instance_id, stage_id, stage_index, required_role,
                status, claim_status, claimed_by_harness_id, claimed_by_session_id,
                started_at, completed_at, metadata, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                stage_instance_id,
                version,
                instance_id,
                _require_text("stage_id", stage_id),
                stage_index,
                _require_text("required_role", required_role),
                _require_text("status", status),
                _require_text("claim_status", claim_status),
                claimed_by_harness_id,
                claimed_by_session_id,
                started_at,
                completed_at,
                _encode_json(metadata or {}),
                _require_text("changed_by", changed_by),
                _now(),
                _require_text("change_reason", change_reason),
            ),
        )
        conn.commit()
        return self.get_stage_instance(stage_instance_id)

    def get_stage_instance(self, stage_instance_id: str) -> dict[str, Any] | None:
        """Return the current version of a TAFE stage instance."""
        row = (
            self._get_conn()
            .execute("SELECT * FROM current_stage_instances WHERE id = ?", (stage_instance_id,))
            .fetchone()
        )
        return _row_to_dict(row) if row else None

    def get_stage_instance_history(self, stage_instance_id: str) -> list[dict[str, Any]]:
        """Return all versions of a TAFE stage instance, newest-first."""
        rows = (
            self._get_conn()
            .execute("SELECT * FROM stage_instances WHERE id = ? ORDER BY version DESC", (stage_instance_id,))
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_stage_instances(
        self,
        *,
        flow_instance_id: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current TAFE stage instances with optional filters."""
        query = "SELECT * FROM current_stage_instances WHERE 1=1"
        params: list[Any] = []
        if flow_instance_id:
            query += " AND flow_instance_id = ?"
            params.append(flow_instance_id)
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY flow_instance_id, stage_index, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def _next_stage_lease_version(self, lease_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM stage_leases WHERE id = ?", (lease_id,)).fetchone()
        return (row[0] or 0) + 1

    def insert_stage_lease(
        self,
        id: str,
        stage_instance_id: str,
        holder_harness_id: str,
        holder_session_id: str,
        ttl_seconds: int,
        changed_by: str,
        change_reason: str,
        *,
        lease_status: str = "active",
        acquired_at: str | None = None,
        heartbeat_at: str | None = None,
        expires_at: str | None = None,
        released_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Append a versioned TAFE stage-lease row without claim semantics."""
        lease_id = _require_text("stage lease id", id)
        stage_id = _require_text("stage_instance_id", stage_instance_id)
        if self.get_stage_instance(stage_id) is None:
            raise ValueError(f"unknown stage_instance_id: {stage_id}")
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        now = _now()
        version = self._next_stage_lease_version(lease_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO stage_leases
               (id, version, stage_instance_id, holder_harness_id, holder_session_id,
                lease_status, acquired_at, heartbeat_at, ttl_seconds, expires_at, released_at,
                metadata, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                lease_id,
                version,
                stage_id,
                _require_text("holder_harness_id", holder_harness_id),
                _require_text("holder_session_id", holder_session_id),
                _require_text("lease_status", lease_status),
                acquired_at or now,
                heartbeat_at,
                ttl_seconds,
                expires_at,
                released_at,
                _encode_json(metadata or {}),
                _require_text("changed_by", changed_by),
                now,
                _require_text("change_reason", change_reason),
            ),
        )
        conn.commit()
        return self.get_stage_lease(lease_id)

    def get_stage_lease(self, lease_id: str) -> dict[str, Any] | None:
        """Return the current version of a TAFE stage lease."""
        row = self._get_conn().execute("SELECT * FROM current_stage_leases WHERE id = ?", (lease_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def get_stage_lease_history(self, lease_id: str) -> list[dict[str, Any]]:
        """Return all versions of a TAFE stage lease, newest-first."""
        rows = (
            self._get_conn()
            .execute("SELECT * FROM stage_leases WHERE id = ? ORDER BY version DESC", (lease_id,))
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_stage_leases(
        self,
        *,
        stage_instance_id: str | None = None,
        lease_status: str | None = None,
        holder_harness_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current TAFE stage leases with optional filters."""
        query = "SELECT * FROM current_stage_leases WHERE 1=1"
        params: list[Any] = []
        if stage_instance_id:
            query += " AND stage_instance_id = ?"
            params.append(stage_instance_id)
        if lease_status:
            query += " AND lease_status = ?"
            params.append(lease_status)
        if holder_harness_id:
            query += " AND holder_harness_id = ?"
            params.append(holder_harness_id)
        query += " ORDER BY stage_instance_id, changed_at, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def _next_stage_attempt_telemetry_version(self, telemetry_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM stage_attempt_telemetry WHERE id = ?", (telemetry_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_stage_attempt_telemetry(
        self,
        id: str,
        flow_instance_id: str,
        stage_instance_id: str,
        changed_by: str,
        change_reason: str,
        *,
        attempt_number: int | None = None,
        agent_harness_id: str | None = None,
        agent_session_id: str | None = None,
        agent_context_id: str | None = None,
        model_identifier: str | None = None,
        provider: str | None = None,
        dispatch_decision: Any | None = None,
        lease_id: str | None = None,
        lease_lifecycle: Any | None = None,
        started_at: str | None = None,
        completed_at: str | None = None,
        duration_ms: int | None = None,
        token_count: int | None = None,
        cost: float | None = None,
        outcome: str | None = None,
        verdict: str | None = None,
        test_summary: Any | None = None,
        failure_class: str | None = None,
        cleanup_result: str | None = None,
        recovery_actions: Any | None = None,
        artifact_links: Any | None = None,
        status: str = "active",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Append a versioned TAFE per-stage-attempt telemetry row (SPEC-TAFE-R6).

        Pure recording substrate: the row is written from caller-supplied fields.
        No detection, aggregation, rollup, or recovery logic runs here (those are
        WI-4505/WI-4506). ``stage_instance_id`` must reference an existing stage
        instance, mirroring ``insert_stage_lease`` referential integrity.
        """
        telemetry_id = _require_text("stage attempt telemetry id", id)
        flow_id = _require_text("flow_instance_id", flow_instance_id)
        stage_id = _require_text("stage_instance_id", stage_instance_id)
        if self.get_stage_instance(stage_id) is None:
            raise ValueError(f"unknown stage_instance_id: {stage_id}")
        now = _now()
        version = self._next_stage_attempt_telemetry_version(telemetry_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO stage_attempt_telemetry
               (id, version, flow_instance_id, stage_instance_id, attempt_number,
                agent_harness_id, agent_session_id, agent_context_id, model_identifier, provider,
                dispatch_decision, lease_id, lease_lifecycle, started_at, completed_at,
                duration_ms, token_count, cost, outcome, verdict, test_summary,
                failure_class, cleanup_result, recovery_actions, artifact_links,
                status, metadata, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                telemetry_id,
                version,
                flow_id,
                stage_id,
                attempt_number,
                agent_harness_id,
                agent_session_id,
                agent_context_id,
                model_identifier,
                provider,
                _encode_json(dispatch_decision) if dispatch_decision is not None else None,
                lease_id,
                _encode_json(lease_lifecycle) if lease_lifecycle is not None else None,
                started_at,
                completed_at,
                duration_ms,
                token_count,
                cost,
                outcome,
                verdict,
                _encode_json(test_summary) if test_summary is not None else None,
                failure_class,
                cleanup_result,
                _encode_json(recovery_actions) if recovery_actions is not None else None,
                _encode_json(artifact_links) if artifact_links is not None else None,
                _require_text("status", status),
                _encode_json(metadata or {}),
                _require_text("changed_by", changed_by),
                now,
                _require_text("change_reason", change_reason),
            ),
        )
        conn.commit()
        return self.get_stage_attempt_telemetry(telemetry_id)

    def get_stage_attempt_telemetry(self, telemetry_id: str) -> dict[str, Any] | None:
        """Return the current version of a TAFE per-stage-attempt telemetry record."""
        row = (
            self._get_conn()
            .execute("SELECT * FROM current_stage_attempt_telemetry WHERE id = ?", (telemetry_id,))
            .fetchone()
        )
        return _row_to_dict(row) if row else None

    def get_stage_attempt_telemetry_history(self, telemetry_id: str) -> list[dict[str, Any]]:
        """Return all versions of a TAFE per-stage-attempt telemetry record, newest-first."""
        rows = (
            self._get_conn()
            .execute("SELECT * FROM stage_attempt_telemetry WHERE id = ? ORDER BY version DESC", (telemetry_id,))
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_stage_attempt_telemetry(
        self,
        *,
        flow_instance_id: str | None = None,
        stage_instance_id: str | None = None,
        outcome: str | None = None,
        failure_class: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current TAFE per-stage-attempt telemetry records with optional filters."""
        query = "SELECT * FROM current_stage_attempt_telemetry WHERE 1=1"
        params: list[Any] = []
        if flow_instance_id:
            query += " AND flow_instance_id = ?"
            params.append(flow_instance_id)
        if stage_instance_id:
            query += " AND stage_instance_id = ?"
            params.append(stage_instance_id)
        if outcome:
            query += " AND outcome = ?"
            params.append(outcome)
        if failure_class:
            query += " AND failure_class = ?"
            params.append(failure_class)
        query += " ORDER BY flow_instance_id, stage_instance_id, changed_at, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def _expired_active_stage_lease_rows(
        self,
        conn: sqlite3.Connection,
        *,
        as_of: str,
        limit: int | None,
    ) -> list[sqlite3.Row]:
        if limit is not None and limit <= 0:
            raise ValueError("limit must be positive")
        as_of_dt = _parse_iso_utc(_require_text("as_of", as_of))
        rows = conn.execute(
            """SELECT * FROM current_stage_leases
               WHERE lease_status = 'active' AND expires_at IS NOT NULL
               ORDER BY expires_at, stage_instance_id, id"""
        ).fetchall()
        expired: list[sqlite3.Row] = []
        for row in rows:
            try:
                expires_at = _parse_iso_utc(row["expires_at"])
            except ValueError as exc:
                raise ValueError(f"invalid expires_at for stage lease {row['id']}: {row['expires_at']}") from exc
            if expires_at <= as_of_dt:
                expired.append(row)
                if limit is not None and len(expired) >= limit:
                    break
        return expired

    def list_expired_stage_leases(self, *, as_of: str | None = None, limit: int | None = None) -> list[dict[str, Any]]:
        """List current active stage leases whose expiry is at or before ``as_of``."""

        rows = self._expired_active_stage_lease_rows(
            self._get_conn(),
            as_of=as_of or _now(),
            limit=limit,
        )
        return [_row_to_dict(row) for row in rows]

    def _active_stage_lease_row(self, conn: sqlite3.Connection, stage_instance_id: str) -> sqlite3.Row | None:
        return cast(
            sqlite3.Row | None,
            conn.execute(
                """SELECT * FROM current_stage_leases
                   WHERE stage_instance_id = ? AND lease_status = 'active'
                   ORDER BY changed_at DESC, id
                   LIMIT 1""",
                (stage_instance_id,),
            ).fetchone(),
        )

    def _append_stage_claim_state(
        self,
        conn: sqlite3.Connection,
        stage: sqlite3.Row,
        *,
        claim_status: str,
        claimed_by_harness_id: str | None,
        claimed_by_session_id: str | None,
        changed_by: str,
        change_reason: str,
    ) -> None:
        version = self._next_stage_instance_version(stage["id"])
        conn.execute(
            """INSERT INTO stage_instances
               (id, version, flow_instance_id, stage_id, stage_index, required_role,
                status, claim_status, claimed_by_harness_id, claimed_by_session_id,
                started_at, completed_at, metadata, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                stage["id"],
                version,
                stage["flow_instance_id"],
                stage["stage_id"],
                stage["stage_index"],
                stage["required_role"],
                stage["status"],
                claim_status,
                claimed_by_harness_id,
                claimed_by_session_id,
                stage["started_at"],
                stage["completed_at"],
                stage["metadata"],
                _require_text("changed_by", changed_by),
                _now(),
                _require_text("change_reason", change_reason),
            ),
        )

    def claim_stage_lease(
        self,
        stage_instance_id: str,
        holder_harness_id: str,
        holder_session_id: str,
        ttl_seconds: int,
        changed_by: str,
        change_reason: str,
        *,
        lease_id: str | None = None,
        acquired_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Acquire one active lease for a stage when no active lease exists."""
        stage_id = _require_text("stage_instance_id", stage_instance_id)
        holder_harness = _require_text("holder_harness_id", holder_harness_id)
        holder_session = _require_text("holder_session_id", holder_session_id)
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")

        conn = self._get_conn()
        try:
            conn.execute("BEGIN IMMEDIATE")
            stage = conn.execute("SELECT * FROM current_stage_instances WHERE id = ?", (stage_id,)).fetchone()
            if stage is None:
                raise ValueError(f"unknown stage_instance_id: {stage_id}")
            active = self._active_stage_lease_row(conn, stage_id)
            if active is not None:
                raise ValueError(f"stage already has active lease: {active['id']}")

            now = acquired_at or _now()
            next_lease_id = _require_text("stage lease id", lease_id or f"LEASE-{stage_id}")
            version = self._next_stage_lease_version(next_lease_id)
            conn.execute(
                """INSERT INTO stage_leases
                   (id, version, stage_instance_id, holder_harness_id, holder_session_id,
                    lease_status, acquired_at, heartbeat_at, ttl_seconds, expires_at, released_at,
                    metadata, changed_by, changed_at, change_reason)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    next_lease_id,
                    version,
                    stage_id,
                    holder_harness,
                    holder_session,
                    "active",
                    now,
                    now,
                    ttl_seconds,
                    _iso_plus_seconds(now, ttl_seconds),
                    None,
                    _encode_json(metadata or {}),
                    _require_text("changed_by", changed_by),
                    _now(),
                    _require_text("change_reason", change_reason),
                ),
            )
            self._append_stage_claim_state(
                conn,
                stage,
                claim_status="claimed",
                claimed_by_harness_id=holder_harness,
                claimed_by_session_id=holder_session,
                changed_by=changed_by,
                change_reason=change_reason,
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return self.get_stage_lease(next_lease_id)

    def release_stage_lease(
        self,
        stage_instance_id: str,
        holder_harness_id: str,
        holder_session_id: str,
        changed_by: str,
        change_reason: str,
        *,
        released_at: str | None = None,
    ) -> dict[str, Any] | None:
        """Release the active stage lease when called by its current holder."""
        stage_id = _require_text("stage_instance_id", stage_instance_id)
        holder_harness = _require_text("holder_harness_id", holder_harness_id)
        holder_session = _require_text("holder_session_id", holder_session_id)

        conn = self._get_conn()
        try:
            conn.execute("BEGIN IMMEDIATE")
            stage = conn.execute("SELECT * FROM current_stage_instances WHERE id = ?", (stage_id,)).fetchone()
            if stage is None:
                raise ValueError(f"unknown stage_instance_id: {stage_id}")
            active = self._active_stage_lease_row(conn, stage_id)
            if active is None:
                raise ValueError(f"stage has no active lease: {stage_id}")
            if active["holder_harness_id"] != holder_harness or active["holder_session_id"] != holder_session:
                raise ValueError("lease holder mismatch")

            now = released_at or _now()
            version = self._next_stage_lease_version(active["id"])
            conn.execute(
                """INSERT INTO stage_leases
                   (id, version, stage_instance_id, holder_harness_id, holder_session_id,
                    lease_status, acquired_at, heartbeat_at, ttl_seconds, expires_at, released_at,
                    metadata, changed_by, changed_at, change_reason)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    active["id"],
                    version,
                    stage_id,
                    holder_harness,
                    holder_session,
                    "released",
                    active["acquired_at"],
                    active["heartbeat_at"],
                    active["ttl_seconds"],
                    active["expires_at"],
                    now,
                    active["metadata"],
                    _require_text("changed_by", changed_by),
                    _now(),
                    _require_text("change_reason", change_reason),
                ),
            )
            self._append_stage_claim_state(
                conn,
                stage,
                claim_status="unclaimed",
                claimed_by_harness_id=None,
                claimed_by_session_id=None,
                changed_by=changed_by,
                change_reason=change_reason,
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return self.get_stage_lease(active["id"])

    def recover_expired_stage_leases(
        self,
        *,
        as_of: str | None = None,
        limit: int | None = None,
        changed_by: str,
        change_reason: str,
    ) -> list[dict[str, Any]]:
        """Append recovered lease versions and unclaim stages for expired active leases."""

        recovery_as_of = as_of or _now()
        actor = _require_text("changed_by", changed_by)
        reason = _require_text("change_reason", change_reason)

        conn = self._get_conn()
        recovered_ids: list[str] = []
        try:
            conn.execute("BEGIN IMMEDIATE")
            expired = self._expired_active_stage_lease_rows(conn, as_of=recovery_as_of, limit=limit)
            recovered_at = _now()
            for active in expired:
                stage = conn.execute(
                    "SELECT * FROM current_stage_instances WHERE id = ?",
                    (active["stage_instance_id"],),
                ).fetchone()
                if stage is None:
                    raise ValueError(f"unknown stage_instance_id: {active['stage_instance_id']}")

                active_dict = _row_to_dict(active)
                metadata = dict(active_dict.get("metadata_parsed") or {})
                metadata["recovery"] = {
                    "previous_lease_status": active["lease_status"],
                    "recovered_as_of": recovery_as_of,
                    "recovered_at": recovered_at,
                }
                version = self._next_stage_lease_version(active["id"])
                conn.execute(
                    """INSERT INTO stage_leases
                       (id, version, stage_instance_id, holder_harness_id, holder_session_id,
                        lease_status, acquired_at, heartbeat_at, ttl_seconds, expires_at, released_at,
                        metadata, changed_by, changed_at, change_reason)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        active["id"],
                        version,
                        active["stage_instance_id"],
                        active["holder_harness_id"],
                        active["holder_session_id"],
                        "recovered",
                        active["acquired_at"],
                        active["heartbeat_at"],
                        active["ttl_seconds"],
                        active["expires_at"],
                        recovered_at,
                        _encode_json(metadata),
                        actor,
                        recovered_at,
                        reason,
                    ),
                )
                self._append_stage_claim_state(
                    conn,
                    stage,
                    claim_status="unclaimed",
                    claimed_by_harness_id=None,
                    claimed_by_session_id=None,
                    changed_by=actor,
                    change_reason=reason,
                )
                recovered_ids.append(active["id"])
            conn.commit()
        except Exception:
            conn.rollback()
            raise

        return [lease for lease_id in recovered_ids if (lease := self.get_stage_lease(lease_id)) is not None]

    def heartbeat_stage_lease(
        self,
        stage_instance_id: str,
        holder_harness_id: str,
        holder_session_id: str,
        changed_by: str,
        change_reason: str,
        *,
        ttl_seconds: int | None = None,
        heartbeat_at: str | None = None,
    ) -> dict[str, Any] | None:
        """Renew the active stage lease heartbeat for its current holder."""
        stage_id = _require_text("stage_instance_id", stage_instance_id)
        holder_harness = _require_text("holder_harness_id", holder_harness_id)
        holder_session = _require_text("holder_session_id", holder_session_id)

        conn = self._get_conn()
        try:
            conn.execute("BEGIN IMMEDIATE")
            if conn.execute("SELECT 1 FROM current_stage_instances WHERE id = ?", (stage_id,)).fetchone() is None:
                raise ValueError(f"unknown stage_instance_id: {stage_id}")
            active = self._active_stage_lease_row(conn, stage_id)
            if active is None:
                raise ValueError(f"stage has no active lease: {stage_id}")
            if active["holder_harness_id"] != holder_harness or active["holder_session_id"] != holder_session:
                raise ValueError("lease holder mismatch")

            ttl = active["ttl_seconds"] if ttl_seconds is None else ttl_seconds
            if ttl <= 0:
                raise ValueError("ttl_seconds must be positive")
            now = heartbeat_at or _now()
            version = self._next_stage_lease_version(active["id"])
            conn.execute(
                """INSERT INTO stage_leases
                   (id, version, stage_instance_id, holder_harness_id, holder_session_id,
                    lease_status, acquired_at, heartbeat_at, ttl_seconds, expires_at, released_at,
                    metadata, changed_by, changed_at, change_reason)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    active["id"],
                    version,
                    stage_id,
                    holder_harness,
                    holder_session,
                    "active",
                    active["acquired_at"],
                    now,
                    ttl,
                    _iso_plus_seconds(now, ttl),
                    None,
                    active["metadata"],
                    _require_text("changed_by", changed_by),
                    _now(),
                    _require_text("change_reason", change_reason),
                ),
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        return self.get_stage_lease(active["id"])

    def _next_agent_capability_snapshot_version(self, snapshot_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM agent_capability_snapshots WHERE id = ?", (snapshot_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_agent_capability_snapshot(
        self,
        id: str,
        harness_id: str,
        role: str,
        changed_by: str,
        change_reason: str,
        *,
        harness_name: str | None = None,
        subject_scope: str | None = None,
        health_status: str = "unknown",
        reviewer_precedence: int | None = None,
        workspace_availability: str | None = None,
        model_identifier: str | None = None,
        capabilities: dict[str, Any] | None = None,
        captured_at: str | None = None,
        source: str | None = None,
        status: str = "active",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Append a versioned TAFE agent capability snapshot row.

        This is the bounded WI-4497 substrate: it records a point-in-time
        capability/health/precedence profile for a candidate harness so the
        later WI-4498 dispatch policy engine has governed inputs. It does not
        score candidates, evaluate eligibility, or select dispatch targets.
        """
        snapshot_id = _require_text("agent capability snapshot id", id)
        now = _now()
        version = self._next_agent_capability_snapshot_version(snapshot_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO agent_capability_snapshots
               (id, version, harness_id, harness_name, role, subject_scope,
                health_status, reviewer_precedence, workspace_availability,
                model_identifier, capabilities, captured_at, source, status,
                metadata, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                snapshot_id,
                version,
                _require_text("harness_id", harness_id),
                harness_name,
                _require_text("role", role),
                subject_scope,
                _require_text("health_status", health_status),
                reviewer_precedence,
                workspace_availability,
                model_identifier,
                _encode_json(capabilities or {}),
                captured_at or now,
                source,
                _require_text("status", status),
                _encode_json(metadata or {}),
                _require_text("changed_by", changed_by),
                now,
                _require_text("change_reason", change_reason),
            ),
        )
        conn.commit()
        return self.get_agent_capability_snapshot(snapshot_id)

    def get_agent_capability_snapshot(self, snapshot_id: str) -> dict[str, Any] | None:
        """Return the current version of a TAFE agent capability snapshot."""
        row = (
            self._get_conn()
            .execute("SELECT * FROM current_agent_capability_snapshots WHERE id = ?", (snapshot_id,))
            .fetchone()
        )
        return _row_to_dict(row) if row else None

    def get_agent_capability_snapshot_history(self, snapshot_id: str) -> list[dict[str, Any]]:
        """Return all versions of a TAFE agent capability snapshot, newest-first."""
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM agent_capability_snapshots WHERE id = ? ORDER BY version DESC",
                (snapshot_id,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_agent_capability_snapshots(
        self,
        *,
        harness_id: str | None = None,
        health_status: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current TAFE agent capability snapshots with optional filters."""
        query = "SELECT * FROM current_agent_capability_snapshots WHERE 1=1"
        params: list[Any] = []
        if harness_id:
            query += " AND harness_id = ?"
            params.append(harness_id)
        if health_status:
            query += " AND health_status = ?"
            params.append(health_status)
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY harness_id, captured_at, id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def insert_flow_event(
        self,
        id: str,
        flow_instance_id: str,
        event_type: str,
        changed_by: str,
        change_reason: str,
        *,
        stage_instance_id: str | None = None,
        event_at: str | None = None,
        event_payload: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Insert an append-only TAFE flow event row."""
        event_id = _require_text("flow event id", id)
        instance_id = _require_text("flow_instance_id", flow_instance_id)
        if self.get_flow_instance(instance_id) is None:
            raise ValueError(f"unknown flow_instance_id: {instance_id}")
        if stage_instance_id and self.get_stage_instance(stage_instance_id) is None:
            raise ValueError(f"unknown stage_instance_id: {stage_instance_id}")
        conn = self._get_conn()
        now = _now()
        conn.execute(
            """INSERT INTO flow_events
               (id, flow_instance_id, stage_instance_id, event_type, event_at,
                event_payload, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                event_id,
                instance_id,
                stage_instance_id,
                _require_text("event_type", event_type),
                event_at or now,
                _encode_json(event_payload or {}),
                _require_text("changed_by", changed_by),
                now,
                _require_text("change_reason", change_reason),
            ),
        )
        conn.commit()
        return self.get_flow_event(event_id)

    def get_flow_event(self, event_id: str) -> dict[str, Any] | None:
        """Return one TAFE flow event by ID."""
        row = self._get_conn().execute("SELECT * FROM flow_events WHERE id = ?", (event_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def list_flow_events(
        self,
        *,
        flow_instance_id: str | None = None,
        stage_instance_id: str | None = None,
        event_type: str | None = None,
    ) -> list[dict[str, Any]]:
        """List append-only TAFE flow events with optional filters."""
        query = "SELECT * FROM flow_events WHERE 1=1"
        params: list[Any] = []
        if flow_instance_id:
            query += " AND flow_instance_id = ?"
            params.append(flow_instance_id)
        if stage_instance_id:
            query += " AND stage_instance_id = ?"
            params.append(stage_instance_id)
        if event_type:
            query += " AND event_type = ?"
            params.append(event_type)
        query += " ORDER BY rowid"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def insert_flow_artifact(
        self,
        id: str,
        flow_instance_id: str,
        artifact_type: str,
        artifact_ref: str,
        changed_by: str,
        change_reason: str,
        *,
        stage_instance_id: str | None = None,
        relationship: str = "related",
        status: str = "active",
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Insert an append-only TAFE flow-artifact reference row."""
        artifact_id = self._insert_flow_artifact_row(
            id,
            flow_instance_id,
            artifact_type,
            artifact_ref,
            changed_by,
            change_reason,
            stage_instance_id=stage_instance_id,
            relationship=relationship,
            status=status,
            metadata=metadata,
        )
        self._get_conn().commit()
        return self.get_flow_artifact(artifact_id)

    def _insert_flow_artifact_row(
        self,
        id: str,
        flow_instance_id: str,
        artifact_type: str,
        artifact_ref: str,
        changed_by: str,
        change_reason: str,
        *,
        stage_instance_id: str | None = None,
        relationship: str = "related",
        status: str = "active",
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """No-commit core for the flow-artifact INSERT (transaction-composable).

        Executes the append on the shared connection WITHOUT calling
        ``conn.commit()`` so it composes inside :meth:`insert_bridge_thread_atomic`'s
        single transaction. The public :meth:`insert_flow_artifact` wraps it with a
        commit, preserving its exact single-commit behavior for every existing
        caller. Returns the inserted artifact id. The ``flow_instance`` existence
        check reads the shared connection, so an instance inserted earlier in the
        same uncommitted transaction is visible. WI-4510 Phase 3
        (``DCL-INDEX-GENERATED-VIEW-001`` #7).
        """
        artifact_id = _require_text("flow artifact id", id)
        instance_id = _require_text("flow_instance_id", flow_instance_id)
        if self.get_flow_instance(instance_id) is None:
            raise ValueError(f"unknown flow_instance_id: {instance_id}")
        if stage_instance_id and self.get_stage_instance(stage_instance_id) is None:
            raise ValueError(f"unknown stage_instance_id: {stage_instance_id}")
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO flow_artifacts
               (id, flow_instance_id, stage_instance_id, artifact_type, artifact_ref,
                relationship, status, metadata, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                artifact_id,
                instance_id,
                stage_instance_id,
                _require_text("artifact_type", artifact_type),
                _require_text("artifact_ref", artifact_ref),
                _require_text("relationship", relationship),
                _require_text("status", status),
                _encode_json(metadata or {}),
                _require_text("changed_by", changed_by),
                _now(),
                _require_text("change_reason", change_reason),
            ),
        )
        return artifact_id

    def get_flow_artifact(self, artifact_id: str) -> dict[str, Any] | None:
        """Return one TAFE flow-artifact reference by ID."""
        row = self._get_conn().execute("SELECT * FROM flow_artifacts WHERE id = ?", (artifact_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def list_flow_artifacts(
        self,
        *,
        flow_instance_id: str | None = None,
        stage_instance_id: str | None = None,
        artifact_type: str | None = None,
    ) -> list[dict[str, Any]]:
        """List append-only TAFE flow-artifact references with optional filters."""
        query = "SELECT * FROM flow_artifacts WHERE 1=1"
        params: list[Any] = []
        if flow_instance_id:
            query += " AND flow_instance_id = ?"
            params.append(flow_instance_id)
        if stage_instance_id:
            query += " AND stage_instance_id = ?"
            params.append(stage_instance_id)
        if artifact_type:
            query += " AND artifact_type = ?"
            params.append(artifact_type)
        query += " ORDER BY rowid"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def insert_harness(
        self,
        id: str,
        harness_name: str,
        harness_type: str,
        role: list[str],
        changed_by: str,
        change_reason: str,
        *,
        status: str = "registered",
        reviewer_precedence: int | None = None,
        invocation_surfaces: dict[str, Any] | None = None,
        capabilities_ref: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new append-only harness registry version.

        Implements REQ-HARNESS-REGISTRY-001 FR1. ``id`` is the durable harness
        identity (e.g. ``A`` / ``B`` / ``C``); each call appends the next
        version for that id. ``role`` is the role-set wire form (a list of
        role tokens) and is JSON-encoded; ``invocation_surfaces`` is an
        optional dict (interactive + headless surfaces) JSON-encoded.
        """
        if not str(id).strip():
            raise ValueError("harness id is required")
        if not harness_name.strip():
            raise ValueError("harness_name is required")
        if not harness_type.strip():
            raise ValueError("harness_type is required")
        conn = self._get_conn()
        version = int(
            conn.execute(
                "SELECT COALESCE(MAX(version), 0) + 1 FROM harnesses WHERE id = ?",
                (id,),
            ).fetchone()[0]
        )
        conn.execute(
            """INSERT INTO harnesses
               (id, version, harness_name, harness_type, status, role,
                reviewer_precedence, invocation_surfaces, capabilities_ref,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                harness_name,
                harness_type,
                status,
                json.dumps(list(role)),
                reviewer_precedence,
                json.dumps(invocation_surfaces) if invocation_surfaces is not None else None,
                capabilities_ref,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_harness(id)

    def get_harness(self, harness_id: str) -> dict[str, Any] | None:
        """Return the current (latest-version) harness row, or None."""
        row = self._get_conn().execute("SELECT * FROM current_harnesses WHERE id = ?", (harness_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def list_harnesses(self) -> list[dict[str, Any]]:
        """Return all current-version harness rows ordered by harness id."""
        rows = self._get_conn().execute("SELECT * FROM current_harnesses ORDER BY id").fetchall()
        return [_row_to_dict(r) for r in rows]

    def update_project_authorization(
        self,
        authorization_id: str,
        changed_by: str,
        change_reason: str,
        **fields: Any,
    ) -> dict[str, Any] | None:
        """Update fields of an existing project authorization by inserting a new version.

        Args:
            authorization_id: The authorization identifier.
            changed_by: Person or agent performing the change.
            change_reason: Explanatory rationale for the change.
            **fields: Keyword arguments of fields to update.

        Returns:
            The updated project authorization dictionary.
        """
        current = self.get_project_authorization(authorization_id)
        if current is None:
            raise ValueError(f"Project authorization {authorization_id} not found")
        allowed_fields = {
            "project_id",
            "status",
            "authorization_name",
            "owner_decision_deliberation_id",
            "scope_summary",
            "allowed_mutation_classes",
            "forbidden_operations",
            "included_work_item_ids",
            "excluded_work_item_ids",
            "included_spec_ids",
            "excluded_spec_ids",
            "expires_at",
            "supersedes",
            "superseded_by",
        }
        unknown = sorted(set(fields) - allowed_fields)
        if unknown:
            raise ValueError(f"Unsupported project authorization fields: {', '.join(unknown)}")

        def current_json(field: str) -> list[str] | None:
            parsed = current.get(f"{field}_parsed")
            if isinstance(parsed, list):
                return [str(value) for value in parsed]
            return None

        values = {
            "project_id": fields.get("project_id", current["project_id"]),
            "status": fields.get("status", current["status"]),
            "authorization_name": fields.get("authorization_name", current["authorization_name"]),
            "owner_decision_deliberation_id": fields.get(
                "owner_decision_deliberation_id", current["owner_decision_deliberation_id"]
            ),
            "scope_summary": fields.get("scope_summary", current["scope_summary"]),
            "allowed_mutation_classes": fields.get(
                "allowed_mutation_classes", current_json("allowed_mutation_classes")
            ),
            "forbidden_operations": fields.get("forbidden_operations", current_json("forbidden_operations")),
            "included_work_item_ids": fields.get("included_work_item_ids", current_json("included_work_item_ids")),
            "excluded_work_item_ids": fields.get("excluded_work_item_ids", current_json("excluded_work_item_ids")),
            "included_spec_ids": fields.get("included_spec_ids", current_json("included_spec_ids")),
            "excluded_spec_ids": fields.get("excluded_spec_ids", current_json("excluded_spec_ids")),
            "expires_at": fields.get("expires_at", current["expires_at"]),
            "supersedes": fields.get("supersedes", current_json("supersedes")),
            "superseded_by": fields.get("superseded_by", current_json("superseded_by")),
        }
        return self.insert_project_authorization(
            values["project_id"],
            values["authorization_name"],
            values["owner_decision_deliberation_id"],
            values["scope_summary"],
            changed_by,
            change_reason,
            id=authorization_id,
            status=values["status"],
            allowed_mutation_classes=values["allowed_mutation_classes"],
            forbidden_operations=values["forbidden_operations"],
            included_work_item_ids=values["included_work_item_ids"],
            excluded_work_item_ids=values["excluded_work_item_ids"],
            included_spec_ids=values["included_spec_ids"],
            excluded_spec_ids=values["excluded_spec_ids"],
            expires_at=values["expires_at"],
            supersedes=values["supersedes"],
            superseded_by=values["superseded_by"],
        )

    # ------------------------------------------------------------------
    # Backlog Snapshots
    # ------------------------------------------------------------------

    def _next_backlog_version(self, snapshot_id: str) -> int:
        row = (
            self._get_conn()
            .execute("SELECT MAX(version) FROM backlog_snapshots WHERE id = ?", (snapshot_id,))
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_backlog_snapshot(
        self,
        id: str,
        title: str,
        work_item_ids: list[str],
        changed_by: str,
        change_reason: str,
        *,
        description: str | None = None,
        snapshot_at: str | None = None,
        summary_by_origin: dict[str, Any] | None = None,
        summary_by_component: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new backlog snapshot.

        Args:
            work_item_ids: Ordered list of active work item IDs (priority order).
            summary_by_origin: Counts by origin (e.g., {"regression": 2, "defect": 5, "new": 12}).
            summary_by_component: Counts by component.
        """
        version = self._next_backlog_version(id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO backlog_snapshots
               (id, version, title, description, snapshot_at, work_item_ids,
                summary_by_origin, summary_by_component,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                title,
                description,
                snapshot_at or _now(),
                json.dumps(work_item_ids),
                json.dumps(summary_by_origin) if summary_by_origin else None,
                json.dumps(summary_by_component) if summary_by_component else None,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_backlog_snapshot(id)

    def get_backlog_snapshot(self, snapshot_id: str) -> dict[str, Any] | None:
        """Return the latest version of a backlog snapshot, or None if not found.

        Args:
            snapshot_id: Backlog snapshot identifier (e.g. ``"SNAP-001"``).

        Returns:
            A dict of the current backlog snapshot row with JSON fields
            (``work_item_ids``, ``summary_by_origin``, ``summary_by_component``)
            pre-parsed, or ``None`` if no snapshot with that ID exists.
        """
        row = (
            self._get_conn().execute("SELECT * FROM current_backlog_snapshots WHERE id = ?", (snapshot_id,)).fetchone()
        )
        return _row_to_dict(row) if row else None

    def get_backlog_snapshot_history(self, snapshot_id: str) -> list[dict[str, Any]]:
        """Return all versions of a backlog snapshot, newest-first.

        Args:
            snapshot_id: Backlog snapshot identifier (e.g. ``"SNAP-001"``).

        Returns:
            A list of version dicts ordered by ``version DESC``. Returns an
            empty list if no snapshot with that ID exists.
        """
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM backlog_snapshots WHERE id = ? ORDER BY version DESC",
                (snapshot_id,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_backlog_snapshots(self, *, limit: int = 20) -> list[dict[str, Any]]:
        """List backlog snapshots, most recent first."""
        rows = (
            self._get_conn()
            .execute(
                "SELECT * FROM current_backlog_snapshots ORDER BY snapshot_at DESC LIMIT ?",
                (limit,),
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def create_backlog_snapshot_from_current(
        self,
        snapshot_id: str,
        changed_by: str,
        change_reason: str,
        *,
        title: str | None = None,
        description: str | None = None,
    ) -> dict[str, Any] | None:
        """Create a backlog snapshot from the current state of open work items.

        Queries all non-verified work items, captures their IDs in priority order,
        and computes summary counts by origin and component.
        """
        open_items = self.get_open_work_items()
        work_item_ids = [item["id"] for item in open_items]
        summary_origin: dict[str, int] = {}
        summary_component: dict[str, int] = {}
        for item in open_items:
            o = item.get("origin", "unknown")
            c = item.get("component", "unknown")
            summary_origin[o] = summary_origin.get(o, 0) + 1
            summary_component[c] = summary_component.get(c, 0) + 1
        return self.insert_backlog_snapshot(
            id=snapshot_id,
            title=title or f"Backlog snapshot {snapshot_id}",
            work_item_ids=work_item_ids,
            changed_by=changed_by,
            change_reason=change_reason,
            description=description,
            summary_by_origin=summary_origin,
            summary_by_component=summary_component,
        )

    # ------------------------------------------------------------------
    # Assertion Runs
    # ------------------------------------------------------------------

    def insert_assertion_run(
        self,
        spec_id: str,
        spec_version: int,
        overall_passed: bool,
        results: list[dict[str, Any]],
        triggered_by: str,
    ) -> None:
        """Record the result of an assertion run for a specification.

        Inserts a row into ``assertion_runs`` capturing which spec version was
        tested, whether all assertions passed, and the per-assertion details.
        Also records a ``pipeline_event`` for audit purposes.

        Args:
            spec_id: The specification ID that was asserted (e.g. ``"SPEC-1234"``).
            spec_version: The spec version number that was evaluated.
            overall_passed: ``True`` if every assertion passed; ``False`` if any failed.
            results: List of per-assertion result dicts from the assertion runner.
            triggered_by: Actor or process that initiated the assertion run
                (e.g. ``"session-start-hook"``).
        """
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO assertion_runs
               (spec_id, spec_version, run_at, overall_passed, results, triggered_by)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (spec_id, spec_version, _now(), int(overall_passed), json.dumps(results), triggered_by),
        )
        if not overall_passed:
            failed = [r for r in results if not r.get("passed") and not r.get("skipped")]
            _log.warning(
                "Assertion %s v%d failed: %d of %d assertions", spec_id, spec_version, len(failed), len(results)
            )
        try:
            self._record_event(
                conn,
                "assertion_run",
                triggered_by,
                artifact_id=spec_id,
                artifact_type="spec",
                artifact_version=spec_version,
                metadata={"overall_passed": overall_passed, "triggered_by": triggered_by, "result_count": len(results)},
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise

    def get_latest_assertion_run(self, spec_id: str) -> dict[str, Any] | None:
        """Return the most recent assertion run for a specification, or None if none exist.

        Args:
            spec_id: The specification ID to look up (e.g. ``"SPEC-1234"``).

        Returns:
            A dict of the most recent assertion run row (including ``results`` as
            a pre-parsed list), or ``None`` if no assertion runs have been
            recorded for this spec.
        """
        row = (
            self._get_conn()
            .execute(
                """SELECT * FROM assertion_runs
               WHERE spec_id = ? ORDER BY rowid DESC LIMIT 1""",
                (spec_id,),
            )
            .fetchone()
        )
        return _row_to_dict(row) if row else None

    def get_all_latest_assertion_runs(self) -> list[dict[str, Any]]:
        """Get the most recent assertion run for each spec."""
        rows = (
            self._get_conn()
            .execute(
                """SELECT a.* FROM assertion_runs a
               INNER JOIN (
                   SELECT spec_id, MAX(rowid) AS max_rowid
                   FROM assertion_runs GROUP BY spec_id
               ) m ON a.spec_id = m.spec_id AND a.rowid = m.max_rowid
               ORDER BY a.spec_id"""
            )
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Session Prompts
    # ------------------------------------------------------------------

    def _next_session_prompt_version(self, session_id: str) -> int:
        row = (
            self._get_conn()
            .execute(
                "SELECT MAX(version) FROM session_prompts WHERE session_id = ?",
                (session_id,),
            )
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_session_prompt(
        self,
        session_id: str,
        prompt_text: str,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Store a next-session handoff prompt (append-only).

        Args:
            session_id: The session that generated this prompt (e.g. "S97").
            prompt_text: The full prompt text for the next session.
            context: Optional structured context (WIs changed, test counts, etc.).

        Multiple calls for the same session_id create versioned records.
        """
        version = self._next_session_prompt_version(session_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO session_prompts
               (session_id, version, event_type, created_at, prompt_text, context)
               VALUES (?, ?, 'created', ?, ?, ?)""",
            (session_id, version, _now(), prompt_text, json.dumps(context) if context else None),
        )
        conn.commit()
        return self.get_session_prompt(session_id)

    def get_session_prompt(self, session_id: str) -> dict[str, Any] | None:
        """Get the latest event for a specific session's handoff prompt."""
        row = (
            self._get_conn()
            .execute(
                """SELECT * FROM session_prompts
               WHERE session_id = ? ORDER BY rowid DESC LIMIT 1""",
                (session_id,),
            )
            .fetchone()
        )
        return _row_to_dict(row) if row else None

    def get_session_prompt_by_idempotency_key(
        self,
        session_id: str,
        idempotency_key: str,
    ) -> dict[str, Any] | None:
        """Retrieve a session prompt by its idempotency key.

        Args:
            idempotency_key: Unique key to identify the session prompt.

        Returns:
            Dictionary containing session prompt data or None if not found.
        """
        # Idempotency lookup for the deterministic handoff service
        # (SPEC-HANDOFF-PROMPT-DETERMINISTIC-SERVICE-001). The key is stored
        # inside the existing ``context`` JSON field, not a dedicated column.
        rows = (
            self._get_conn()
            .execute(
                """SELECT * FROM session_prompts
                   WHERE session_id = ? AND context IS NOT NULL
                   ORDER BY rowid DESC""",
                (session_id,),
            )
            .fetchall()
        )
        for row in rows:
            raw_context = row["context"]
            if not raw_context:
                continue
            try:
                ctx = json.loads(raw_context)
            except (TypeError, ValueError):
                continue
            if isinstance(ctx, dict) and ctx.get("idempotency_key") == idempotency_key:
                return _row_to_dict(row)
        return None

    def get_next_session_prompt(self) -> dict[str, Any] | None:
        """Get the latest unconsumed handoff prompt.

        A prompt is unconsumed if its most recent event is 'created' (not 'consumed').
        Returns the most recently created prompt that hasn't been consumed.
        """
        # Find session_ids whose latest event is 'created'
        row = (
            self._get_conn()
            .execute(
                """SELECT p.* FROM session_prompts p
               INNER JOIN (
                   SELECT session_id, MAX(rowid) AS max_rowid
                   FROM session_prompts GROUP BY session_id
               ) m ON p.session_id = m.session_id AND p.rowid = m.max_rowid
               WHERE p.event_type = 'created'
               ORDER BY p.rowid DESC LIMIT 1"""
            )
            .fetchone()
        )
        return _row_to_dict(row) if row else None

    def consume_session_prompt(self, session_id: str) -> None:
        """Record consumption of a session prompt (append-only — inserts new row)."""
        current = self.get_session_prompt(session_id)
        if not current:
            return
        version = self._next_session_prompt_version(session_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO session_prompts
               (session_id, version, event_type, created_at, prompt_text, context)
               VALUES (?, ?, 'consumed', ?, ?, ?)""",
            (session_id, version, _now(), current.get("prompt_text", ""), current.get("context")),
        )
        conn.commit()

    def list_session_prompts(self, *, include_consumed: bool = False) -> list[dict[str, Any]]:
        """List session prompts, optionally including consumed ones."""
        if include_consumed:
            rows = self._get_conn().execute("SELECT * FROM session_prompts ORDER BY rowid DESC").fetchall()
        else:
            # Only show sessions whose latest event is 'created'
            rows = (
                self._get_conn()
                .execute(
                    """SELECT p.* FROM session_prompts p
                   INNER JOIN (
                       SELECT session_id, MAX(rowid) AS max_rowid
                       FROM session_prompts GROUP BY session_id
                   ) m ON p.session_id = m.session_id AND p.rowid = m.max_rowid
                   WHERE p.event_type = 'created'
                   ORDER BY p.rowid DESC"""
                )
                .fetchall()
            )
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Dispatch Events
    # ------------------------------------------------------------------

    def _next_dispatch_event_version(self, event_id: str) -> int:
        row = (
            self._get_conn()
            .execute(
                "SELECT MAX(version) FROM dispatch_events WHERE id = ?",
                (event_id,),
            )
            .fetchone()
        )
        return (row[0] or 0) + 1

    def insert_dispatch_event(
        self,
        *,
        event_id: str,
        rule_id: str,
        target_kind: str = "rule_target",
        target_value: str | None = None,
        trigger_at: str | None = None,
        gate_result: str | None = None,
        payload_template_id: str | None = None,
        spawn_outcome: str | None = None,
        spawn_pid: int | None = None,
        spawn_exit_status: int | None = None,
        target: str | None = None,
        trigger: str | None = None,
        activity_gate: str,
        gate_passed: bool | None = None,
        dry_run: bool = True,
        payload: dict[str, Any] | None = None,
        changed_by: str = "dispatch-envelope-scheduler",
        change_reason: str = "dispatch-envelope event recorded",
    ) -> dict[str, Any] | None:
        """Insert a dispatch event into the database.

        Args:
            event_data: Dictionary containing dispatch event fields.

        Returns:
            The inserted dispatch event record.
        """
        resolved_target = target_value or target
        if not resolved_target:
            raise ValueError("target_value or target is required")
        resolved_gate = gate_result or ("pass" if gate_passed else "skip")
        resolved_spawn_outcome = spawn_outcome or (
            "dry_run" if dry_run else ("eligible" if resolved_gate == "pass" else "gate_skip")
        )
        now = _now()
        version = self._next_dispatch_event_version(event_id)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO dispatch_events
               (id, version, rule_id, target_kind, target_value, trigger_at, gate_result, payload_template_id,
                spawn_outcome, spawn_pid, spawn_exit_status, activity_gate, dry_run, payload,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                event_id,
                version,
                rule_id,
                target_kind,
                resolved_target,
                trigger_at or now,
                resolved_gate,
                payload_template_id or trigger,
                resolved_spawn_outcome,
                spawn_pid,
                spawn_exit_status,
                activity_gate,
                1 if dry_run else 0,
                json.dumps(payload) if payload else None,
                changed_by,
                now,
                change_reason,
            ),
        )
        conn.commit()
        row = conn.execute(
            "SELECT * FROM dispatch_events WHERE id = ? AND version = ?",
            (event_id, version),
        ).fetchone()
        return _row_to_dict(row) if row else None

    # ------------------------------------------------------------------
    # Audit Cadence
    # ------------------------------------------------------------------

    AUDIT_INTERVAL = 5  # every 5 sessions

    @staticmethod
    def parse_session_number(session_id: str) -> int | None:
        """Extract the numeric part from a session ID like 'S98'. Returns None if not parseable."""
        import re

        m = re.match(r"[Ss](\d+)$", session_id.strip())
        return int(m.group(1)) if m else None

    def is_audit_session(self, next_session_id: str, interval: int | None = None) -> bool:
        """Check whether the given session should be an audit session.

        Audit sessions occur every `interval` sessions (default: AUDIT_INTERVAL).
        S100, S105, S110, ... are audit sessions at interval=5.
        """
        n = self.parse_session_number(next_session_id)
        if n is None:
            return False
        return n % (interval or self.AUDIT_INTERVAL) == 0

    @staticmethod
    def get_audit_directive() -> str:
        """Return the standard audit session directive text."""
        return (
            "AUDIT SESSION: This is a scheduled self-care session. Before starting "
            "new feature work, perform a fresh-context review:\n"
            "1. Knowledge DB integrity — run assertions, check for status drift, "
            "verify append-only invariants hold\n"
            "2. MEMORY.md and CLAUDE.md — accuracy, staleness, contradictions, "
            "line count within limits\n"
            "3. Repeatable Procedures — still accurate? Any procedure defects "
            "from recent sessions?\n"
            "4. Open design debt — any patterns from recent sessions that need "
            "cleanup or consolidation?\n"
            "5. Hooks and scheduler — verify all hooks execute without errors "
            "(check stderr output)\n"
            "Report findings to the owner before proceeding with regular work."
        )

    # ------------------------------------------------------------------
    # Quality Scores (SPEC-1838)
    # ------------------------------------------------------------------

    def insert_quality_score(
        self,
        session_id: str,
        spec_coverage: float,
        defect_escape_rate: float,
        assertion_strength: float,
        change_failure_rate: float,
        test_freshness: float,
        coverage_delta: float,
        composite_score: float,
        details: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Insert a quality score record for a session."""
        conn = self._get_conn()
        now = _now()
        conn.execute(
            """INSERT OR REPLACE INTO quality_scores
               (session_id, computed_at, spec_coverage, defect_escape_rate,
                assertion_strength, change_failure_rate, test_freshness,
                coverage_delta, composite_score, details)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                session_id,
                now,
                spec_coverage,
                defect_escape_rate,
                assertion_strength,
                change_failure_rate,
                test_freshness,
                coverage_delta,
                composite_score,
                json.dumps(details) if details else None,
            ),
        )
        conn.commit()
        return self.get_quality_score(session_id)  # type: ignore[return-value]

    def get_quality_score(self, session_id: str) -> dict[str, Any] | None:
        """Get the quality score for a specific session."""
        row = self._get_conn().execute("SELECT * FROM quality_scores WHERE session_id = ?", (session_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def get_quality_scores(self, *, last: int = 10) -> list[dict[str, Any]]:
        """Get the most recent quality scores, newest first."""
        rows = (
            self._get_conn()
            .execute("SELECT * FROM quality_scores ORDER BY computed_at DESC LIMIT ?", (last,))
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def get_kpi_spec_test_mapping(self) -> dict[str, Any] | None:
        """Get the current Specification Test-Mapping Rate (STMR) KPI metrics."""
        row = self._get_conn().execute("SELECT * FROM kpi_spec_test_mapping").fetchone()
        return _row_to_dict(row) if row else None

    def get_kpi_deliberation_provenance(self) -> dict[str, Any] | None:
        """Get the current Deliberation Provenance Depth (DPD) KPI metrics."""
        row = self._get_conn().execute("SELECT * FROM kpi_deliberation_provenance").fetchone()
        return _row_to_dict(row) if row else None

    def get_kpi_backlog_churn(self) -> dict[str, Any] | None:
        """Get the current Backlog Churn and Drift Rate (BCDR) KPI metrics."""
        row = self._get_conn().execute("SELECT * FROM kpi_backlog_churn").fetchone()
        return _row_to_dict(row) if row else None

    # ------------------------------------------------------------------
    # Global History
    # ------------------------------------------------------------------

    def get_history(
        self, *, limit: int = 50, changed_by: str | None = None, table: str | None = None
    ) -> list[dict[str, Any]]:
        """Get recent changes across all tables, newest first."""
        parts = []
        params: list[Any] = []

        tables = {
            "specifications": ("id", "specifications", "title"),
            "test_procedures": ("id", "test_procedures", "title"),
            "operational_procedures": ("id", "operational_procedures", "title"),
            "environment_config": ("id", "environment_config", "key"),
            "documents": ("id", "documents", "title"),
            "tests": ("id", "tests", "title"),
            "test_plans": ("id", "test_plans", "title"),
            "test_plan_phases": ("id", "test_plan_phases", "title"),
            "work_items": ("id", "work_items", "title"),
            "projects": ("id", "projects", "name"),
            "project_authorizations": ("id", "project_authorizations", "authorization_name"),
            "backlog_snapshots": ("id", "backlog_snapshots", "title"),
        }

        for tbl_key, (id_col, tbl_name, title_col) in tables.items():
            if table and table != tbl_key:
                continue
            where = ""
            if changed_by:
                where = " WHERE changed_by = ?"
                params.append(changed_by)
            parts.append(
                f"SELECT '{tbl_key}' AS table_name, {id_col} AS record_id, "
                f"version, {title_col} AS title, changed_by, changed_at, change_reason "
                f"FROM {tbl_name}{where}"
            )

        if not parts:
            return []

        query = " UNION ALL ".join(parts) + f" ORDER BY changed_at DESC LIMIT {limit}"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Export / Backup
    # ------------------------------------------------------------------

    def export_json(self, output_path: str | Path | None = None) -> str:
        """Export the entire database as a JSON file (all tables, all rows).

        This is a full logical backup — every row from every table, preserving
        the complete append-only history. The export can be used to reconstruct
        the database from scratch if the SQLite file is lost or corrupted.

        Args:
            output_path: Where to write the JSON. Defaults to sibling of the DB
                         file with a UTC timestamp suffix.

        Returns:
            The path to the written file.
        """
        from datetime import datetime

        conn = self._get_conn()
        tables = [
            "specifications",
            "test_procedures",
            "operational_procedures",
            "assertion_runs",
            "session_prompts",
            "dispatch_events",
            "environment_config",
            "documents",
            "test_coverage",
            "tests",
            "test_plans",
            "test_plan_phases",
            "work_items",
            "projects",
            "project_work_item_memberships",
            "project_dependencies",
            "project_artifact_links",
            "project_authorizations",
            "backlog_snapshots",
            "quality_scores",
            "testable_elements",
            "deliberations",
            "deliberation_specs",
            "deliberation_work_items",
            "pipeline_events",
            "spec_quality_scores",
            "session_snapshots",
        ]
        export: dict[str, Any] = {"exported_at": _now(), "tables": {}}
        for table in tables:
            rows = conn.execute(f"SELECT * FROM {table} ORDER BY rowid").fetchall()
            export["tables"][table] = [_row_to_dict(r) for r in rows]

        if output_path is None:
            timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            output_path = self.db_path.parent / f"knowledge-export-{timestamp}.json"
        else:
            output_path = Path(output_path)

        output_path.write_text(json.dumps(export, indent=2, default=str), encoding="utf-8")
        return str(output_path)

    # ------------------------------------------------------------------
    # Summary stats
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Testable Elements (SPEC-1652/1653)
    # ------------------------------------------------------------------

    def _next_te_version(self, te_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM testable_elements WHERE id = ?", (te_id,)).fetchone()
        return (row[0] or 0) + 1

    def insert_testable_element(
        self,
        id: str,
        subsystem: str,
        page_or_module: str,
        name: str,
        element_type: str,
        expected_behavior: str,
        applicable_dimensions: list[str],
        changed_by: str,
        change_reason: str,
        *,
        spec_id: str | None = None,
        status: str = "active",
    ) -> dict[str, Any] | None:
        """Insert a new version of a testable element.

        Args:
            id: Unique identifier (e.g., "EL-dashboard-001").
            subsystem: Categorical (dashboard, team, config, inbox, api, auth, etc.).
            page_or_module: Where this element lives (page name or module path).
            name: Human-readable element name.
            element_type: button, text, input, chart, link, endpoint, config_field, etc.
            expected_behavior: What correct behavior looks like.
            applicable_dimensions: Which test dimensions apply (exists, correct_value, etc.).
            spec_id: Linked specification ID (nullable).
            status: 'active' or 'deprecated'.
        """
        version = self._next_te_version(id)
        dims_json = json.dumps(applicable_dimensions)
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO testable_elements
               (id, version, subsystem, page_or_module, name, element_type,
                expected_behavior, spec_id, applicable_dimensions, status,
                changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                subsystem,
                page_or_module,
                name,
                element_type,
                expected_behavior,
                spec_id,
                dims_json,
                status,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()
        return self.get_testable_element(id)

    def get_testable_element(self, te_id: str) -> dict[str, Any] | None:
        """Get the current (latest) version of a testable element."""
        row = self._get_conn().execute("SELECT * FROM current_testable_elements WHERE id = ?", (te_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def list_testable_elements(
        self,
        *,
        subsystem: str | None = None,
        page_or_module: str | None = None,
        element_type: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current testable elements with optional filters."""
        query = "SELECT * FROM current_testable_elements WHERE 1=1"
        params: list[Any] = []
        if subsystem:
            query += " AND subsystem = ?"
            params.append(subsystem)
        if page_or_module:
            query += " AND page_or_module = ?"
            params.append(page_or_module)
        if element_type:
            query += " AND element_type = ?"
            params.append(element_type)
        if status:
            query += " AND status = ?"
            params.append(status)
        query += " ORDER BY id"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_element_coverage_summary(self) -> dict[str, Any]:
        """Get coverage statistics per subsystem for quality dashboard."""
        conn = self._get_conn()
        # Count elements per subsystem
        subsystem_counts = conn.execute(
            """SELECT subsystem, COUNT(*) as total,
                      SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active
               FROM current_testable_elements
               GROUP BY subsystem ORDER BY subsystem"""
        ).fetchall()
        return {
            "subsystems": [
                {"subsystem": r["subsystem"], "total": r["total"], "active": r["active"]} for r in subsystem_counts
            ],
            "total_elements": sum(r["total"] for r in subsystem_counts),
            "total_active": sum(r["active"] for r in subsystem_counts),
        }

    # ------------------------------------------------------------------
    # Pipeline Events (SPEC-2099)
    # ------------------------------------------------------------------

    @staticmethod
    def _record_event(
        conn: sqlite3.Connection,
        event_type: str,
        changed_by: str,
        *,
        session_id: str | None = None,
        artifact_id: str | None = None,
        artifact_type: str | None = None,
        artifact_version: int | None = None,
        duration_ms: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Record a lifecycle event WITHIN an existing transaction.

        Does NOT commit — the caller commits alongside the artifact mutation.
        """
        event_id = str(uuid.uuid4())
        now = _now()
        conn.execute(
            """INSERT INTO pipeline_events
               (id, event_type, session_id, artifact_id, artifact_type,
                artifact_version, timestamp, duration_ms, metadata, changed_by)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                event_id,
                event_type,
                session_id,
                artifact_id,
                artifact_type,
                artifact_version,
                now,
                duration_ms,
                json.dumps(metadata) if metadata else None,
                changed_by,
            ),
        )
        return event_id

    def record_event(
        self,
        event_type: str,
        changed_by: str,
        *,
        session_id: str | None = None,
        artifact_id: str | None = None,
        artifact_type: str | None = None,
        artifact_version: int | None = None,
        duration_ms: int | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Record a lifecycle event (public API for external callers).

        Commits immediately in its own transaction.
        """
        conn = self._get_conn()
        event_id = self._record_event(
            conn,
            event_type,
            changed_by,
            session_id=session_id,
            artifact_id=artifact_id,
            artifact_type=artifact_type,
            artifact_version=artifact_version,
            duration_ms=duration_ms,
            metadata=metadata,
        )
        conn.commit()
        return event_id

    def list_events(
        self,
        *,
        event_type: str | None = None,
        artifact_id: str | None = None,
        artifact_type: str | None = None,
        session_id: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Query pipeline events with optional filters."""
        conn = self._get_conn()
        query = "SELECT * FROM pipeline_events WHERE 1=1"
        params: list[Any] = []
        if event_type:
            query += " AND event_type = ?"
            params.append(event_type)
        if artifact_id:
            query += " AND artifact_id = ?"
            params.append(artifact_id)
        if artifact_type:
            query += " AND artifact_type = ?"
            params.append(artifact_type)
        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_events_for_artifact(self, artifact_type: str, artifact_id: str) -> list[dict[str, Any]]:
        """Get all lifecycle events for a specific artifact, chronological."""
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT * FROM pipeline_events
               WHERE artifact_type = ? AND artifact_id = ?
               ORDER BY timestamp ASC""",
            (artifact_type, artifact_id),
        ).fetchall()
        return [_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Lifecycle Metrics (SPEC-2100)
    # ------------------------------------------------------------------

    @staticmethod
    def _metric(
        value: Any,
        *,
        numerator: int | None = None,
        denominator: int | None = None,
        unit: str = "ratio",
        sample_count: int | None = None,
        **extra: Any,
    ) -> dict[str, Any]:
        """Build a structured metric result with metadata."""
        result: dict[str, Any] = {"value": value, "unit": unit}
        if numerator is not None:
            result["numerator"] = numerator
        if denominator is not None:
            result["denominator"] = denominator
        if sample_count is not None:
            result["sample_count"] = sample_count
        result.update(extra)
        return result

    def compute_m2_spec_revision_rounds(self) -> dict[str, Any]:
        """M2: Average spec versions before reaching 'implemented' status."""
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT s.id, MIN(s.version) as impl_version
               FROM specifications s
               WHERE s.status = 'implemented'
               GROUP BY s.id"""
        ).fetchall()
        if not rows:
            return self._metric(None, unit="versions", sample_count=0, status="not_applicable")
        versions = [r["impl_version"] for r in rows]
        avg = sum(versions) / len(versions)
        return self._metric(
            round(avg, 2), unit="versions", sample_count=len(versions), min=min(versions), max=max(versions)
        )

    def compute_m4_spec_to_implemented_duration(self) -> dict[str, Any]:
        """M4: Average elapsed time from first 'specified' to first 'implemented' version."""
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT s.id,
                      MIN(CASE WHEN s.status = 'specified' THEN s.changed_at END) as first_specified,
                      MIN(CASE WHEN s.status = 'implemented' THEN s.changed_at END) as first_implemented
               FROM specifications s
               WHERE s.status IN ('specified', 'implemented')
               GROUP BY s.id
               HAVING first_specified IS NOT NULL AND first_implemented IS NOT NULL"""
        ).fetchall()
        if not rows:
            return self._metric(None, unit="hours", sample_count=0, status="not_applicable")
        durations = []
        for r in rows:
            try:
                spec_ts = datetime.fromisoformat(r["first_specified"])
                impl_ts = datetime.fromisoformat(r["first_implemented"])
                hours = (impl_ts - spec_ts).total_seconds() / 3600
                if hours >= 0:
                    durations.append(hours)
            except (ValueError, TypeError):
                continue
        if not durations:
            return self._metric(None, unit="hours", sample_count=0, status="not_applicable")
        durations.sort()
        avg = sum(durations) / len(durations)
        median = durations[len(durations) // 2]
        return self._metric(
            round(avg, 2),
            unit="hours",
            sample_count=len(durations),
            min=round(min(durations), 2),
            max=round(max(durations), 2),
            median=round(median, 2),
        )

    def compute_m6_defect_injection_rate(self, *, last_n_days: int | None = None) -> dict[str, Any]:
        """M6: Defect WIs created / specs implemented in the same time window."""
        conn = self._get_conn()
        time_filter = ""
        if last_n_days is not None:
            cutoff = (datetime.now(UTC) - __import__("datetime").timedelta(days=last_n_days)).isoformat()
            time_filter = f" AND changed_at >= '{cutoff}'"

        defect_count = conn.execute(
            f"SELECT COUNT(DISTINCT id) FROM work_items WHERE origin = 'defect' AND version = 1{time_filter}"
        ).fetchone()[0]

        impl_count = conn.execute(
            f"""SELECT COUNT(DISTINCT id) FROM specifications
                WHERE status = 'implemented'{time_filter}
                AND id NOT IN (SELECT id FROM specifications WHERE status = 'implemented' AND version < (
                    SELECT MIN(version) FROM specifications s2 WHERE s2.id = specifications.id AND s2.status = 'implemented'{time_filter}
                ))"""
        ).fetchone()[0]
        # Simpler: count specs that first became implemented in the window
        impl_count = conn.execute(
            f"""SELECT COUNT(DISTINCT s.id) FROM specifications s
                WHERE s.status = 'implemented'{time_filter}
                AND NOT EXISTS (
                    SELECT 1 FROM specifications s2 WHERE s2.id = s.id AND s2.status = 'implemented'
                    AND s2.changed_at < s.changed_at
                )"""
        ).fetchone()[0]

        if impl_count == 0:
            return self._metric(None, numerator=defect_count, denominator=0, unit="ratio", status="not_applicable")
        rate = defect_count / impl_count
        return self._metric(round(rate, 4), numerator=defect_count, denominator=impl_count, unit="ratio")

    def compute_m10_defect_resolution_duration(self) -> dict[str, Any]:
        """M10: Average time from wi_created(defect) to wi_resolved, event-backed."""
        conn = self._get_conn()
        # Find defect WIs with both created and resolved events
        rows = conn.execute(
            """SELECT e1.artifact_id,
                      MIN(e1.timestamp) as created_at,
                      MIN(e2.timestamp) as resolved_at
               FROM pipeline_events e1
               JOIN pipeline_events e2 ON e1.artifact_id = e2.artifact_id
                    AND e2.artifact_type = 'work_item' AND e2.event_type = 'wi_resolved'
               WHERE e1.artifact_type = 'work_item' AND e1.event_type = 'wi_created'
               GROUP BY e1.artifact_id"""
        ).fetchall()
        # Filter to defects using metadata
        defect_created = conn.execute(
            """SELECT artifact_id FROM pipeline_events
               WHERE event_type = 'wi_created' AND artifact_type = 'work_item'
               AND json_extract(metadata, '$.origin') = 'defect'"""
        ).fetchall()
        defect_ids = {r["artifact_id"] for r in defect_created}

        total_defects = len(defect_ids)
        durations = []
        for r in rows:
            if r["artifact_id"] not in defect_ids:
                continue
            try:
                c = datetime.fromisoformat(r["created_at"])
                r_ts = datetime.fromisoformat(r["resolved_at"])
                hours = (r_ts - c).total_seconds() / 3600
                if hours >= 0:
                    durations.append(hours)
            except (ValueError, TypeError):
                continue

        skipped = total_defects - len(durations)
        if not durations:
            return self._metric(
                None, unit="hours", sample_count=0, skipped_missing_event_count=skipped, status="not_applicable"
            )
        durations.sort()
        avg = sum(durations) / len(durations)
        median = durations[len(durations) // 2]
        return self._metric(
            round(avg, 2),
            unit="hours",
            sample_count=len(durations),
            min=round(min(durations), 2),
            max=round(max(durations), 2),
            median=round(median, 2),
            skipped_missing_event_count=skipped,
        )

    def compute_m11_regression_rate(self) -> dict[str, Any]:
        """M11: Failed assertion runs / total assertion runs (aggregate, not per-session)."""
        conn = self._get_conn()
        stats = conn.execute(
            "SELECT COUNT(*) as total, SUM(CASE WHEN overall_passed = 0 THEN 1 ELSE 0 END) as failed FROM assertion_runs"
        ).fetchone()
        total = stats["total"] or 0
        failed = stats["failed"] or 0
        if total == 0:
            return self._metric(None, numerator=0, denominator=0, unit="ratio", status="not_applicable")
        rate = failed / total
        return self._metric(round(rate, 6), numerator=failed, denominator=total, unit="ratio")

    def compute_m12_spec_retirement_rate(self) -> dict[str, Any]:
        """M12: retired / (retired + active) where active = implemented + verified + specified."""
        conn = self._get_conn()
        counts = conn.execute("SELECT status, COUNT(*) as cnt FROM current_specifications GROUP BY status").fetchall()
        status_map = {r["status"]: r["cnt"] for r in counts}
        retired = status_map.get("retired", 0)
        active = sum(status_map.get(s, 0) for s in ("specified", "implemented", "verified"))
        denom = retired + active
        if denom == 0:
            return self._metric(None, numerator=0, denominator=0, unit="ratio", status="not_applicable")
        rate = retired / denom
        return self._metric(round(rate, 4), numerator=retired, denominator=denom, unit="ratio")

    def compute_m16_verified_with_passing_tests_rate(self) -> dict[str, Any]:
        """M16: Verified specs where ALL live linked test artifacts have last_result='pass'."""
        conn = self._get_conn()
        verified_specs = conn.execute("SELECT id FROM current_specifications WHERE status = 'verified'").fetchall()
        if not verified_specs:
            return self._metric(None, numerator=0, denominator=0, unit="ratio", status="not_applicable")
        verified_with_evidence = 0
        for spec_row in verified_specs:
            sid = spec_row["id"]
            tests = conn.execute(
                """SELECT last_result, test_file FROM current_tests
                   WHERE spec_id = ?
                   AND test_file IS NOT NULL
                   AND TRIM(test_file) != ''
                   AND COALESCE(last_result, '') NOT IN ('stale', 'historical_agent_red')""",
                (sid,),
            ).fetchall()
            if not tests:
                continue  # No tests = not verified with evidence
            all_pass = all(t["last_result"] == "pass" and bool((t["test_file"] or "").strip()) for t in tests)
            if all_pass:
                verified_with_evidence += 1
        denom = len(verified_specs)
        return self._metric(
            round(verified_with_evidence / denom, 4),
            numerator=verified_with_evidence,
            denominator=denom,
            unit="ratio",
        )

    def compute_m17_stale_test_ratio(self, *, now: str | None = None) -> dict[str, Any]:
        """M17: Live tests with last_executed_at >30 days old or null / total live tests.

        Args:
            now: ISO timestamp to use as "current time" (for deterministic tests).
                 Defaults to actual current time.
        """
        conn = self._get_conn()
        live_filter = """test_file IS NOT NULL
            AND TRIM(test_file) != ''
            AND COALESCE(last_result, '') NOT IN ('stale', 'historical_agent_red')"""
        total = conn.execute(f"SELECT COUNT(*) FROM current_tests WHERE {live_filter}").fetchone()[0]
        if total == 0:
            return self._metric(None, numerator=0, denominator=0, unit="ratio", status="not_applicable")
        if now is None:
            now = _now()
        cutoff = (datetime.fromisoformat(now) - __import__("datetime").timedelta(days=30)).isoformat()
        stale = conn.execute(
            f"""SELECT COUNT(*) FROM current_tests
                WHERE {live_filter}
                AND (last_executed_at IS NULL OR last_executed_at < ?)""",
            (cutoff,),
        ).fetchone()[0]
        return self._metric(round(stale / total, 4), numerator=stale, denominator=total, unit="ratio")

    def compute_m18_implemented_without_test_count(self) -> dict[str, Any]:
        """M18: Implemented/verified specs with zero current linked tests."""
        conn = self._get_conn()
        total_impl = conn.execute(
            "SELECT COUNT(*) FROM current_specifications WHERE status IN ('implemented', 'verified')"
        ).fetchone()[0]
        if total_impl == 0:
            return self._metric(None, numerator=0, denominator=0, unit="count", status="not_applicable")
        rows = conn.execute(
            """SELECT s.id FROM current_specifications s
               WHERE s.status IN ('implemented', 'verified')
               AND NOT EXISTS (
                   SELECT 1 FROM test_coverage c WHERE c.spec_id = s.id
               )
               AND NOT EXISTS (
                   SELECT 1 FROM current_tests t
                   WHERE t.spec_id = s.id
                   AND t.test_file IS NOT NULL
                   AND TRIM(t.test_file) != ''
                   AND COALESCE(t.last_result, '') NOT IN ('stale', 'historical_agent_red')
               )"""
        ).fetchall()
        return self._metric(len(rows), denominator=total_impl, unit="count", spec_ids=[r["id"] for r in rows])

    def get_lifecycle_metrics(self, *, last_n_days: int | None = None) -> dict[str, Any]:
        """Compute all available Phase 1 lifecycle metrics.

        Args:
            last_n_days: Time window filter (applied where supported). None = all time.

        Returns dict keyed by metric ID (M2, M4, etc.) with structured values.
        """
        return {
            "M2": self.compute_m2_spec_revision_rounds(),
            "M4": self.compute_m4_spec_to_implemented_duration(),
            "M6": self.compute_m6_defect_injection_rate(last_n_days=last_n_days),
            "M10": self.compute_m10_defect_resolution_duration(),
            "M11": self.compute_m11_regression_rate(),
            "M12": self.compute_m12_spec_retirement_rate(),
            "M16": self.compute_m16_verified_with_passing_tests_rate(),
            "M17": self.compute_m17_stale_test_ratio(),
            "M18": self.compute_m18_implemented_without_test_count(),
        }

    # ------------------------------------------------------------------
    # Deliberations
    # ------------------------------------------------------------------

    # Redaction patterns for credential/PII scanning.
    #
    # Sourced from ``groundtruth_kb.governance.credential_patterns`` — the
    # canonical cross-consumer catalog. The list shape ``(name, pattern)``
    # is preserved so ``redact_content()`` and any downstream code that
    # iterates ``_REDACTION_PATTERNS`` remain unchanged. See
    # ``bridge/gtkb-credential-patterns-canonical-007.md`` (proposal)
    # and ``-008.md`` (GO) for the consolidation rationale.
    _REDACTION_PATTERNS: list[tuple[str, re.Pattern[str]]] = db_pattern_list()

    @classmethod
    def redact_content(cls, text: str) -> tuple[str, str | None]:
        """Scan text for credentials/PII and replace with [REDACTED:type] markers.

        Returns (redacted_text, redaction_notes). If nothing was redacted,
        redaction_notes is None.
        """
        notes: list[str] = []
        result = text
        for label, pattern in cls._REDACTION_PATTERNS:
            matches = pattern.findall(result)
            if matches:
                result = pattern.sub(f"[REDACTED:{label}]", result)
                notes.append(f"{label}: {len(matches)} occurrence(s)")
        return result, "; ".join(notes) if notes else None

    def _next_deliberation_version(self, delib_id: str) -> int:
        row = self._get_conn().execute("SELECT MAX(version) FROM deliberations WHERE id = ?", (delib_id,)).fetchone()
        return (row[0] or 0) + 1

    def insert_deliberation(
        self,
        id: str,
        source_type: str,
        title: str,
        summary: str,
        content: str,
        changed_by: str,
        change_reason: str,
        *,
        spec_id: str | None = None,
        work_item_id: str | None = None,
        source_ref: str | None = None,
        participants: list[str] | None = None,
        outcome: str | None = None,
        session_id: str | None = None,
        sensitivity: str = "normal",
        origin_project: str | None = None,
        origin_repo: str | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new version of a deliberation record.

        Content is redacted before storage. The SHA-256 hash of the
        pre-redaction text is stored in content_hash for dedup and audit.
        """
        valid_source_types = {
            "lo_review",
            "proposal",
            "owner_conversation",
            "report",
            "session_harvest",
            "bridge_thread",
        }
        if source_type not in valid_source_types:
            raise ValueError(f"Invalid source_type '{source_type}'; must be one of {sorted(valid_source_types)}")

        valid_outcomes = {"go", "no_go", "deferred", "owner_decision", "informational", None}
        if outcome not in valid_outcomes:
            raise ValueError(f"Invalid outcome '{outcome}'; must be one of {sorted(o for o in valid_outcomes if o)}")

        # Hash raw content before redaction (for dedup)
        content_hash = hashlib.sha256(content.encode()).hexdigest()

        # Redact credentials/PII
        redacted_content, redaction_notes = self.redact_content(content)
        redaction_state = "redacted" if redaction_notes else "clean"
        if redaction_notes:
            sensitivity = "contains_redacted"

        version = self._next_deliberation_version(id)
        participants_json = json.dumps(participants) if participants else None
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO deliberations
               (id, version, spec_id, work_item_id, source_type, source_ref,
                title, summary, content, content_hash, participants, outcome,
                session_id, sensitivity, redaction_state, redaction_notes,
                origin_project, origin_repo, changed_by, changed_at, change_reason)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                id,
                version,
                spec_id,
                work_item_id,
                source_type,
                source_ref,
                title,
                summary,
                redacted_content,
                content_hash,
                participants_json,
                outcome,
                session_id,
                sensitivity,
                redaction_state,
                redaction_notes,
                origin_project,
                origin_repo,
                changed_by,
                _now(),
                change_reason,
            ),
        )
        conn.commit()

        # Sync to ChromaDB (delete stale + index current).
        # ChromaDB is optional and rebuildable — failures must not make
        # the canonical SQLite write appear failed.
        try:
            self._index_deliberation_in_chroma(id)
        except Exception as _idx_err:  # intentional-catch: ChromaDB optional, SQLite canonical
            _log.warning("ChromaDB index failed for %s (rebuildable): %s", id, _idx_err)

        return self.get_deliberation(id)

    def upsert_deliberation_source(
        self,
        source_type: str,
        source_ref: str,
        content: str,
        **kwargs: Any,
    ) -> dict[str, Any] | None:
        """Idempotent insert keyed on (source_ref, content_hash).

        If a deliberation with the same source_ref and content_hash already
        exists, returns the existing record without modification. Otherwise
        inserts a new deliberation.
        """
        content_hash = hashlib.sha256(content.encode()).hexdigest()
        conn = self._get_conn()
        existing = conn.execute(
            """SELECT id FROM current_deliberations
               WHERE source_ref = ? AND content_hash = ?""",
            (source_ref, content_hash),
        ).fetchone()
        if existing:
            return self.get_deliberation(existing["id"])

        # Generate next DELIB ID — use MAX numeric suffix, not last rowid,
        # so append-only versioning of lower IDs does not corrupt allocation.
        row = conn.execute(
            "SELECT MAX(CAST(SUBSTR(id, 7) AS INTEGER)) FROM deliberations WHERE id LIKE 'DELIB-%'"
        ).fetchone()
        if row and row[0] is not None:
            new_id = f"DELIB-{row[0] + 1:04d}"
        else:
            new_id = "DELIB-0001"

        return self.insert_deliberation(
            id=new_id,
            source_type=source_type,
            source_ref=source_ref,
            content=content,
            **kwargs,
        )

    def get_deliberation(self, delib_id: str) -> dict[str, Any] | None:
        """Get the current (latest) version of a deliberation."""
        row = self._get_conn().execute("SELECT * FROM current_deliberations WHERE id = ?", (delib_id,)).fetchone()
        return _row_to_dict(row) if row else None

    def get_deliberation_history(self, delib_id: str) -> list[dict[str, Any]]:
        """Get all versions of a deliberation."""
        rows = (
            self._get_conn()
            .execute("SELECT * FROM deliberations WHERE id = ? ORDER BY version", (delib_id,))
            .fetchall()
        )
        return [_row_to_dict(r) for r in rows]

    def list_deliberations(
        self,
        *,
        spec_id: str | None = None,
        work_item_id: str | None = None,
        source_type: str | None = None,
        session_id: str | None = None,
        source_ref: str | None = None,
        outcome: str | None = None,
    ) -> list[dict[str, Any]]:
        """List current deliberations with optional filters."""
        query = "SELECT * FROM current_deliberations WHERE 1=1"
        params: list[Any] = []
        if spec_id is not None:
            query += " AND spec_id = ?"
            params.append(spec_id)
        if work_item_id is not None:
            query += " AND work_item_id = ?"
            params.append(work_item_id)
        if source_type is not None:
            query += " AND source_type = ?"
            params.append(source_type)
        if session_id is not None:
            query += " AND session_id = ?"
            params.append(session_id)
        if source_ref is not None:
            query += " AND source_ref = ?"
            params.append(source_ref)
        if outcome is not None:
            query += " AND outcome = ?"
            params.append(outcome)
        query += " ORDER BY rowid DESC"
        rows = self._get_conn().execute(query, params).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_deliberations_for_spec(self, spec_id: str) -> list[dict[str, Any]]:
        """Get all deliberations linked to a spec (primary FK + relation table)."""
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT DISTINCT d.* FROM current_deliberations d
               WHERE d.spec_id = ?
               UNION
               SELECT DISTINCT d.* FROM current_deliberations d
               INNER JOIN deliberation_specs ds ON d.id = ds.deliberation_id
               WHERE ds.spec_id = ?
               ORDER BY rowid DESC""",
            (spec_id, spec_id),
        ).fetchall()
        return [_row_to_dict(r) for r in rows]

    def get_deliberations_for_work_item(self, work_item_id: str) -> list[dict[str, Any]]:
        """Get all deliberations linked to a work item (primary FK + relation table)."""
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT DISTINCT d.* FROM current_deliberations d
               WHERE d.work_item_id = ?
               UNION
               SELECT DISTINCT d.* FROM current_deliberations d
               INNER JOIN deliberation_work_items dw ON d.id = dw.deliberation_id
               WHERE dw.work_item_id = ?
               ORDER BY rowid DESC""",
            (work_item_id, work_item_id),
        ).fetchall()
        return [_row_to_dict(r) for r in rows]

    def link_deliberation_spec(self, deliberation_id: str, spec_id: str, role: str = "related") -> None:
        """Link a deliberation to an additional spec via the relation table."""
        conn = self._get_conn()
        conn.execute(
            """INSERT OR REPLACE INTO deliberation_specs
               (deliberation_id, spec_id, role) VALUES (?, ?, ?)""",
            (deliberation_id, spec_id, role),
        )
        conn.commit()

    def link_deliberation_work_item(self, deliberation_id: str, work_item_id: str, role: str = "related") -> None:
        """Link a deliberation to an additional work item via the relation table."""
        conn = self._get_conn()
        conn.execute(
            """INSERT OR REPLACE INTO deliberation_work_items
               (deliberation_id, work_item_id, role) VALUES (?, ?, ?)""",
            (deliberation_id, work_item_id, role),
        )
        conn.commit()

    # ── ChromaDB semantic search integration ──────────────────────

    def _get_chroma_collection(self) -> Any | None:
        """Get or create the ChromaDB deliberations collection.

        Returns None if ChromaDB is not installed or not configured.
        Creates the persistence directory lazily on first use.
        """
        if not HAS_CHROMADB:
            return None
        if not hasattr(self, "_chroma_client"):
            chroma_path = getattr(self, "_chroma_path", None)
            if chroma_path is None:
                chroma_path = self.db_path.parent / self._canonical_chroma_dirname()
            chroma_path = Path(chroma_path)
            chroma_path.mkdir(parents=True, exist_ok=True)
            _chromadb = _load_chromadb()
            if _chromadb is None:
                return None
            self._chroma_client = _chromadb.PersistentClient(path=str(chroma_path))
        return self._chroma_client.get_or_create_collection(
            name=_CHROMA_COLLECTION_NAME,
            metadata={"hnsw:space": "l2"},
        )

    @staticmethod
    def _deliberation_chroma_metadata(row: dict[str, Any], *, chunk_index: int, chunk_count: int) -> dict[str, Any]:
        """Build ChromaDB metadata from a deliberation row.

        Maps SQLite ``id`` to Chroma ``delib_id``. Required fields are
        always present; optional fields are omitted when None.
        """
        metadata = {
            "delib_id": row["id"],
            "version": row["version"],
            "changed_at": row["changed_at"],
            "source_type": row["source_type"],
            "sensitivity": row.get("sensitivity", "normal"),
            "redaction_state": row.get("redaction_state", "clean"),
            "chunk_index": chunk_index,
            "chunk_count": chunk_count,
            "title": row["title"],
        }
        optional_fields = [
            "spec_id",
            "work_item_id",
            "outcome",
            "session_id",
            "source_ref",
            "origin_project",
            "origin_repo",
        ]
        metadata.update({k: row[k] for k in optional_fields if row.get(k) is not None})
        return metadata

    @staticmethod
    def _chunk_text_for_embedding(text: str) -> list[str]:
        """Split text into chunks sized for the embedding model.

        Uses sentence-boundary splitting with token-aware sizing.
        Each chunk targets CHUNK_MAX_TOKENS wordpieces with
        CHUNK_OVERLAP_TOKENS overlap from the previous chunk.

        Falls back to character estimation: ~4 chars per wordpiece for
        English prose, avoiding a hard dependency on the tokenizer.
        """
        chars_per_token = 4  # Conservative estimate for English
        max_chars = CHUNK_MAX_TOKENS * chars_per_token  # ~920 chars
        overlap_chars = CHUNK_OVERLAP_TOKENS * chars_per_token  # ~120 chars

        if len(text) <= max_chars:
            return [text]

        sentences = _SENTENCE_SPLIT_RE.split(text)
        chunks: list[str] = []
        current_chunk: list[str] = []
        current_len = 0

        for sentence in sentences:
            sentence_len = len(sentence)
            if sentence_len > max_chars:
                # Rare: single sentence exceeds limit — split mid-sentence
                if current_chunk:
                    chunks.append(" ".join(current_chunk))
                for i in range(0, sentence_len, max_chars - overlap_chars):
                    chunks.append(sentence[i : i + max_chars])
                current_chunk = []
                current_len = 0
                continue

            if current_len + sentence_len > max_chars and current_chunk:
                chunk_text = " ".join(current_chunk)
                chunks.append(chunk_text)
                # Overlap: keep trailing sentences that fit in overlap budget
                overlap_parts: list[str] = []
                overlap_len = 0
                for s in reversed(current_chunk):
                    if overlap_len + len(s) > overlap_chars:
                        break
                    overlap_parts.insert(0, s)
                    overlap_len += len(s)
                current_chunk = overlap_parts + [sentence]
                current_len = overlap_len + sentence_len
            else:
                current_chunk.append(sentence)
                current_len += sentence_len

        if current_chunk:
            chunks.append(" ".join(current_chunk))

        return chunks

    def _canonical_chroma_dirname(self) -> str:
        """Return the single canonical Chroma store directory name (FAB-17 Area 3).

        Reads config/governance/chroma-read-path.toml relative to the DB's
        parent (the project root) so every read path resolves to ONE index.
        Falls back to the historical default when the config is absent or
        unreadable (adopter installs / fresh clones).
        """
        try:
            import tomllib

            cfg = self.db_path.parent.joinpath(*_CHROMA_READ_PATH_CONFIG_RELPATH)
            if cfg.is_file():
                data = tomllib.loads(cfg.read_text(encoding="utf-8"))
                name = data.get("chroma", {}).get("canonical_dirname")
                if isinstance(name, str) and name.strip():
                    return name.strip()
        except Exception:  # intentional-catch: config optional; fall back to default
            pass
        return _CANONICAL_CHROMA_DIRNAME_DEFAULT

    def _index_deliberation_in_chroma(self, delib_id: str) -> int:
        """Index the current version of a deliberation in ChromaDB.

        Deletes any existing entries for this delib_id first (stale chunk
        removal), then indexes the current version's chunks.

        Returns the number of chunks indexed, or 0 if ChromaDB unavailable.
        """
        collection = self._get_chroma_collection()
        if collection is None:
            return 0

        # Delete stale entries for this deliberation
        try:
            collection.delete(where={"delib_id": delib_id})
        except Exception:  # intentional-catch: ChromaDB optional cleanup
            pass  # Collection may be empty or delib_id not present

        # Get current version
        row = self.get_deliberation(delib_id)
        if row is None:
            return 0

        # Only index redacted content — secrets never enter ChromaDB
        content = row["content"]
        chunks = self._chunk_text_for_embedding(content)

        ids = []
        documents = []
        metadatas = []
        for i, chunk in enumerate(chunks):
            chunk_id = f"{delib_id}::v{row['version']}::chunk-{i:03d}"
            metadata = self._deliberation_chroma_metadata(row, chunk_index=i, chunk_count=len(chunks))
            ids.append(chunk_id)
            documents.append(chunk)
            metadatas.append(metadata)

        # WI-4453: bound the embedding-triggering add so record/propose cannot
        # hang on a first-use model load. On timeout, degrade to a deferred
        # semantic index (sentinel 0 chunks) rather than raising — the canonical
        # SQLite DA row is already committed and the index is rebuildable.
        try:
            _call_with_timeout(
                lambda: collection.add(ids=ids, documents=documents, metadatas=metadatas),
                _CHROMA_INDEX_TIMEOUT_SECONDS,
            )
        except TimeoutError as _chroma_index_timeout:  # intentional-catch: degrade to deferred index
            _log.warning(
                "ChromaDB index add timed out after %.1fs for %s; deferring semantic "
                "index (canonical SQLite row preserved, rebuildable via "
                "rebuild_deliberation_index): %s",
                _CHROMA_INDEX_TIMEOUT_SECONDS,
                delib_id,
                _chroma_index_timeout,
            )
            return 0
        return len(chunks)

    def _chroma_query_matches(self, collection: Any, query: str, limit: int) -> dict[str, dict[str, Any]]:
        """Run the ChromaDB count + query and return ``{delib_id: match_info}``.

        Pure ChromaDB interaction (no SQLite) so it can run under a bounded
        timeout in a worker thread (FAB-17 / HYG-048) without violating SQLite
        thread affinity. Returns ``{}`` when the store is empty or nothing
        survives the distance filter; the caller then degrades to SQLite LIKE.
        """
        if collection.count() <= 0:
            return {}
        results = collection.query(
            query_texts=[query],
            n_results=min(limit * 3, 30),  # Over-fetch for dedup
        )
        if not (results and results["ids"] and results["ids"][0]):
            return {}
        seen_delib_ids: dict[str, dict[str, Any]] = {}
        for idx, (doc_id, distance) in enumerate(zip(results["ids"][0], results["distances"][0], strict=True)):
            if distance > SEMANTIC_MAX_DISTANCE:
                continue
            metadata = results["metadatas"][0][idx]
            delib_id = metadata.get("delib_id", "")
            # Keep best (lowest distance) per delib_id
            if delib_id not in seen_delib_ids or distance < seen_delib_ids[delib_id]["score"]:
                doc_text = results["documents"][0][idx] if results["documents"] else ""
                seen_delib_ids[delib_id] = {
                    "score": distance,
                    "matched_chunk_id": doc_id,
                    "matched_chunk_preview": doc_text[:200] if doc_text else None,
                }
        return seen_delib_ids

    def search_deliberations(self, query: str, *, limit: int = 5) -> list[dict[str, Any]]:
        """Search deliberations via ChromaDB semantic search merged with an
        always-on SQLite LIKE pass.

        On every call this runs BOTH a bounded ChromaDB semantic search
        (FAB-17 / HYG-048) AND an in-process SQLite LIKE pass, then merges the
        two result sets deduped by deliberation ``id``. Semantic results come
        first (preserving relevance ordering); LIKE-only rows are appended by
        recency (``rowid DESC``) for any id the semantic pass did not surface.
        The merged output is capped to ``limit``.

        The always-on LIKE merge (WI-4519) is the read-side complement to the
        WI-4453 embedding-timeout guard: when ``insert_deliberation`` persists a
        row in SQLite but its ChromaDB index step is deferred by a timeout, the
        row would otherwise be silently crowded out by any successful semantic
        search. Running LIKE on every call guarantees such fresh-but-unindexed
        deliberations are surfaced by the very next search, protecting the
        mandatory pre-proposal/pre-review Deliberation Archive search contract
        (``.claude/rules/deliberation-protocol.md``). LIKE is in-process
        SQLite: fast and cannot hang.

        Returns list of dicts with all deliberation row fields plus:
          - search_method: "semantic" | "text_match"
          - score: float (L2 distance, lower=better) | None for text_match
          - matched_chunk_id: str | None
          - matched_chunk_preview: str | None (first 200 chars of matched chunk)
        """
        # Semantic pass — bounded so chroma contention degrades to an empty
        # semantic set (FAB-17 / HYG-048) instead of crashing (the count() probe
        # was previously OUTSIDE the try) or hanging indefinitely. The SQLite
        # LIKE pass below always runs regardless of the semantic outcome.
        semantic_status: dict[str, Any] = {
            "semantic_expected": bool(HAS_CHROMADB),
            "semantic_attempted": False,
            "semantic_succeeded": False,
            "semantic_degraded": False,
            "degradation_reason": None,
        }
        self._last_deliberation_search_status = semantic_status
        semantic_results: list[dict[str, Any]] = []
        collection = self._get_chroma_collection()
        if collection is None and semantic_status["semantic_expected"]:
            semantic_status["semantic_degraded"] = True
            semantic_status["degradation_reason"] = "collection_unavailable"
        if collection is not None:
            seen_delib_ids: dict[str, dict[str, Any]] = {}
            attempts = max(1, _CHROMA_QUERY_RETRIES + 1)
            for attempt in range(attempts):
                try:
                    semantic_status["semantic_attempted"] = True
                    seen_delib_ids = _call_with_timeout(
                        lambda: self._chroma_query_matches(collection, query, limit),
                        _CHROMA_QUERY_TIMEOUT_SECONDS,
                    )
                    semantic_status["semantic_succeeded"] = True
                    semantic_status["semantic_degraded"] = False
                    semantic_status["degradation_reason"] = None
                    break
                except TimeoutError as _chroma_timeout:  # intentional-catch: degrade to SQLite LIKE
                    _log.warning(
                        "ChromaDB search timed out after %.1fs, falling back to SQLite LIKE: %s",
                        _CHROMA_QUERY_TIMEOUT_SECONDS,
                        _chroma_timeout,
                    )
                    seen_delib_ids = {}
                    semantic_status["semantic_degraded"] = True
                    semantic_status["degradation_reason"] = "timeout"
                    break  # a stalled store will stall again; do not retry a timeout
                except Exception as _chroma_err:  # intentional-catch: ChromaDB fallback to SQLite LIKE
                    if _is_chroma_stale_segment_error(_chroma_err):
                        _log.warning(
                            "ChromaDB stale/incompatible segment error, falling back to SQLite LIKE without retry: %s",
                            _chroma_err,
                        )
                        seen_delib_ids = {}
                        semantic_status["semantic_degraded"] = True
                        semantic_status["degradation_reason"] = "stale_segment"
                        break
                    _log.warning(
                        "ChromaDB search failed (attempt %d/%d), falling back to SQLite LIKE: %s",
                        attempt + 1,
                        attempts,
                        _chroma_err,
                    )
                    seen_delib_ids = {}
                    if attempt + 1 >= attempts:
                        semantic_status["semantic_degraded"] = True
                        semantic_status["degradation_reason"] = "error"
                    continue

            if seen_delib_ids:
                # Fetch full deliberation rows on the calling thread (SQLite is
                # thread-affine) and merge the semantic metadata.
                for delib_id, match_info in sorted(seen_delib_ids.items(), key=lambda x: x[1]["score"])[:limit]:
                    row = self.get_deliberation(delib_id)
                    if row:
                        row["search_method"] = "semantic"
                        row["score"] = match_info["score"]
                        row["matched_chunk_id"] = match_info["matched_chunk_id"]
                        row["matched_chunk_preview"] = match_info["matched_chunk_preview"]
                        semantic_results.append(row)

        # Always-on SQLite LIKE pass (WI-4519). Runs on every call — not only as
        # a fallback — so fresh-but-unindexed deliberations are never crowded out
        # by a successful semantic search.
        conn = self._get_conn()
        pattern = f"%{query}%"
        rows = conn.execute(
            """SELECT * FROM current_deliberations
               WHERE content LIKE ? OR summary LIKE ? OR title LIKE ?
               ORDER BY rowid DESC LIMIT ?""",
            (pattern, pattern, pattern, limit),
        ).fetchall()
        like_results = []
        for r in rows:
            d = _row_to_dict(r)
            d["search_method"] = "text_match"
            d["score"] = None
            d["matched_chunk_id"] = None
            d["matched_chunk_preview"] = None
            like_results.append(d)

        # Merge & dedupe by deliberation id: semantic results first (relevance
        # ordering preserved), then LIKE-only rows by recency for any id the
        # semantic pass did not already surface. Cap to ``limit``.
        merged: list[dict[str, Any]] = list(semantic_results)
        seen_ids = {row.get("id") for row in merged}
        for row in like_results:
            row_id = row.get("id")
            if row_id not in seen_ids:
                merged.append(row)
                seen_ids.add(row_id)
        return merged[:limit]

    def rebuild_deliberation_index(self) -> dict[str, Any]:
        """Rebuild ChromaDB collection from SQLite canonical data.

        Drops the existing collection and re-indexes all current
        deliberations. SQLite is always the source of truth.

        Returns: {"indexed": N, "chunks": M, "errors": []}
        """
        if not HAS_CHROMADB:
            return {"indexed": 0, "chunks": 0, "errors": ["ChromaDB not installed"]}

        # Drop and recreate collection
        client = self._get_chroma_collection()
        if client is None:
            return {"indexed": 0, "chunks": 0, "errors": ["ChromaDB client unavailable"]}

        # Delete the collection and recreate
        try:
            self._chroma_client.delete_collection(_CHROMA_COLLECTION_NAME)
        except Exception:  # intentional-catch: ChromaDB optional rebuild cleanup
            pass
        # Clear cached collection reference
        if hasattr(self, "_chroma_client"):
            pass  # Client persists; collection is recreated on next get_or_create

        # Re-index all current deliberations
        conn = self._get_conn()
        rows = conn.execute("SELECT id FROM current_deliberations").fetchall()
        indexed = 0
        total_chunks = 0
        errors: list[str] = []
        for row in rows:
            try:
                chunks = self._index_deliberation_in_chroma(row["id"])
                total_chunks += chunks
                indexed += 1
            except Exception as e:  # intentional-catch: per-item error tracking, continues rebuild
                errors.append(f"{row['id']}: {e}")

        return {"indexed": indexed, "chunks": total_chunks, "errors": errors}

    def get_summary(self) -> dict[str, Any]:
        """Return a high-level count summary across all artifact types in the database.

        Queries current-view tables for spec counts by status, test artifact
        counts, procedure counts, assertion pass/fail stats, work item counts
        by resolution status, backlog snapshot count, deliberation count,
        and pipeline event count.

        Returns:
            A dict with keys:
            - ``spec_counts``: dict of ``{status: count}`` for current specs.
            - ``spec_total``: total current spec count (sum of spec_counts).
            - ``spec_total_versions``: total rows in the specs history table.
            - ``test_procedure_count``: number of current test procedures.
            - ``op_procedure_count``: number of current operational procedures.
            - ``assertions_total``: count of specs with at least one assertion run.
            - ``assertions_passed``: count where the latest assertion run passed.
            - ``assertions_failed``: count where the latest assertion run failed.
            - ``env_config_count``: number of current environment config entries.
            - ``document_count``: number of current documents.
            - ``test_artifact_count``: number of current test artifacts.
            - ``test_plan_count``: number of current test plans.
            - ``test_plan_phase_count``: number of current test plan phases.
            - ``work_item_counts``: dict of ``{resolution_status: count}``.
            - ``work_item_total``: total current work item count.
            - ``backlog_snapshot_count``: number of current backlog snapshots.
            - ``testable_element_count``: number of current testable elements.
            - ``deliberation_count``: number of current deliberations.
            - ``pipeline_event_count``: total pipeline event rows.
        """
        conn = self._get_conn()
        specs = conn.execute("SELECT status, COUNT(*) as cnt FROM current_specifications GROUP BY status").fetchall()
        spec_counts = {r["status"]: r["cnt"] for r in specs}

        test_count = conn.execute("SELECT COUNT(*) FROM current_test_procedures").fetchone()[0]

        op_count = conn.execute("SELECT COUNT(*) FROM current_operational_procedures").fetchone()[0]

        assertion_stats = conn.execute(
            """SELECT
                 COUNT(*) as total,
                 SUM(overall_passed) as passed
               FROM (
                 SELECT a.* FROM assertion_runs a
                 INNER JOIN (
                   SELECT spec_id, MAX(rowid) AS max_rowid
                   FROM assertion_runs GROUP BY spec_id
                 ) m ON a.spec_id = m.spec_id AND a.rowid = m.max_rowid
               )"""
        ).fetchone()

        total_versions = conn.execute("SELECT COUNT(*) FROM specifications").fetchone()[0]

        env_count = conn.execute("SELECT COUNT(*) FROM current_environment_config").fetchone()[0]

        doc_count = conn.execute("SELECT COUNT(*) FROM current_documents").fetchone()[0]

        # Test coverage stats (legacy — superseded by tests table)
        cov_mappings = conn.execute("SELECT COUNT(*) FROM test_coverage").fetchone()[0]
        cov_specs = conn.execute("SELECT COUNT(DISTINCT spec_id) FROM test_coverage").fetchone()[0]

        # New artifact counts
        test_artifact_count = conn.execute("SELECT COUNT(*) FROM current_tests").fetchone()[0]
        test_plan_count = conn.execute("SELECT COUNT(*) FROM current_test_plans").fetchone()[0]
        test_plan_phase_count = conn.execute("SELECT COUNT(*) FROM current_test_plan_phases").fetchone()[0]

        wi_stats = conn.execute(
            "SELECT resolution_status, COUNT(*) as cnt FROM current_work_items GROUP BY resolution_status"
        ).fetchall()
        work_item_counts = {r["resolution_status"]: r["cnt"] for r in wi_stats}

        project_stats = conn.execute("SELECT status, COUNT(*) as cnt FROM current_projects GROUP BY status").fetchall()
        project_counts = {r["status"]: r["cnt"] for r in project_stats}
        project_membership_count = conn.execute(
            "SELECT COUNT(*) FROM current_project_work_item_memberships"
        ).fetchone()[0]
        project_dependency_count = conn.execute("SELECT COUNT(*) FROM current_project_dependencies").fetchone()[0]
        project_artifact_link_count = conn.execute("SELECT COUNT(*) FROM current_project_artifact_links").fetchone()[0]
        project_authorization_count = conn.execute("SELECT COUNT(*) FROM current_project_authorizations").fetchone()[0]

        backlog_count = conn.execute("SELECT COUNT(*) FROM current_backlog_snapshots").fetchone()[0]

        te_count = conn.execute("SELECT COUNT(*) FROM current_testable_elements").fetchone()[0]

        delib_count = conn.execute("SELECT COUNT(*) FROM current_deliberations").fetchone()[0]

        return {
            "spec_counts": spec_counts,
            "spec_total": sum(spec_counts.values()),
            "spec_total_versions": total_versions,
            "test_procedure_count": test_count,
            "op_procedure_count": op_count,
            "assertions_total": assertion_stats["total"] or 0,
            "assertions_passed": assertion_stats["passed"] or 0,
            "assertions_failed": (assertion_stats["total"] or 0) - (assertion_stats["passed"] or 0),
            "env_config_count": env_count,
            "document_count": doc_count,
            "test_coverage_mappings": cov_mappings,
            "test_coverage_specs": cov_specs,
            "test_artifact_count": test_artifact_count,
            "test_plan_count": test_plan_count,
            "test_plan_phase_count": test_plan_phase_count,
            "work_item_counts": work_item_counts,
            "work_item_total": sum(work_item_counts.values()),
            "project_counts": project_counts,
            "project_total": sum(project_counts.values()),
            "project_membership_count": project_membership_count,
            "project_dependency_count": project_dependency_count,
            "project_artifact_link_count": project_artifact_link_count,
            "project_authorization_count": project_authorization_count,
            "backlog_snapshot_count": backlog_count,
            "testable_element_count": te_count,
            "deliberation_count": delib_count,
            "pipeline_event_count": conn.execute("SELECT COUNT(*) FROM pipeline_events").fetchone()[0],
        }


def _require_text(field_name: str, value: str) -> str:
    text = value.strip()
    if not text:
        raise ValueError(f"{field_name} must be a non-empty string")
    return text


def _encode_json(value: Any) -> str:
    return json.dumps(value)


def _row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    # Parse JSON fields — expose as both "field_parsed" (clean) and "_field_parsed" (legacy)
    for key in (
        "assertions",
        "results",
        "variables",
        "steps",
        "known_failure_modes",
        "tags",
        "context",
        "participants",
        "test_ids",
        "work_item_ids",
        "summary_by_origin",
        "summary_by_component",
        "applicable_dimensions",
        "constraints",
        "affected_by",
        "source_paths",
        "related_deliberation_ids",
        "related_spec_ids_at_creation",
        "related_bridge_threads",
        "depends_on_work_items",
        "blocks_work_items",
        "supersedes",
        "superseded_by",
        "allowed_mutation_classes",
        "forbidden_operations",
        "included_work_item_ids",
        "excluded_work_item_ids",
        "included_spec_ids",
        "excluded_spec_ids",
        "stage_sequence",
        "required_roles_by_stage",
        "stages",
        "required_roles",
        "auq_gate_positions",
        "never_self_review_stages",
        "never_self_review_points",
        "deterministic_carve_outs",
        "deterministic_carveouts",
        "workspace_isolation",
        "source_spec_ids",
        "metadata",
        "event_payload",
        "capabilities",
        "dispatch_decision",
        "lease_lifecycle",
        "test_summary",
        "recovery_actions",
        "artifact_links",
    ):
        if key in d and d[key] and isinstance(d[key], str):
            try:
                parsed = json.loads(d[key])
                # Defensive: handle double-encoded JSON (string instead of list/dict)
                if isinstance(parsed, str):
                    try:
                        parsed = json.loads(parsed)
                    except (json.JSONDecodeError, TypeError):
                        pass
                d[f"{key}_parsed"] = parsed
                d[f"_{key}_parsed"] = parsed  # backward compat
            except (json.JSONDecodeError, TypeError):
                pass
    return d
