"""
GroundTruth KB deterministic handoff-prompt service.

Implements ``SPEC-HANDOFF-PROMPT-DETERMINISTIC-SERVICE-001`` (MemBase rowid
8562). The service generates a bounded, action-oriented handoff prompt that
the next GroundTruth-KB session reads to inherit the closing session's open
state. Output is byte-stable for identical canonical inputs and contains no
AI-mediated content.

Inputs (per spec § Inputs):

1. The latest archived session-envelope JSON at
   ``harness-state/<harness_name>/session-envelope-archive/<closed_at-ISO>-session-envelope.json``.
2. Open bridge state filtered for the active role: the latest NEW / REVISED /
   GO / NO-GO line per versioned bridge Document chain.

Outputs (per spec § Output Surfaces):

1. A new MemBase ``session_prompts`` row keyed by ``session_id`` plus a
   deterministic idempotency key carried in the row's ``context`` JSON field.
2. A markdown file at ``.claude/session/handoff-<session-id>.md``.
3. Terminal echo (performed by the CLI wrapper, not this module).

Copyright (c) 2026 Remaker Digital, a DBA of VanDusen & Palmeter, LLC. All rights reserved.
Licensed under AGPL-3.0-or-later.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from groundtruth_kb.db import KnowledgeDB
from groundtruth_kb.harness_projection import HarnessStateError, read_identity

# Canonical status tokens we surface in the handoff prompt. Latest-only per
# Document; matches the bridge file-bridge protocol § Statuses.
_BRIDGE_STATUSES_OF_INTEREST = ("NEW", "REVISED", "GO", "NO-GO")

# Roles for which a bridge entry is considered "open" / actionable.
_ROLE_ACTIONABLE_STATUSES = {
    "prime-builder": ("GO", "NO-GO"),
    "loyal-opposition": ("NEW", "REVISED"),
}


class HandoffError(Exception):
    """Raised when the handoff service cannot produce a deterministic prompt.

    The CLI maps this to a non-zero exit code.
    """


def generate(
    session_id: str | None = None,
    *,
    project_root: Path | None = None,
    db: KnowledgeDB | None = None,
    harness_name: str | None = None,
) -> dict[str, Any]:
    """Generate the deterministic handoff prompt for a session.

    Args:
        session_id: Operator-supplied identifier used to key MemBase rows and
            name the markdown output file. When ``None``, the service derives
            an identifier from the latest archived envelope's ``harness_id``
            plus its ``closed_at`` field.
        project_root: Repository root. Defaults to the GT-KB project root
            (resolved relative to this module).
        db: Optional pre-bound ``KnowledgeDB``. Tests inject this; production
            opens the default database resolved from ``project_root``.
        harness_name: Optional explicit registered harness-name override. When
            omitted and ``session_id`` is supplied, the service resolves the
            matching envelope by scanning registered archive directories.

    Returns:
        A dict with keys ``session_id``, ``prompt_markdown``, ``output_files``,
        and ``session_prompts_id``.

    Raises:
        HandoffError: When the archive directory or a usable envelope file is
            missing, or when bridge state cannot be read.
    """
    root = (project_root or _default_project_root()).resolve()
    if harness_name is not None:
        resolved_harness_name = _validate_harness_name_override(root, harness_name)
        archive_dir = root / "harness-state" / resolved_harness_name / "session-envelope-archive"
        if not archive_dir.exists():
            raise HandoffError(
                f"Session-envelope archive directory missing: {archive_dir}. "
                "WI-4293 (session-envelope durability) must land before the handoff "
                "service can read archived envelopes for harness '{harness_name}'.".format(
                    harness_name=resolved_harness_name,
                )
            )
        envelope_path = _select_envelope_for_session_id(archive_dir, session_id)
    elif session_id is not None:
        resolved_harness_name, envelope_path = _select_envelope_across_archives(root, session_id)
        archive_dir = root / "harness-state" / resolved_harness_name / "session-envelope-archive"
    else:
        resolved_harness_name = _resolve_active_harness_name(root)
        archive_dir = root / "harness-state" / resolved_harness_name / "session-envelope-archive"
        if not archive_dir.exists():
            raise HandoffError(
                f"Session-envelope archive directory missing: {archive_dir}. "
                "WI-4293 (session-envelope durability) must land before the handoff "
                "service can read archived envelopes for harness '{harness_name}'.".format(
                    harness_name=resolved_harness_name,
                )
            )
        envelope_path = _select_envelope_for_session_id(archive_dir, None)
    if envelope_path is None:
        raise HandoffError(
            f"No archived session envelope found in {archive_dir}. "
            "Run ::wrap on a session before invoking the handoff service.",
        )

    envelope_bytes = envelope_path.read_bytes()
    envelope = json.loads(envelope_bytes.decode("utf-8"))

    resolved_session_id = session_id or _derive_session_id(envelope, envelope_path)

    bridge_bytes = _read_bridge_state_bytes(root)
    role = _role_from_envelope(envelope)
    bridge_state = _parse_bridge_state_for_role(bridge_bytes.decode("utf-8"), role)

    idempotency_key = _compute_idempotency_key(
        resolved_session_id,
        envelope_bytes,
        bridge_bytes,
    )

    owned_db = db is None
    db_instance = db if db is not None else KnowledgeDB(db_path=root / "groundtruth.db")
    try:
        existing = db_instance.get_session_prompt_by_idempotency_key(
            resolved_session_id,
            idempotency_key,
        )
        if existing is not None:
            prompt_markdown = existing["prompt_text"]
            handoff_md_path = _write_handoff_markdown(
                root,
                resolved_session_id,
                prompt_markdown,
            )
            return {
                "session_id": resolved_session_id,
                "prompt_markdown": prompt_markdown,
                "output_files": [str(handoff_md_path.relative_to(root))],
                "session_prompts_id": _row_identifier(existing),
            }

        prompt_markdown = _assemble_prompt(
            session_id=resolved_session_id,
            envelope=envelope,
            envelope_path=envelope_path,
            bridge_state=bridge_state,
            role=role,
        )
        context = {
            "idempotency_key": idempotency_key,
            "envelope_path": str(envelope_path.relative_to(root)),
            "role": role,
        }
        row = db_instance.insert_session_prompt(
            resolved_session_id,
            prompt_markdown,
            context=context,
        )
        if row is None:
            raise HandoffError(
                f"MemBase insert_session_prompt returned no row for session_id={resolved_session_id!r}",
            )
        handoff_md_path = _write_handoff_markdown(
            root,
            resolved_session_id,
            prompt_markdown,
        )
        return {
            "session_id": resolved_session_id,
            "prompt_markdown": prompt_markdown,
            "output_files": [str(handoff_md_path.relative_to(root))],
            "session_prompts_id": _row_identifier(row),
        }
    finally:
        if owned_db:
            with _suppress():
                db_instance.close()


# ---------------------------------------------------------------------------
# Pure helpers (deterministic)
# ---------------------------------------------------------------------------


def _default_project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def _registered_harnesses(project_root: Path) -> dict[str, Any]:
    """Read registered harness identities through the canonical reader."""
    identities_path = project_root / "harness-state" / "harness-identities.json"
    try:
        data = read_identity(project_root)
    except HarnessStateError as exc:
        raise HandoffError(f"Harness identities missing or unreadable: {identities_path}") from exc
    harnesses = data.get("harnesses", {}) or data.get("identities", {}) or {}
    if not isinstance(harnesses, dict) or not harnesses:
        raise HandoffError(
            f"No harnesses recorded in {identities_path}; cannot resolve active harness.",
        )
    return harnesses


def _validate_harness_name_override(project_root: Path, harness_name: str) -> str:
    """Validate an explicit harness override as a registered path segment."""
    candidate = harness_name.strip()
    if not candidate:
        raise HandoffError("invalid harness name: empty")
    if candidate in {".", ".."}:
        raise HandoffError(f"invalid harness name: contains path syntax: {candidate!r}")
    if any(separator in candidate for separator in ("/", "\\", ":")):
        raise HandoffError(f"invalid harness name: contains path syntax: {candidate!r}")
    if Path(candidate).is_absolute():
        raise HandoffError(f"invalid harness name: absolute path: {candidate!r}")

    harnesses = _registered_harnesses(project_root)
    if candidate not in harnesses:
        raise HandoffError(f"not a registered harness: {candidate}")

    base = (project_root / "harness-state" / candidate).resolve()
    archive_dir = (base / "session-envelope-archive").resolve()
    try:
        archive_dir.relative_to(base)
    except ValueError as exc:
        raise HandoffError(f"invalid harness name escapes registered harness directory: {candidate!r}") from exc
    return candidate


def _resolve_active_harness_name(project_root: Path) -> str:
    """Resolve the active host-local harness name via deterministic disambiguation.

    Selection rule (per FINDING-P1-002 of
    ``bridge/gtkb-handoff-prompt-deterministic-service-impl-007.md``):

    1. Read ``harness-state/harness-identities.json``.
    2. Use every enumerated harness as the candidate pool. ``status`` fields
       are metadata only for this resolver and must not narrow the pool.
    3. Filter that pool to names whose
       ``harness-state/<name>/session-envelope-archive`` directory exists.
    4. If exactly one candidate remains, return it.
    5. Otherwise raise ``HandoffError`` — alphabetic fallback would select a
       registered-but-non-present harness (e.g., ``antigravity`` sorting
       before ``claude`` / ``codex``).

    This function is used only when both ``harness_name`` and ``session_id`` are
    omitted. Explicit ``session_id`` calls scan registered archives directly.
    """
    harnesses = _registered_harnesses(project_root)
    pool = list(harnesses.keys())
    candidates = sorted(
        name for name in pool if (project_root / "harness-state" / name / "session-envelope-archive").is_dir()
    )
    if not candidates:
        raise HandoffError(
            "No registered harness has a session-envelope archive directory under "
            f"{project_root / 'harness-state'}. WI-4293 (session-envelope durability) "
            "must land before the handoff service can read archived envelopes.",
        )
    if len(candidates) == 1:
        return str(candidates[0])
    raise HandoffError(
        "Cannot deterministically resolve active harness: multiple harnesses have "
        f"session-envelope archives ({candidates}); supply the active harness explicitly.",
    )


def _latest_archived_envelope(archive_dir: Path) -> Path | None:
    """Return the lexicographically largest envelope file, or None.

    Archive filenames are ``<closed_at-ISO>-session-envelope.json`` per
    WI-4293's invariant; lexicographic ordering matches chronological order
    for ISO-8601 UTC timestamps.
    """
    candidates = sorted(p for p in archive_dir.glob("*-session-envelope.json") if p.is_file())
    return candidates[-1] if candidates else None


def _select_envelope_for_session_id(
    archive_dir: Path,
    session_id: str | None,
) -> Path | None:
    """Select the archived envelope identified by ``session_id``.

    Per ``SPEC-HANDOFF-PROMPT-DETERMINISTIC-SERVICE-001`` § Inputs (line 278):
    ``<harness_name>`` and ``<closed_at-ISO>`` are resolved "from the
    ``session_id`` + directory contents at service invocation time." That
    contract requires the explicit ``session_id`` to participate in archive
    selection — not be applied as a label after a latest-envelope pick.

    Selection rules:

    1. If ``session_id is None``: fall back to ``_latest_archived_envelope``
       so callers that omit the argument receive the most-recently-archived
       envelope (canonical case for fresh-wrap handoff).
    2. If ``session_id`` is supplied: scan candidate envelope files. For
       each, look up the canonical session identifier:

       a. Prefer the envelope's explicit ``session_id`` JSON field when
          present.
       b. Otherwise fall back to ``_derive_session_id(envelope, path)``
          (``{harness_id}-{closed_at}``), which is the legacy derivation
          used by callers that pre-date the explicit-field schema.

       Match the supplied ``session_id`` against the canonical identifier.
       On exactly one match: return it. On zero matches: raise
       ``HandoffError`` ("no archived envelope matches session_id"). On
       multiple matches: raise ``HandoffError`` ("ambiguous").

    This closes FINDING-P1-001 of
    ``bridge/gtkb-handoff-prompt-deterministic-service-impl-009.md``.
    """
    candidates = sorted(p for p in archive_dir.glob("*-session-envelope.json") if p.is_file())
    if not candidates:
        return None
    if session_id is None:
        return candidates[-1]

    matches: list[Path] = []
    for candidate in candidates:
        canonical_id = _canonical_session_id_for_envelope(candidate)
        if canonical_id is None:
            continue
        if canonical_id == session_id:
            matches.append(candidate)

    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise HandoffError(
            f"No archived envelope matches session_id={session_id!r} in {archive_dir}. "
            f"Found {len(candidates)} envelope(s); the explicit session_id must match an "
            "envelope's `session_id` field or its derived `<harness_id>-<closed_at>` form."
        )
    raise HandoffError(
        f"Ambiguous archive selection: multiple envelopes match session_id={session_id!r} "
        f"in {archive_dir} ({[m.name for m in matches]}). Archive envelopes must have "
        "distinct session_id values."
    )


def _select_envelope_across_archives(project_root: Path, session_id: str) -> tuple[str, Path]:
    """Resolve a session envelope by scanning all registered harness archives."""
    harnesses = _registered_harnesses(project_root)
    matches: list[tuple[str, Path]] = []
    scanned_names: list[str] = []

    for harness_name in sorted(harnesses.keys()):
        archive_dir = project_root / "harness-state" / harness_name / "session-envelope-archive"
        if not archive_dir.is_dir():
            continue
        scanned_names.append(harness_name)
        for candidate in sorted(p for p in archive_dir.glob("*-session-envelope.json") if p.is_file()):
            if _canonical_session_id_for_envelope(candidate) == session_id:
                matches.append((harness_name, candidate))

    if len(matches) == 1:
        return matches[0]
    if not scanned_names:
        raise HandoffError(
            "No registered harness has a session-envelope archive directory under "
            f"{project_root / 'harness-state'}. WI-4293 (session-envelope durability) "
            "must land before the handoff service can read archived envelopes.",
        )
    if not matches:
        raise HandoffError(
            f"No archived envelope matches session_id={session_id!r} in any scanned harness archive. "
            f"Scanned: {scanned_names}."
        )
    harness_names = [name for name, _path in matches]
    envelope_names = [f"{name}/{path.name}" for name, path in matches]
    raise HandoffError(
        f"Ambiguous archive selection: session_id={session_id!r} matches multiple envelopes "
        f"in registered harness archives {harness_names}: {envelope_names}."
    )


def _canonical_session_id_for_envelope(envelope_path: Path) -> str | None:
    """Return the explicit or derived session id for a readable envelope."""
    try:
        envelope = json.loads(envelope_path.read_bytes().decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError, OSError):
        return None
    if not isinstance(envelope, dict):
        return None
    explicit = envelope.get("session_id")
    if explicit is not None:
        return str(explicit)
    return _derive_session_id(envelope, envelope_path)


def _derive_session_id(envelope: dict[str, Any], envelope_path: Path) -> str:
    """Deterministically derive a session_id from envelope metadata."""
    harness_id = envelope.get("harness_id") or envelope.get("harness_name") or "unknown"
    closed_at = envelope.get("closed_at") or envelope_path.stem
    return f"{harness_id}-{closed_at}"


def _role_from_envelope(envelope: dict[str, Any]) -> str:
    """Extract the canonical operating role from the envelope."""
    role = envelope.get("role_resolved") or envelope.get("role")
    if role in _ROLE_ACTIONABLE_STATUSES:
        return str(role)
    return "prime-builder"


_DOCUMENT_LINE = re.compile(r"^Document:\s*(?P<name>\S+)\s*$")
_STATUS_LINE = re.compile(r"^(?P<status>[A-Z-]+):\s*(?P<path>\S+)\s*$")
_VERSIONED_BRIDGE_FILE = re.compile(r"^(?P<slug>.+)-(?P<version>\d+)\.md$")
_BRIDGE_FILE_STATUS = re.compile(
    r"^[#>*\-\s`]*(NEW|REVISED|GO|NO-GO|VERIFIED|ADVISORY|DEFERRED|WITHDRAWN)\b",
    re.IGNORECASE,
)


def _read_bridge_state_bytes(project_root: Path) -> bytes:
    """Render current bridge state from status-bearing numbered files."""
    rendered = _render_versioned_bridge_state(project_root)
    if not rendered:
        raise HandoffError(f"No readable bridge state under {project_root / 'bridge'}")
    return rendered.encode("utf-8")


def _status_from_bridge_file(path: Path) -> str | None:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        match = _BRIDGE_FILE_STATUS.match(stripped)
        return match.group(1).upper() if match else None
    return None


def _render_versioned_bridge_state(project_root: Path) -> str:
    bridge_dir = project_root / "bridge"
    if not bridge_dir.is_dir():
        return ""
    rows: dict[str, list[tuple[int, str, str]]] = {}
    for path in bridge_dir.glob("*.md"):
        match = _VERSIONED_BRIDGE_FILE.match(path.name)
        if not match:
            continue
        status = _status_from_bridge_file(path)
        if status is None:
            continue
        slug = match.group("slug")
        version = int(match.group("version"))
        rows.setdefault(slug, []).append((version, status, f"bridge/{path.name}"))
    lines = ["<!-- GENERATED IN MEMORY: bridge state rendered from numbered bridge files. -->", ""]
    for slug in sorted(rows):
        lines.append(f"Document: {slug}")
        for _version, status, rel_path in sorted(rows[slug], reverse=True):
            lines.append(f"{status}: {rel_path}")
        lines.append("")
    return "\n".join(lines)


def _parse_bridge_state_for_role(index_text: str, role: str) -> list[dict[str, str]]:
    """Parse INDEX-shaped bridge state into role-filtered latest-status entries.

    Returns a list of ``{document, status, path}`` dicts whose ``status`` is
    actionable for ``role``. Entries are ordered by first appearance in the
    rendered state (newest version first within each document).
    """
    actionable = _ROLE_ACTIONABLE_STATUSES.get(role, _ROLE_ACTIONABLE_STATUSES["prime-builder"])
    entries: list[dict[str, str]] = []
    current_doc: str | None = None
    latest_seen: bool = False
    for raw in index_text.splitlines():
        line = raw.rstrip()
        doc_match = _DOCUMENT_LINE.match(line)
        if doc_match:
            current_doc = doc_match.group("name")
            latest_seen = False
            continue
        if current_doc is None:
            continue
        status_match = _STATUS_LINE.match(line)
        if not status_match:
            continue
        if latest_seen:
            continue
        latest_seen = True
        status = status_match.group("status")
        if status not in _BRIDGE_STATUSES_OF_INTEREST:
            continue
        if status not in actionable:
            continue
        entries.append(
            {
                "document": current_doc,
                "status": status,
                "path": status_match.group("path"),
            },
        )
    return entries


def _compute_idempotency_key(
    session_id: str,
    envelope_bytes: bytes,
    bridge_bytes: bytes,
) -> str:
    """Compute the deterministic idempotency key for these inputs."""
    digest = hashlib.sha256()
    digest.update(session_id.encode("utf-8"))
    digest.update(b"\x00")
    digest.update(envelope_bytes)
    digest.update(b"\x00")
    digest.update(bridge_bytes)
    return f"sha256:{digest.hexdigest()}"


def _assemble_prompt(
    *,
    session_id: str,
    envelope: dict[str, Any],
    envelope_path: Path,
    bridge_state: list[dict[str, str]],
    role: str,
) -> str:
    """Assemble the deterministic handoff-prompt markdown body."""
    harness_id = envelope.get("harness_id", "unknown")
    harness_name = envelope.get("harness_name", "unknown")
    project_id = envelope.get("project_id") or "unset"
    active_wi = envelope.get("active_work_item_id") or "unset"
    work_item_ids = envelope.get("work_item_ids") or []
    closed_at = envelope.get("closed_at") or "unset"
    wrap_outcome = envelope.get("wrap_outcome") or "unset"
    topics = envelope.get("topics") or []

    lines: list[str] = []
    lines.append(f"# Handoff Prompt - session {session_id}")
    lines.append("")
    lines.append(
        "Generated deterministically per "
        "SPEC-HANDOFF-PROMPT-DETERMINISTIC-SERVICE-001 from the archived "
        "session envelope plus live versioned bridge state.",
    )
    lines.append("")
    lines.append("## Closed Session Envelope")
    lines.append("")
    lines.append(f"- envelope_file: {envelope_path.name}")
    lines.append(f"- harness_id: {harness_id}")
    lines.append(f"- harness_name: {harness_name}")
    lines.append(f"- role: {role}")
    lines.append(f"- project_id: {project_id}")
    lines.append(f"- active_work_item_id: {active_wi}")
    lines.append(f"- work_item_ids: {', '.join(work_item_ids) if work_item_ids else 'none'}")
    lines.append(f"- closed_at: {closed_at}")
    lines.append(f"- wrap_outcome: {wrap_outcome}")
    lines.append("")
    lines.append("## Topics Recorded in Envelope")
    lines.append("")
    if topics:
        for topic in topics:
            ttype = topic.get("type", "unknown")
            outcome = topic.get("close_outcome", "unset")
            opened = topic.get("opened_at", "unset")
            closed = topic.get("closed_at", "unset")
            lines.append(
                f"- {ttype}: close_outcome={outcome} opened_at={opened} closed_at={closed}",
            )
    else:
        lines.append("- (no topics recorded)")
    lines.append("")
    lines.append(f"## Open Bridge Entries Actionable for {role}")
    lines.append("")
    if bridge_state:
        for entry in bridge_state:
            lines.append(
                f"- {entry['status']}: {entry['document']} -> {entry['path']}",
            )
    else:
        lines.append("- (no actionable bridge entries for this role)")
    lines.append("")
    lines.append("## Next-Session Direction")
    lines.append("")
    lines.append(
        "Read this handoff prompt, then read live dispatcher/TAFE state and "
        "the versioned bridge file chain. Act on the role-actionable entries "
        "above in oldest-first order.",
    )
    lines.append("")
    return "\n".join(lines)


def _write_handoff_markdown(
    project_root: Path,
    session_id: str,
    prompt_markdown: str,
) -> Path:
    """Write the handoff-prompt markdown to .claude/session/handoff-<id>.md."""
    out_dir = project_root / ".claude" / "session"
    out_dir.mkdir(parents=True, exist_ok=True)
    safe_session_id = re.sub(r"[^A-Za-z0-9._-]", "_", session_id)
    out_path = out_dir / f"handoff-{safe_session_id}.md"
    out_path.write_text(prompt_markdown, encoding="utf-8")
    return out_path


def _row_identifier(row: dict[str, Any]) -> str:
    """Return a stable identifier for a session_prompts row."""
    rowid = row.get("rowid")
    if rowid is None:
        return f"session_prompts:{row.get('session_id')}:{row.get('version')}"
    return f"session_prompts:{rowid}"


class _suppress:
    """Tiny context manager that swallows AttributeError on db.close()."""

    def __enter__(self) -> _suppress:
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, tb: object) -> bool:
        return exc_type is None or issubclass(exc_type, AttributeError)
